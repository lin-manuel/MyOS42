# First-Party Detailed File Report

Generated on: 2026-03-06T21:59:14+03:00
Root: /home/immanuel/classwork/myos

---

## myos_backend/.env.example

- Size: 685 bytes
- Lines: 30
- Modified: 2026-03-05 21:10:45
- SHA256: c8851beea6e723692bffb24419df2bfcd0e181c781d3b19edccd5c0f57367180
- MIME: text/plain

```
DJANGO_ENV=development
DJANGO_SECRET_KEY=change-me
DJANGO_DEBUG=True
DJANGO_ALLOWED_HOSTS=127.0.0.1,localhost
LOCALHOST_ONLY=True

DATABASE_ENGINE=sqlite
DATABASE_NAME=myos
DATABASE_USER=myos
DATABASE_PASSWORD=myos
DATABASE_HOST=127.0.0.1
DATABASE_PORT=5432

EMAIL_HOST=smtp.example.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=example@example.com
EMAIL_HOST_PASSWORD=change-me
DEFAULT_FROM_EMAIL=MyOS <no-reply@myos.local>

CORS_ALLOWED_ORIGINS=http://127.0.0.1:8000,http://localhost:8000

FERNET_KEY=generate-a-valid-fernet-key
ACCESS_TOKEN_MINUTES=5
REFRESH_TOKEN_DAYS=1

SECURE_SSL_REDIRECT=False
SESSION_COOKIE_SECURE=False
CSRF_COOKIE_SECURE=False
SECURE_HSTS_SECONDS=0

```

---

## myos_backend/Dockerfile

- Size: 382 bytes
- Lines: 15
- Modified: 2026-03-05 18:52:04
- SHA256: 10f97fb7fd33a83950b0b4461358a843f120e2edf9bc4ba5ec889b3dfc7b25d2
- MIME: text/plain

```
FROM python:3.12-slim

ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1

WORKDIR /app

RUN apt-get update && apt-get install -y --no-install-recommends gcc libpq-dev && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["gunicorn", "myos_backend.wsgi:application", "--bind", "0.0.0.0:8000", "--workers", "3"]

```

---

## myos_backend/README.md

- Size: 645 bytes
- Lines: 32
- Modified: 2026-03-05 18:39:59
- SHA256: 48abb3fe37f2be1eebfd92a5eed319d0aa706d38a6c59a59cfff1d04e51b3466
- MIME: text/plain

```
# MyOS Backend

Production-oriented Django backend for MyOS with:
- Custom user model + JWT auth
- OTP verification flow
- Modular domain apps
- DRF APIs + server-rendered template support
- Service-layer business logic
- Security middleware, audit logs, and encrypted sensitive fields

## Quick Start

1. Create venv and install dependencies.
2. Copy `.env.example` to `.env` and configure values.
3. Run migrations and start server:

```bash
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## Apps
- `users`
- `projects`
- `finance`
- `diary`
- `media`
- `bucket`
- `notifications`
- `api`
- `common`

```

---

## myos_backend/apps/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/api/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/api/admin.py

- Size: 31 bytes
- Lines: 1
- Modified: 2026-03-05 18:49:55
- SHA256: 45e3b2dff0eb1333b8be4eb64fa04e6c74c798846f31ecea9ecfc9d1e0ef72f7
- MIME: text/plain

```
# API app has no admin models.

```

---

## myos_backend/apps/api/apps.py

- Size: 161 bytes
- Lines: 7
- Modified: 2026-03-05 18:42:41
- SHA256: 95334ba57ea86b0ecbc562b4a55a0b7d2efa9ab28c5d15f3c222ef9a4cfb68e1
- MIME: text/x-script.python

```
from django.apps import AppConfig


class ApiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.api"
    label = "api"

```

---

## myos_backend/apps/api/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/api/models.py

- Size: 35 bytes
- Lines: 1
- Modified: 2026-03-05 18:50:09
- SHA256: a3d7eee076733acc5c96f70d273ba9984cc13255aaba2549217bcaf0b52f153a
- MIME: text/plain

```
# API app stores no domain models.

```

---

## myos_backend/apps/api/permissions.py

- Size: 111 bytes
- Lines: 5
- Modified: 2026-03-05 18:50:09
- SHA256: 4da3c04f59b92603307e2d33bb1c80256d9536256b5157bb4f68e1107defba54
- MIME: text/x-script.python

```
from rest_framework.permissions import IsAuthenticated


class APIDefaultPermission(IsAuthenticated):
    pass

```

---

## myos_backend/apps/api/serializers.py

- Size: 381 bytes
- Lines: 12
- Modified: 2026-03-05 18:50:09
- SHA256: 5ab7e164c7d433a0a18779fd3796b3d8475bb758535bffddc5392f326d240855
- MIME: text/x-script.python

```
from rest_framework import serializers


class SearchQuerySerializer(serializers.Serializer):
    q = serializers.CharField(max_length=200)


class DashboardSerializer(serializers.Serializer):
    project_counts = serializers.ListField()
    finance = serializers.DictField()
    bucket_completion = serializers.IntegerField()
    unread_notifications = serializers.IntegerField()

```

---

## myos_backend/apps/api/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/api/services/dashboard_service.py

- Size: 963 bytes
- Lines: 26
- Modified: 2026-03-05 18:45:35
- SHA256: 0460474a01fbc2d671b7c61fcf3abde0791e152836bf25ec5e528bcf614ef455
- MIME: text/x-script.python

```
from django.db.models import Count

from apps.bucket.services.bucket_service import BucketService
from apps.finance.services.finance_service import FinanceService
from apps.notifications.services.notification_service import NotificationService
from apps.projects.models import Project


class DashboardService:
    @staticmethod
    def get_dashboard_payload(user):
        project_counts = (
            Project.objects.filter(user=user)
            .values("status")
            .annotate(total=Count("id"))
            .order_by("status")
        )
        finance = FinanceService.summary_for_user(user)
        bucket_completion = BucketService.completion_rate(user)
        unread_notifications = NotificationService.unread_count(user)
        return {
            "project_counts": list(project_counts),
            "finance": finance,
            "bucket_completion": bucket_completion,
            "unread_notifications": unread_notifications,
        }

```

---

## myos_backend/apps/api/signals.py

- Size: 42 bytes
- Lines: 1
- Modified: 2026-03-05 18:49:22
- SHA256: 6313b39348ec991759661446b255659bb92d298cf5be8b911f444920f2687cdf
- MIME: text/plain

```
# API app does not define domain signals.

```

---

## myos_backend/apps/api/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/api/urls.py

- Size: 1398 bytes
- Lines: 28
- Modified: 2026-03-05 18:48:39
- SHA256: 7a4de8e265918fb0f073fba41b1cca470efef422e00e7333bb6d46b91ce5f92a
- MIME: text/x-script.python

```
from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.api.views import DashboardAggregationAPIView, GlobalSearchAPIView
from apps.bucket.views import BucketCategoryViewSet, BucketItemViewSet
from apps.diary.views import DiaryEntryViewSet
from apps.finance.views import FinanceEntryViewSet
from apps.media.views import MediaItemViewSet
from apps.notifications.views import NotificationViewSet
from apps.projects.views import ProjectViewSet
from apps.users.views import UserProfileViewSet

router = DefaultRouter()
router.register(r"profile", UserProfileViewSet, basename="profile")
router.register(r"projects", ProjectViewSet, basename="projects")
router.register(r"finance", FinanceEntryViewSet, basename="finance")
router.register(r"diary", DiaryEntryViewSet, basename="diary")
router.register(r"media", MediaItemViewSet, basename="media")
router.register(r"bucket/categories", BucketCategoryViewSet, basename="bucket-categories")
router.register(r"bucket/items", BucketItemViewSet, basename="bucket-items")
router.register(r"notifications", NotificationViewSet, basename="notifications")

urlpatterns = [
    path("", include(router.urls)),
    path("", include("apps.users.urls")),
    path("search/", GlobalSearchAPIView.as_view(), name="global_search"),
    path("dashboard/", DashboardAggregationAPIView.as_view(), name="dashboard_aggregation"),
]

```

---

## myos_backend/apps/api/views.py

- Size: 2783 bytes
- Lines: 71
- Modified: 2026-03-05 21:11:31
- SHA256: 61431a5d5074156cbdd29281d5dec313b67dfe9b054ed827d59d0ae7b48d92ee
- MIME: text/x-script.python

```
from django.db.models import Q
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.api.services.dashboard_service import DashboardService
from apps.diary.models import DiaryEntry
from apps.finance.models import FinanceEntry
from apps.media.models import MediaItem
from apps.projects.models import Project

DECRYPTED_SCAN_LIMIT = 300
SEARCH_RESULT_LIMIT = 10


class GlobalSearchAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        query = request.query_params.get("q", "").strip()
        if not query:
            return Response({"results": {"projects": [], "diary": [], "finance": [], "media": []}})
        normalized_query = query.lower()

        projects = list(
            Project.objects.filter(user=request.user).filter(Q(title__icontains=query) | Q(description__icontains=query)).values(
                "id", "title", "status", "progress"
            )[:SEARCH_RESULT_LIMIT]
        )
        diary = []
        for entry in DiaryEntry.objects.filter(user=request.user).order_by("-date", "-created_at")[:DECRYPTED_SCAN_LIMIT]:
            content = (entry.content or "").lower()
            mood = (entry.mood or "").lower()
            if normalized_query in content or normalized_query in mood:
                diary.append({"id": entry.id, "date": entry.date, "mood": entry.mood})
            if len(diary) >= SEARCH_RESULT_LIMIT:
                break

        finance = []
        for entry in FinanceEntry.objects.filter(user=request.user).order_by("-date", "-created_at")[:DECRYPTED_SCAN_LIMIT]:
            category = (entry.category or "").lower()
            description = (entry.description or "").lower()
            if normalized_query in category or normalized_query in description:
                finance.append({"id": entry.id, "type": entry.type, "amount": entry.amount, "date": entry.date})
            if len(finance) >= SEARCH_RESULT_LIMIT:
                break

        media = list(
            MediaItem.objects.filter(user=request.user).filter(
                Q(title__icontains=query) | Q(description__icontains=query)
            ).values("id", "title", "type", "upload_date")[:SEARCH_RESULT_LIMIT]
        )

        return Response(
            {
                "results": {
                    "projects": projects,
                    "diary": diary,
                    "finance": finance,
                    "media": media,
                }
            }
        )


class DashboardAggregationAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        payload = DashboardService.get_dashboard_payload(request.user)
        return Response(payload)

```

---

## myos_backend/apps/bucket/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/bucket/admin.py

- Size: 494 bytes
- Lines: 15
- Modified: 2026-03-05 18:49:55
- SHA256: d1d66f957f6fb03e428e7bda1de009849877e0fbc4b2c3e9eb10ed3c61970a53
- MIME: text/x-script.python

```
from django.contrib import admin
from .models import BucketCategory, BucketItem


@admin.register(BucketCategory)
class BucketCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "user", "created_at")
    search_fields = ("name", "user__email")


@admin.register(BucketItem)
class BucketItemAdmin(admin.ModelAdmin):
    list_display = ("title", "category", "status", "due_date", "created_at")
    list_filter = ("status",)
    search_fields = ("title", "description", "category__name")

```

---

## myos_backend/apps/bucket/apps.py

- Size: 236 bytes
- Lines: 10
- Modified: 2026-03-05 18:42:41
- SHA256: d0a6f6c6931b3284ebdeaf28888afae3685446957fddc3c2fd8c8c4bd305fefe
- MIME: text/x-script.python

```
from django.apps import AppConfig


class BucketConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.bucket"
    label = "bucket"

    def ready(self):
        from . import signals  # noqa: F401

```

---

## myos_backend/apps/bucket/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/bucket/models.py

- Size: 1122 bytes
- Lines: 38
- Modified: 2026-03-05 18:44:06
- SHA256: e38f379014121b617777931ba2d7997167d33f36d5b5c64a119c9363cc0b0e65
- MIME: text/x-script.python

```
from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class BucketCategory(TimeStampedModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="bucket_categories")
    name = models.CharField(max_length=120)

    class Meta:
        unique_together = ("user", "name")
        ordering = ["name"]

    def __str__(self):
        return self.name


class BucketItem(TimeStampedModel):
    STATUS_PENDING = "pending"
    STATUS_COMPLETED = "completed"

    STATUS_CHOICES = (
        (STATUS_PENDING, "Pending"),
        (STATUS_COMPLETED, "Completed"),
    )

    category = models.ForeignKey(BucketCategory, on_delete=models.CASCADE, related_name="items")
    title = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    due_date = models.DateField(blank=True, null=True)

    class Meta:
        ordering = ["status", "due_date", "created_at"]

    def __str__(self):
        return self.title

```

---

## myos_backend/apps/bucket/permissions.py

- Size: 120 bytes
- Lines: 5
- Modified: 2026-03-05 18:46:03
- SHA256: 8132b1986d53d25821a0b334d5106bff73bb98dbda244a735242f6723ee7c64a
- MIME: text/x-script.python

```
from apps.common.permissions import IsOwnerObjectPermission


class BucketPermission(IsOwnerObjectPermission):
    pass

```

---

## myos_backend/apps/bucket/serializers.py

- Size: 715 bytes
- Lines: 25
- Modified: 2026-03-05 18:44:52
- SHA256: 831c43ef9aaee7db8265d060af687773fe003dd84ca57cc492e6235c45191d5f
- MIME: text/x-script.python

```
from rest_framework import serializers
from .models import BucketCategory, BucketItem


class BucketCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = BucketCategory
        fields = ("id", "user", "name", "created_at", "updated_at")
        read_only_fields = ("id", "user", "created_at", "updated_at")


class BucketItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = BucketItem
        fields = (
            "id",
            "category",
            "title",
            "description",
            "status",
            "due_date",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "created_at", "updated_at")

```

---

## myos_backend/apps/bucket/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/bucket/services/bucket_service.py

- Size: 327 bytes
- Lines: 10
- Modified: 2026-03-05 18:45:35
- SHA256: 3f6de46c0baf387fb5fed67e39dc1a72c410617677a8689b953fe3b382256b55
- MIME: text/x-script.python

```
from apps.bucket.models import BucketItem


class BucketService:
    @staticmethod
    def completion_rate(user):
        qs = BucketItem.objects.filter(category__user=user)
        total = qs.count()
        done = qs.filter(status=BucketItem.STATUS_COMPLETED).count()
        return int((done / total) * 100) if total else 0

```

---

## myos_backend/apps/bucket/signals.py

- Size: 579 bytes
- Lines: 13
- Modified: 2026-03-05 18:49:22
- SHA256: 6191fe078bef985abd9270b23b9e1752b76381463b103cd41326c96f3391540d
- MIME: text/x-script.python

```
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.notifications.models import Notification
from .models import BucketItem


@receiver(post_save, sender=BucketItem)
def notify_bucket_progress(sender, instance, created, **kwargs):
    if created:
        Notification.objects.create(user=instance.category.user, message=f"Bucket item created: {instance.title}")
    elif instance.status == BucketItem.STATUS_COMPLETED:
        Notification.objects.create(user=instance.category.user, message=f"Bucket item completed: {instance.title}")

```

---

## myos_backend/apps/bucket/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/bucket/urls.py

- Size: 17 bytes
- Lines: 1
- Modified: 2026-03-05 18:48:39
- SHA256: 06375ec2cb258edd0b21e7e38b105e9bd24dd2492084fbe6ac81138f719d5db6
- MIME: text/plain

```
urlpatterns = []

```

---

## myos_backend/apps/bucket/views.py

- Size: 1174 bytes
- Lines: 32
- Modified: 2026-03-05 21:11:16
- SHA256: 48a868a8e11b9c3b9729a4dbf246e67742da8a97b04972c8d3437040d6c101f1
- MIME: text/x-script.python

```
from rest_framework import viewsets
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated

from .models import BucketCategory, BucketItem
from .permissions import BucketPermission
from .serializers import BucketCategorySerializer, BucketItemSerializer


class BucketCategoryViewSet(viewsets.ModelViewSet):
    serializer_class = BucketCategorySerializer
    permission_classes = [IsAuthenticated, BucketPermission]

    def get_queryset(self):
        return BucketCategory.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class BucketItemViewSet(viewsets.ModelViewSet):
    serializer_class = BucketItemSerializer
    permission_classes = [IsAuthenticated, BucketPermission]

    def get_queryset(self):
        return BucketItem.objects.filter(category__user=self.request.user)

    def perform_create(self, serializer):
        category = serializer.validated_data["category"]
        if category.user != self.request.user:
            raise PermissionDenied("Cannot add items to another user's category")
        serializer.save()

```

---

## myos_backend/apps/common/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/common/admin.py

- Size: 299 bytes
- Lines: 9
- Modified: 2026-03-05 18:42:12
- SHA256: 024a87db4ee7ef2f9c3d3b24e4ddf74273ccfc9452c7bd3b99ee666f5e5426c4
- MIME: text/x-script.python

```
from django.contrib import admin
from .models import AuditLog


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("created_at", "user", "method", "path", "ip_address")
    search_fields = ("path", "ip_address", "user__email")
    readonly_fields = ("created_at",)

```

---

## myos_backend/apps/common/apps.py

- Size: 170 bytes
- Lines: 7
- Modified: 2026-03-05 18:42:12
- SHA256: 391c2c40d6f2ca0104121d796d060d3fd7a1f3915a0d7fb8c174e24d6710ea81
- MIME: text/x-script.python

```
from django.apps import AppConfig


class CommonConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.common"
    label = "common"

```

---

## myos_backend/apps/common/fields.py

- Size: 1308 bytes
- Lines: 37
- Modified: 2026-03-05 18:42:12
- SHA256: 614001824bc499af9eeebb633fb53a419bee06009fc54d423e8aab5834d2a641
- MIME: text/x-script.python

```
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.db import models
from cryptography.fernet import Fernet, InvalidToken


class EncryptedTextField(models.TextField):
    """Encrypt/decrypt text transparently using Fernet."""

    def _fernet(self):
        key = getattr(settings, "FERNET_KEY", None)
        if not key:
            raise ImproperlyConfigured("FERNET_KEY is required for encrypted fields")
        return Fernet(key.encode("utf-8"))

    def get_prep_value(self, value):
        value = super().get_prep_value(value)
        if value in (None, ""):
            return value
        token = self._fernet().encrypt(str(value).encode("utf-8"))
        return token.decode("utf-8")

    def from_db_value(self, value, expression, connection):
        if value in (None, ""):
            return value
        try:
            return self._fernet().decrypt(value.encode("utf-8")).decode("utf-8")
        except (InvalidToken, ValueError):
            return value

    def to_python(self, value):
        if value in (None, "") or not isinstance(value, str):
            return value
        try:
            return self._fernet().decrypt(value.encode("utf-8")).decode("utf-8")
        except (InvalidToken, ValueError):
            return value

```

---

## myos_backend/apps/common/middleware.py

- Size: 1544 bytes
- Lines: 42
- Modified: 2026-03-05 18:42:12
- SHA256: 3653c000d8f32b13ddcbd323ed3ded0b7fd62ba7a2912125abbd3c72ca26e12a
- MIME: text/x-script.python

```
import logging
from django.conf import settings
from django.http import HttpResponseForbidden

from .models import AuditLog

logger = logging.getLogger("myos.audit")


class LocalhostOnlyMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if getattr(settings, "LOCALHOST_ONLY", False):
            host = request.get_host().split(":")[0]
            if host not in {"127.0.0.1", "localhost"}:
                return HttpResponseForbidden("Localhost-only mode is enabled")
        return self.get_response(request)


class AuditLogMiddleware:
    TRACK_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if request.method in self.TRACK_METHODS and not request.path.startswith("/admin/jsi18n/"):
            user = request.user if getattr(request, "user", None) and request.user.is_authenticated else None
            ip = request.META.get("REMOTE_ADDR")
            AuditLog.objects.create(
                user=user,
                action="api_change",
                path=request.path,
                method=request.method,
                ip_address=ip,
                metadata={"status_code": response.status_code},
            )
            logger.info("audit action=%s method=%s path=%s user=%s", "api_change", request.method, request.path, getattr(user, "id", None))
        return response

```

---

## myos_backend/apps/common/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/common/models.py

- Size: 919 bytes
- Lines: 32
- Modified: 2026-03-05 18:42:12
- SHA256: 2ed5663b54beef4bb39c984829d532cc1e101557c8642d9f8b8a5fb42a3110c8
- MIME: text/x-script.python

```
from django.conf import settings
from django.db import models


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class AuditLog(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="audit_logs",
    )
    action = models.CharField(max_length=64)
    path = models.CharField(max_length=255)
    method = models.CharField(max_length=10)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.method} {self.path} ({self.user_id})"

```

---

## myos_backend/apps/common/permissions.py

- Size: 467 bytes
- Lines: 12
- Modified: 2026-03-05 18:42:12
- SHA256: 44d1efcc65c12efbb13aee53187e4fa0440bfbb70183c4757a09d6921f6442c7
- MIME: text/x-script.python

```
from rest_framework.permissions import BasePermission


class IsOwnerObjectPermission(BasePermission):
    def has_object_permission(self, request, view, obj):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        owner = getattr(obj, "user", None)
        if owner is None and hasattr(obj, "category"):
            owner = getattr(obj.category, "user", None)
        return owner == user or user.is_superuser

```

---

## myos_backend/apps/common/serializers.py

- Size: 46 bytes
- Lines: 1
- Modified: 2026-03-05 18:42:41
- SHA256: 8382eb48d30aa831ff9b3b7dc0995b5d8198beed88be5b58e403d93f4273fcaa
- MIME: text/plain

```
# Common app serializers live in domain apps.

```

---

## myos_backend/apps/common/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/common/signals.py

- Size: 49 bytes
- Lines: 1
- Modified: 2026-03-05 18:42:41
- SHA256: ad6db1693bc54eb1ae1009ac28f30ef8833c50eb8581d7a1d7f7ca99bb5f969e
- MIME: text/plain

```
# Shared signals are implemented in domain apps.

```

---

## myos_backend/apps/common/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/common/urls.py

- Size: 17 bytes
- Lines: 1
- Modified: 2026-03-05 18:42:41
- SHA256: 06375ec2cb258edd0b21e7e38b105e9bd24dd2492084fbe6ac81138f719d5db6
- MIME: text/plain

```
urlpatterns = []

```

---

## myos_backend/apps/common/views.py

- Size: 43 bytes
- Lines: 1
- Modified: 2026-03-05 18:42:41
- SHA256: 5171709cc3cecac6cbe5e08d00d70e63eb70b7a1c74bf3cc7c49e204fd0c8b3e
- MIME: text/plain

```
# Common app does not expose direct views.

```

---

## myos_backend/apps/diary/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/diary/admin.py

- Size: 272 bytes
- Lines: 9
- Modified: 2026-03-05 18:49:55
- SHA256: bf8749de2f867926520b2f1ebc9e8e26d4b283e5b71b905005fa672e5db3b98c
- MIME: text/x-script.python

```
from django.contrib import admin
from .models import DiaryEntry


@admin.register(DiaryEntry)
class DiaryEntryAdmin(admin.ModelAdmin):
    list_display = ("user", "date", "mood", "created_at")
    list_filter = ("date", "mood")
    search_fields = ("user__email", "mood")

```

---

## myos_backend/apps/diary/apps.py

- Size: 233 bytes
- Lines: 10
- Modified: 2026-03-05 18:42:41
- SHA256: 657888ff0d72acb1fd0c3e7b24c1228b696073c65461b261ae6fad1a1f8e176e
- MIME: text/x-script.python

```
from django.apps import AppConfig


class DiaryConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.diary"
    label = "diary"

    def ready(self):
        from . import signals  # noqa: F401

```

---

## myos_backend/apps/diary/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/diary/models.py

- Size: 773 bytes
- Lines: 22
- Modified: 2026-03-05 18:44:06
- SHA256: a1653c04cd6cc2c7aa18d8cfa76c613a218ade8cd336a34f4313e17a51e345a4
- MIME: text/x-script.python

```
from django.conf import settings
from django.db import models

from apps.common.fields import EncryptedTextField
from apps.common.models import TimeStampedModel


class DiaryEntry(TimeStampedModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="diary_entries")
    date = models.DateField()
    content = EncryptedTextField()
    mood = models.CharField(max_length=64, blank=True, default="")
    tags = models.JSONField(default=list, blank=True)

    class Meta:
        ordering = ["-date", "-created_at"]
        constraints = [
            models.UniqueConstraint(fields=["user", "date", "created_at"], name="unique_diary_snapshot"),
        ]

    def __str__(self):
        return f"Diary<{self.user_id}> {self.date}"

```

---

## myos_backend/apps/diary/permissions.py

- Size: 119 bytes
- Lines: 5
- Modified: 2026-03-05 18:46:03
- SHA256: f0e142c2c01fa611bc761259cb6137aa90281880959621fe6a00f7fb860749e5
- MIME: text/x-script.python

```
from apps.common.permissions import IsOwnerObjectPermission


class DiaryPermission(IsOwnerObjectPermission):
    pass

```

---

## myos_backend/apps/diary/serializers.py

- Size: 444 bytes
- Lines: 18
- Modified: 2026-03-05 18:44:52
- SHA256: 8da16a0eb483356bc87cdb598489d328c27d0825a3451b19410314e2658781b8
- MIME: text/x-script.python

```
from rest_framework import serializers
from .models import DiaryEntry


class DiaryEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = DiaryEntry
        fields = (
            "id",
            "user",
            "date",
            "content",
            "mood",
            "tags",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "user", "created_at", "updated_at")

```

---

## myos_backend/apps/diary/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/diary/services/diary_service.py

- Size: 857 bytes
- Lines: 23
- Modified: 2026-03-05 21:11:37
- SHA256: f56e3e55698e7f43189cc0997c2897f3a62a981e64fc2a3e18790e3f847f6b06
- MIME: text/x-script.python

```
from apps.diary.models import DiaryEntry


class DiaryService:
    @staticmethod
    def search(user, query, limit=50, scan_limit=500):
        normalized = (query or "").strip().lower()
        if not normalized:
            return DiaryEntry.objects.none()

        matched_ids = []
        candidates = DiaryEntry.objects.filter(user=user).order_by("-date", "-created_at")[:scan_limit]
        for entry in candidates:
            content = (entry.content or "").lower()
            mood = (entry.mood or "").lower()
            if normalized in content or normalized in mood:
                matched_ids.append(entry.id)
            if len(matched_ids) >= limit:
                break

        if not matched_ids:
            return DiaryEntry.objects.none()
        return DiaryEntry.objects.filter(id__in=matched_ids).order_by("-date", "-created_at")

```

---

## myos_backend/apps/diary/signals.py

- Size: 399 bytes
- Lines: 11
- Modified: 2026-03-05 18:49:22
- SHA256: 2fdd2cd0687d3d81da76b5cd4febfe845a3973666694abc6240058c00d80535c
- MIME: text/x-script.python

```
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.notifications.models import Notification
from .models import DiaryEntry


@receiver(post_save, sender=DiaryEntry)
def notify_diary_entry_saved(sender, instance, created, **kwargs):
    if created:
        Notification.objects.create(user=instance.user, message=f"Diary entry saved for {instance.date}.")

```

---

## myos_backend/apps/diary/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/diary/urls.py

- Size: 17 bytes
- Lines: 1
- Modified: 2026-03-05 18:48:39
- SHA256: 06375ec2cb258edd0b21e7e38b105e9bd24dd2492084fbe6ac81138f719d5db6
- MIME: text/plain

```
urlpatterns = []

```

---

## myos_backend/apps/diary/views.py

- Size: 549 bytes
- Lines: 17
- Modified: 2026-03-05 18:47:56
- SHA256: 30e24e9c28ab0043b84c773077c1bc9994cb68eb5ada69daec79fb488cd928a3
- MIME: text/x-script.python

```
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from .models import DiaryEntry
from .permissions import DiaryPermission
from .serializers import DiaryEntrySerializer


class DiaryEntryViewSet(viewsets.ModelViewSet):
    serializer_class = DiaryEntrySerializer
    permission_classes = [IsAuthenticated, DiaryPermission]

    def get_queryset(self):
        return DiaryEntry.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

```

---

## myos_backend/apps/finance/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/finance/admin.py

- Size: 281 bytes
- Lines: 9
- Modified: 2026-03-05 18:49:55
- SHA256: 645ec0ebe472e9710992c6c50c383e643f80918e4b8bb1157cb7b9188248afaa
- MIME: text/x-script.python

```
from django.contrib import admin
from .models import FinanceEntry


@admin.register(FinanceEntry)
class FinanceEntryAdmin(admin.ModelAdmin):
    list_display = ("user", "type", "amount", "date", "created_at")
    list_filter = ("type", "date")
    search_fields = ("user__email",)

```

---

## myos_backend/apps/finance/apps.py

- Size: 239 bytes
- Lines: 10
- Modified: 2026-03-05 18:42:41
- SHA256: efefae3f26777c94ea16ec12cbd913269eda87b644fb4909895c54232febeb35
- MIME: text/x-script.python

```
from django.apps import AppConfig


class FinanceConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.finance"
    label = "finance"

    def ready(self):
        from . import signals  # noqa: F401

```

---

## myos_backend/apps/finance/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/finance/models.py

- Size: 1024 bytes
- Lines: 31
- Modified: 2026-03-05 18:44:06
- SHA256: 834c89a4953c4dbc2515dcda98b1e9b9aec4eae0c8a9c799685c5cd18153faa2
- MIME: text/x-script.python

```
from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models

from apps.common.fields import EncryptedTextField
from apps.common.models import TimeStampedModel


class FinanceEntry(TimeStampedModel):
    TYPE_INCOME = "income"
    TYPE_EXPENSE = "expense"
    TYPE_SAVINGS = "savings"

    TYPE_CHOICES = (
        (TYPE_INCOME, "Income"),
        (TYPE_EXPENSE, "Expense"),
        (TYPE_SAVINGS, "Savings"),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="finance_entries")
    type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0.01)])
    category = EncryptedTextField()
    description = EncryptedTextField(blank=True, default="")
    date = models.DateField()

    class Meta:
        ordering = ["-date", "-created_at"]

    def __str__(self):
        return f"{self.user_id} {self.type} {self.amount}"

```

---

## myos_backend/apps/finance/permissions.py

- Size: 121 bytes
- Lines: 5
- Modified: 2026-03-05 18:46:03
- SHA256: f9c77dddc87970d12720ee87b177f4ea6309070a73ac2786e07b5c8ebb4f2fbf
- MIME: text/x-script.python

```
from apps.common.permissions import IsOwnerObjectPermission


class FinancePermission(IsOwnerObjectPermission):
    pass

```

---

## myos_backend/apps/finance/serializers.py

- Size: 480 bytes
- Lines: 19
- Modified: 2026-03-05 18:44:52
- SHA256: ebe1207e8a8ec9e932393fafd3ba9d41afad18101216425977772d456ebdc7c3
- MIME: text/x-script.python

```
from rest_framework import serializers
from .models import FinanceEntry


class FinanceEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = FinanceEntry
        fields = (
            "id",
            "user",
            "type",
            "amount",
            "category",
            "description",
            "date",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "user", "created_at", "updated_at")

```

---

## myos_backend/apps/finance/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/finance/services/finance_service.py

- Size: 676 bytes
- Lines: 18
- Modified: 2026-03-05 18:45:35
- SHA256: 35e1277e036bf559a4e767ef21e8972c07b96807468fe4d65227952b39dd9574
- MIME: text/x-script.python

```
from django.db.models import Sum

from apps.finance.models import FinanceEntry


class FinanceService:
    @staticmethod
    def summary_for_user(user):
        qs = FinanceEntry.objects.filter(user=user)
        income = qs.filter(type=FinanceEntry.TYPE_INCOME).aggregate(total=Sum("amount"))["total"] or 0
        expense = qs.filter(type=FinanceEntry.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"] or 0
        savings = qs.filter(type=FinanceEntry.TYPE_SAVINGS).aggregate(total=Sum("amount"))["total"] or 0
        return {
            "income": income,
            "expense": expense,
            "savings": savings,
            "net": income - expense,
        }

```

---

## myos_backend/apps/finance/signals.py

- Size: 568 bytes
- Lines: 15
- Modified: 2026-03-05 18:49:22
- SHA256: 6a1a1175e102f1fbd5de0a4164666185614f6f0e7a3559e411f5f0a45f3d1317
- MIME: text/x-script.python

```
from decimal import Decimal
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.notifications.models import Notification
from .models import FinanceEntry


@receiver(post_save, sender=FinanceEntry)
def notify_high_expense(sender, instance, created, **kwargs):
    if created and instance.type == FinanceEntry.TYPE_EXPENSE and instance.amount >= Decimal("1000"):
        Notification.objects.create(
            user=instance.user,
            message=f"High expense recorded: {instance.amount} on {instance.date}",
        )

```

---

## myos_backend/apps/finance/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/finance/urls.py

- Size: 17 bytes
- Lines: 1
- Modified: 2026-03-05 18:48:39
- SHA256: 06375ec2cb258edd0b21e7e38b105e9bd24dd2492084fbe6ac81138f719d5db6
- MIME: text/plain

```
urlpatterns = []

```

---

## myos_backend/apps/finance/views.py

- Size: 563 bytes
- Lines: 17
- Modified: 2026-03-05 18:47:56
- SHA256: 04bbd4e38b934a56ac94b9441e5bbb8f6d5e1e407ce5f8adb2471d1baec7abc1
- MIME: text/x-script.python

```
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from .models import FinanceEntry
from .permissions import FinancePermission
from .serializers import FinanceEntrySerializer


class FinanceEntryViewSet(viewsets.ModelViewSet):
    serializer_class = FinanceEntrySerializer
    permission_classes = [IsAuthenticated, FinancePermission]

    def get_queryset(self):
        return FinanceEntry.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

```

---

## myos_backend/apps/media/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/media/admin.py

- Size: 280 bytes
- Lines: 9
- Modified: 2026-03-05 18:49:55
- SHA256: e50c77166cdfc9e1114d69498378251d2516f92731f683f09b4cd9fd0dd23cf8
- MIME: text/x-script.python

```
from django.contrib import admin
from .models import MediaItem


@admin.register(MediaItem)
class MediaItemAdmin(admin.ModelAdmin):
    list_display = ("title", "user", "type", "upload_date")
    list_filter = ("type",)
    search_fields = ("title", "description", "user__email")

```

---

## myos_backend/apps/media/apps.py

- Size: 241 bytes
- Lines: 10
- Modified: 2026-03-05 18:42:41
- SHA256: ca0e386d4721514ef7de52ba0fb9f328bcee1fc042f811aed35e318e9e66f44b
- MIME: text/x-script.python

```
from django.apps import AppConfig


class MediaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.media"
    label = "media_library"

    def ready(self):
        from . import signals  # noqa: F401

```

---

## myos_backend/apps/media/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/media/models.py

- Size: 1460 bytes
- Lines: 46
- Modified: 2026-03-05 18:44:06
- SHA256: e46a23cd26acadc45b481c635c04ede977481bcb8a3f7c5c7bedc8c7105c2745
- MIME: text/x-script.python

```
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from apps.common.models import TimeStampedModel


ALLOWED_CONTENT_TYPES = {
    "image": {"image/jpeg", "image/png", "image/webp"},
    "video": {"video/mp4", "video/webm"},
    "audio": {"audio/mpeg", "audio/wav", "audio/ogg"},
}


def media_upload_path(instance, filename):
    return f"user_{instance.user_id}/{instance.type}/{filename}"


class MediaItem(TimeStampedModel):
    TYPE_IMAGE = "image"
    TYPE_VIDEO = "video"
    TYPE_AUDIO = "audio"

    TYPE_CHOICES = (
        (TYPE_IMAGE, "Image"),
        (TYPE_VIDEO, "Video"),
        (TYPE_AUDIO, "Audio"),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="media_items")
    type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    title = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to=media_upload_path)
    upload_date = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-upload_date"]

    def clean(self):
        file_content_type = getattr(self.file.file, "content_type", None)
        if file_content_type and file_content_type not in ALLOWED_CONTENT_TYPES.get(self.type, set()):
            raise ValidationError("Invalid media content type for selected media type")

    def __str__(self):
        return self.title

```

---

## myos_backend/apps/media/permissions.py

- Size: 119 bytes
- Lines: 5
- Modified: 2026-03-05 18:46:03
- SHA256: ab247bad358c9f445acc199e374d7e1ede5dc0c27687ee31b156558c8d2b76b1
- MIME: text/x-script.python

```
from apps.common.permissions import IsOwnerObjectPermission


class MediaPermission(IsOwnerObjectPermission):
    pass

```

---

## myos_backend/apps/media/serializers.py

- Size: 698 bytes
- Lines: 25
- Modified: 2026-03-05 18:44:52
- SHA256: e9fa232d34341740efc4e51198df519022d99a4b636633bc33cacaa8b7e0cb36
- MIME: text/x-script.python

```
from rest_framework import serializers
from .models import MediaItem


class MediaItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = MediaItem
        fields = (
            "id",
            "user",
            "type",
            "title",
            "description",
            "file",
            "upload_date",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "user", "upload_date", "created_at", "updated_at")

    def validate_file(self, value):
        max_size = 25 * 1024 * 1024
        if value.size > max_size:
            raise serializers.ValidationError("File too large. Max size is 25MB")
        return value

```

---

## myos_backend/apps/media/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/media/services/media_service.py

- Size: 183 bytes
- Lines: 7
- Modified: 2026-03-05 18:45:35
- SHA256: 2f06b86539ca0fce6a2043c77c1d504ad11e9c68727f82bedb219b3ea58562ee
- MIME: text/x-script.python

```
from apps.media.models import MediaItem


class MediaService:
    @staticmethod
    def by_type(user, media_type):
        return MediaItem.objects.filter(user=user, type=media_type)

```

---

## myos_backend/apps/media/signals.py

- Size: 388 bytes
- Lines: 11
- Modified: 2026-03-05 18:49:22
- SHA256: 5b93a40d3380c7b988ddbb03633b1ba41cdae65c6fd61e41b5deae4e9ee7d861
- MIME: text/x-script.python

```
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.notifications.models import Notification
from .models import MediaItem


@receiver(post_save, sender=MediaItem)
def notify_media_uploaded(sender, instance, created, **kwargs):
    if created:
        Notification.objects.create(user=instance.user, message=f"Media uploaded: {instance.title}")

```

---

## myos_backend/apps/media/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/media/urls.py

- Size: 17 bytes
- Lines: 1
- Modified: 2026-03-05 18:48:39
- SHA256: 06375ec2cb258edd0b21e7e38b105e9bd24dd2492084fbe6ac81138f719d5db6
- MIME: text/plain

```
urlpatterns = []

```

---

## myos_backend/apps/media/views.py

- Size: 544 bytes
- Lines: 17
- Modified: 2026-03-05 18:47:56
- SHA256: f27afb2c143e88db34c7d38494a7b13b40634a9a190b5630701d3b6b946c5b40
- MIME: text/x-script.python

```
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from .models import MediaItem
from .permissions import MediaPermission
from .serializers import MediaItemSerializer


class MediaItemViewSet(viewsets.ModelViewSet):
    serializer_class = MediaItemSerializer
    permission_classes = [IsAuthenticated, MediaPermission]

    def get_queryset(self):
        return MediaItem.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

```

---

## myos_backend/apps/notifications/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/notifications/admin.py

- Size: 277 bytes
- Lines: 9
- Modified: 2026-03-05 18:49:55
- SHA256: cb7c4734562b3aae64bcbcfaa9c1f1da329984a78a6cb7eea0609d2a0d39ddf5
- MIME: text/x-script.python

```
from django.contrib import admin
from .models import Notification


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user", "message", "read", "created_at")
    list_filter = ("read",)
    search_fields = ("user__email", "message")

```

---

## myos_backend/apps/notifications/apps.py

- Size: 191 bytes
- Lines: 7
- Modified: 2026-03-05 18:42:41
- SHA256: 6d45c15d7e382013a3da6545daa71c35a5610957e6db1ccbbcd03428b79b3a0f
- MIME: text/x-script.python

```
from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.notifications"
    label = "notifications"

```

---

## myos_backend/apps/notifications/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/notifications/models.py

- Size: 498 bytes
- Lines: 16
- Modified: 2026-03-05 18:44:06
- SHA256: 4b14d3a6988d398d3b1274fce1463da4bbb7decf9aab3fd3d957b400587e3bb1
- MIME: text/x-script.python

```
from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class Notification(TimeStampedModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    message = models.CharField(max_length=255)
    read = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Notification<{self.user_id}> {self.message[:40]}"

```

---

## myos_backend/apps/notifications/permissions.py

- Size: 126 bytes
- Lines: 5
- Modified: 2026-03-05 18:46:03
- SHA256: 7c9c6d0cb90f3cdfcb3ca5720035557e933d66f776b860b8e6b050a49a7e1092
- MIME: text/x-script.python

```
from apps.common.permissions import IsOwnerObjectPermission


class NotificationPermission(IsOwnerObjectPermission):
    pass

```

---

## myos_backend/apps/notifications/serializers.py

- Size: 327 bytes
- Lines: 9
- Modified: 2026-03-05 18:44:52
- SHA256: c5b48d5823ee93d23b7dc7271bee9dc0d389fdd81e0b7bda8056f64bdef65245
- MIME: text/x-script.python

```
from rest_framework import serializers
from .models import Notification


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ("id", "user", "message", "read", "created_at", "updated_at")
        read_only_fields = ("id", "user", "created_at", "updated_at")

```

---

## myos_backend/apps/notifications/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/notifications/services/notification_service.py

- Size: 321 bytes
- Lines: 11
- Modified: 2026-03-05 18:45:35
- SHA256: b2fc3f97cf08889ad5b6bb07fbe049cacb860ad9dd0de1c5d113ecf879a63e05
- MIME: text/x-script.python

```
from apps.notifications.models import Notification


class NotificationService:
    @staticmethod
    def create(user, message):
        return Notification.objects.create(user=user, message=message)

    @staticmethod
    def unread_count(user):
        return Notification.objects.filter(user=user, read=False).count()

```

---

## myos_backend/apps/notifications/signals.py

- Size: 55 bytes
- Lines: 1
- Modified: 2026-03-05 18:49:22
- SHA256: d836c3444255971834397940c3b492b635dab6a38a0d3278296ff8f192b15845
- MIME: text/plain

```
# Notification app is signal target for other modules.

```

---

## myos_backend/apps/notifications/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/notifications/urls.py

- Size: 17 bytes
- Lines: 1
- Modified: 2026-03-05 18:48:39
- SHA256: 06375ec2cb258edd0b21e7e38b105e9bd24dd2492084fbe6ac81138f719d5db6
- MIME: text/plain

```
urlpatterns = []

```

---

## myos_backend/apps/notifications/views.py

- Size: 1088 bytes
- Lines: 26
- Modified: 2026-03-05 18:47:56
- SHA256: d96ec10fa1c82187284c80a3762151136ccb9e606662e965bb67665daf662919
- MIME: text/x-script.python

```
from rest_framework import mixins, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import Notification
from .permissions import NotificationPermission
from .serializers import NotificationSerializer


class NotificationViewSet(mixins.ListModelMixin, mixins.UpdateModelMixin, viewsets.GenericViewSet):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated, NotificationPermission]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)

    @action(detail=False, methods=["get"], url_path="unread-count")
    def unread_count(self, request):
        count = self.get_queryset().filter(read=False).count()
        return Response({"unread": count})

    @action(detail=False, methods=["post"], url_path="mark-all-read")
    def mark_all_read(self, request):
        self.get_queryset().filter(read=False).update(read=True)
        return Response({"detail": "All notifications marked as read"})

```

---

## myos_backend/apps/projects/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/projects/admin.py

- Size: 301 bytes
- Lines: 9
- Modified: 2026-03-05 18:49:55
- SHA256: 0e42dd921c2d6e8658e16dcfd2857bec22ed97e7cad5994c379914f99e9ef806
- MIME: text/x-script.python

```
from django.contrib import admin
from .models import Project


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("title", "user", "status", "progress", "start_date", "end_date")
    list_filter = ("status",)
    search_fields = ("title", "description", "user__email")

```

---

## myos_backend/apps/projects/apps.py

- Size: 242 bytes
- Lines: 10
- Modified: 2026-03-05 18:42:41
- SHA256: 12e5996d89a83d017543bae9d11603bd9f99084b74e3ce7036422632c1bda79c
- MIME: text/x-script.python

```
from django.apps import AppConfig


class ProjectsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.projects"
    label = "projects"

    def ready(self):
        from . import signals  # noqa: F401

```

---

## myos_backend/apps/projects/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/projects/models.py

- Size: 1153 bytes
- Lines: 33
- Modified: 2026-03-05 18:44:06
- SHA256: f973afd188343193d30ef06d32776847c32d57d33847c8dac2349a024d17fb09
- MIME: text/x-script.python

```
from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from apps.common.models import TimeStampedModel


class Project(TimeStampedModel):
    STATUS_IDEA = "idea"
    STATUS_PENDING = "pending"
    STATUS_IN_PROGRESS = "in_progress"
    STATUS_COMPLETED = "completed"

    STATUS_CHOICES = (
        (STATUS_IDEA, "Idea"),
        (STATUS_PENDING, "Pending"),
        (STATUS_IN_PROGRESS, "In Progress"),
        (STATUS_COMPLETED, "Completed"),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="projects")
    title = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_IDEA)
    progress = models.PositiveSmallIntegerField(default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

```

---

## myos_backend/apps/projects/permissions.py

- Size: 121 bytes
- Lines: 5
- Modified: 2026-03-05 18:46:03
- SHA256: b61e1da1d4acac5f0db422e470ce783c70ee93bb8d2dafe4b7388bcf8b2e1c0a
- MIME: text/x-script.python

```
from apps.common.permissions import IsOwnerObjectPermission


class ProjectPermission(IsOwnerObjectPermission):
    pass

```

---

## myos_backend/apps/projects/serializers.py

- Size: 496 bytes
- Lines: 20
- Modified: 2026-03-05 18:44:52
- SHA256: 4a8d38a8237d57f34e919657fbec89d4467c97c2b76901473ec299aa728be02f
- MIME: text/x-script.python

```
from rest_framework import serializers
from .models import Project


class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = (
            "id",
            "user",
            "title",
            "description",
            "status",
            "progress",
            "start_date",
            "end_date",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "user", "created_at", "updated_at")

```

---

## myos_backend/apps/projects/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/projects/services/project_service.py

- Size: 514 bytes
- Lines: 13
- Modified: 2026-03-05 18:45:35
- SHA256: 0fa4c3a4ddf297937b9bcf2756839a39dd02c19f801e4c3dcaf9a84eb968e395
- MIME: text/x-script.python

```
from apps.projects.models import Project


class ProjectService:
    @staticmethod
    def update_progress(project: Project, progress: int):
        project.progress = max(0, min(100, progress))
        if project.progress == 100:
            project.status = Project.STATUS_COMPLETED
        elif project.progress > 0 and project.status == Project.STATUS_IDEA:
            project.status = Project.STATUS_IN_PROGRESS
        project.save(update_fields=["progress", "status", "updated_at"])
        return project

```

---

## myos_backend/apps/projects/signals.py

- Size: 555 bytes
- Lines: 13
- Modified: 2026-03-05 18:49:22
- SHA256: 113e8364c79f88fabe0e06721cb8743342e51b37164df4ad88442b08b2d55193
- MIME: text/x-script.python

```
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.notifications.models import Notification
from .models import Project


@receiver(post_save, sender=Project)
def notify_project_updates(sender, instance, created, **kwargs):
    if created:
        Notification.objects.create(user=instance.user, message=f"Project '{instance.title}' created.")
    elif instance.status == Project.STATUS_COMPLETED:
        Notification.objects.create(user=instance.user, message=f"Project '{instance.title}' marked completed.")

```

---

## myos_backend/apps/projects/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/projects/urls.py

- Size: 17 bytes
- Lines: 1
- Modified: 2026-03-05 18:48:39
- SHA256: 06375ec2cb258edd0b21e7e38b105e9bd24dd2492084fbe6ac81138f719d5db6
- MIME: text/plain

```
urlpatterns = []

```

---

## myos_backend/apps/projects/views.py

- Size: 538 bytes
- Lines: 17
- Modified: 2026-03-05 18:47:56
- SHA256: 6e3f3f417be9939ba4784defa7f42bfb7d562be199c79451e83d8edf1f251e23
- MIME: text/x-script.python

```
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from .models import Project
from .permissions import ProjectPermission
from .serializers import ProjectSerializer


class ProjectViewSet(viewsets.ModelViewSet):
    serializer_class = ProjectSerializer
    permission_classes = [IsAuthenticated, ProjectPermission]

    def get_queryset(self):
        return Project.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

```

---

## myos_backend/apps/users/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/users/admin.py

- Size: 1340 bytes
- Lines: 34
- Modified: 2026-03-05 18:49:55
- SHA256: 0f03d08f291e4b653e9f1bff02527a55a71557bf6049808aed689ccb685a335b
- MIME: text/x-script.python

```
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import CustomUser, UserOTP


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ("email", "first_name", "last_name", "is_staff", "is_active", "is_email_verified")
    ordering = ("email",)
    search_fields = ("email", "first_name", "last_name")
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Personal", {"fields": ("first_name", "last_name", "avatar", "timezone", "preferences")}),
        ("Security", {"fields": ("is_email_verified", "two_factor_enabled")}),
        ("Permissions", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Important dates", {"fields": ("last_login", "created_at", "updated_at")}),
    )
    readonly_fields = ("created_at", "updated_at", "last_login")
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "first_name", "last_name", "password1", "password2", "is_staff", "is_active"),
            },
        ),
    )


@admin.register(UserOTP)
class UserOTPAdmin(admin.ModelAdmin):
    list_display = ("user", "purpose", "code", "expires_at", "is_used", "created_at")
    search_fields = ("user__email", "purpose", "code")

```

---

## myos_backend/apps/users/apps.py

- Size: 233 bytes
- Lines: 10
- Modified: 2026-03-05 18:42:41
- SHA256: 5f9aabf781705e7b474cc4fc0006c3d4854c6b8afbb573361c682a6fb8a906a9
- MIME: text/x-script.python

```
from django.apps import AppConfig


class UsersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.users"
    label = "users"

    def ready(self):
        from . import signals  # noqa: F401

```

---

## myos_backend/apps/users/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/users/models.py

- Size: 2466 bytes
- Lines: 70
- Modified: 2026-03-05 18:44:06
- SHA256: ff2bb45cb85e7f25ad72804fac9bb8e240676caff813c9769e2e6ec33e8d19a4
- MIME: text/x-script.python

```
from datetime import timedelta
from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone

from apps.common.models import TimeStampedModel


class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Users must have an email address")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractBaseUser, PermissionsMixin, TimeStampedModel):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True)
    timezone = models.CharField(max_length=64, default="UTC")
    preferences = models.JSONField(default=dict, blank=True)

    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_email_verified = models.BooleanField(default=False)
    two_factor_enabled = models.BooleanField(default=False)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name", "last_name"]

    objects = CustomUserManager()

    def __str__(self):
        return self.email


class UserOTP(TimeStampedModel):
    PURPOSE_CHOICES = (
        ("signup", "Signup Verification"),
        ("login_2fa", "Login 2FA"),
        ("password_reset", "Password Reset"),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="otps")
    purpose = models.CharField(max_length=20, choices=PURPOSE_CHOICES)
    code = models.CharField(max_length=6)
    expires_at = models.DateTimeField()
    is_used = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]

    @classmethod
    def default_expiry(cls):
        return timezone.now() + timedelta(minutes=10)

    def is_expired(self):
        return timezone.now() > self.expires_at

```

---

## myos_backend/apps/users/permissions.py

- Size: 117 bytes
- Lines: 5
- Modified: 2026-03-05 18:46:03
- SHA256: 10de7bc91e64695d9a03c7a24ea8a6f686c40d1faeb307ccc98150213066df7a
- MIME: text/x-script.python

```
from apps.common.permissions import IsOwnerObjectPermission


class IsSelfOrAdmin(IsOwnerObjectPermission):
    pass

```

---

## myos_backend/apps/users/serializers.py

- Size: 3193 bytes
- Lines: 98
- Modified: 2026-03-05 21:10:57
- SHA256: 12459aa21a7cd866273f21421ed5743815d47ae678ca4ce1533486854f5a57c1
- MIME: text/x-script.python

```
from django.contrib.auth import get_user_model
from rest_framework import serializers
from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import UserOTP
from .services.auth_service import AuthService

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            "id",
            "first_name",
            "last_name",
            "email",
            "avatar",
            "timezone",
            "preferences",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "created_at", "updated_at")


class SignupSerializer(serializers.Serializer):
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    email = serializers.EmailField()
    password = serializers.CharField(min_length=8, write_only=True)
    timezone = serializers.CharField(max_length=64, required=False, default="UTC")

    def validate_email(self, value):
        normalized = value.strip().lower()
        if User.objects.filter(email__iexact=normalized).exists():
            raise serializers.ValidationError("Email already registered")
        return normalized


class Request2FASerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(min_length=8, write_only=True, trim_whitespace=False)


class OTPVerifySerializer(serializers.Serializer):
    email = serializers.EmailField()
    code = serializers.CharField(max_length=6)


class PasswordResetRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    uid = serializers.CharField()
    token = serializers.CharField()
    new_password = serializers.CharField(min_length=8)


class SecureTokenObtainPairSerializer(TokenObtainPairSerializer):
    otp_code = serializers.CharField(max_length=6, required=False, allow_blank=True)

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["is_email_verified"] = bool(user.is_email_verified)
        return token

    def validate(self, attrs):
        otp_code = (attrs.get("otp_code") or "").strip()
        data = super().validate(attrs)
        user = self.user

        if not user.is_email_verified:
            raise AuthenticationFailed("Verify your email before signing in.")

        if user.two_factor_enabled:
            if not otp_code:
                raise AuthenticationFailed("2FA code required.")
            verified_user = AuthService.verify_otp(
                email=user.email,
                code=otp_code,
                purpose="login_2fa",
            )
            if not verified_user or verified_user.pk != user.pk:
                raise AuthenticationFailed("Invalid or expired 2FA code.")

        return data


class UserOTPSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserOTP
        fields = ("id", "purpose", "code", "expires_at", "is_used", "created_at")
        read_only_fields = fields

```

---

## myos_backend/apps/users/services/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:50:42
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/users/services/auth_service.py

- Size: 2683 bytes
- Lines: 83
- Modified: 2026-03-05 18:45:35
- SHA256: d59c67218e3b9042b41c12ccf953867ecf093f7956a7bc6bf60048a6e0abdba5
- MIME: text/x-script.python

```
import random
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.core.mail import send_mail
from django.utils import timezone
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes

from apps.users.models import UserOTP

User = get_user_model()


class AuthService:
    @staticmethod
    def _generate_otp_code() -> str:
        return f"{random.randint(0, 999999):06d}"

    @classmethod
    def signup(cls, validated_data):
        user = User.objects.create_user(
            email=validated_data["email"],
            password=validated_data["password"],
            first_name=validated_data["first_name"],
            last_name=validated_data["last_name"],
            timezone=validated_data.get("timezone", "UTC"),
            is_active=True,
            is_email_verified=False,
        )
        cls.send_otp(user, "signup")
        return user

    @classmethod
    def send_otp(cls, user, purpose="signup"):
        code = cls._generate_otp_code()
        UserOTP.objects.create(
            user=user,
            purpose=purpose,
            code=code,
            expires_at=UserOTP.default_expiry(),
        )
        send_mail(
            subject=f"MyOS {purpose} verification code",
            message=f"Your verification code is: {code}",
            from_email=None,
            recipient_list=[user.email],
            fail_silently=True,
        )
        return code

    @staticmethod
    def verify_otp(email, code, purpose="signup"):
        user = User.objects.filter(email=email).first()
        if not user:
            return None
        otp = (
            UserOTP.objects.filter(user=user, code=code, purpose=purpose, is_used=False)
            .order_by("-created_at")
            .first()
        )
        if not otp or otp.is_expired():
            return None
        otp.is_used = True
        otp.save(update_fields=["is_used", "updated_at"])
        if purpose == "signup":
            user.is_email_verified = True
            user.save(update_fields=["is_email_verified", "updated_at"])
        return user

    @staticmethod
    def request_password_reset(email):
        user = User.objects.filter(email=email).first()
        if not user:
            return
        token = PasswordResetTokenGenerator().make_token(user)
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        send_mail(
            subject="MyOS Password Reset",
            message=f"Use this uid: {uid}\nUse this token: {token}",
            from_email=None,
            recipient_list=[email],
            fail_silently=True,
        )

```

---

## myos_backend/apps/users/signals.py

- Size: 406 bytes
- Lines: 11
- Modified: 2026-03-05 18:49:22
- SHA256: f2a83f7f9a5a2d829023281e99b5282220124286e7c380353c065606b8b2bb5b
- MIME: text/x-script.python

```
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.notifications.models import Notification
from .models import CustomUser


@receiver(post_save, sender=CustomUser)
def create_welcome_notification(sender, instance, created, **kwargs):
    if created:
        Notification.objects.create(user=instance, message="Welcome to MyOS. Your secure dashboard is ready.")

```

---

## myos_backend/apps/users/tests/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/apps/users/urls.py

- Size: 1234 bytes
- Lines: 27
- Modified: 2026-03-05 18:51:31
- SHA256: 6d68a747e116e891933a61d76ec76723d3ff3cea8037c0d37502ec1dee0f1089
- MIME: text/x-script.python

```
from django.urls import path

from .views import (
    AppleSocialLoginAPIView,
    GoogleSocialLoginAPIView,
    PasswordResetConfirmAPIView,
    PasswordResetRequestAPIView,
    Request2FAAPIView,
    SecureTokenObtainPairView,
    SecureTokenRefreshView,
    SignupAPIView,
    Verify2FAAPIView,
    VerifyOTPAPIView,
)

urlpatterns = [
    path("auth/signup/", SignupAPIView.as_view(), name="signup"),
    path("auth/verify-otp/", VerifyOTPAPIView.as_view(), name="verify_otp"),
    path("auth/2fa/request/", Request2FAAPIView.as_view(), name="request_2fa"),
    path("auth/2fa/verify/", Verify2FAAPIView.as_view(), name="verify_2fa"),
    path("auth/token/", SecureTokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("auth/token/refresh/", SecureTokenRefreshView.as_view(), name="token_refresh"),
    path("auth/password-reset/request/", PasswordResetRequestAPIView.as_view(), name="password_reset_request"),
    path("auth/password-reset/confirm/", PasswordResetConfirmAPIView.as_view(), name="password_reset_confirm"),
    path("auth/social/google/", GoogleSocialLoginAPIView.as_view(), name="google_social_login"),
    path("auth/social/apple/", AppleSocialLoginAPIView.as_view(), name="apple_social_login"),
]

```

---

## myos_backend/apps/users/views.py

- Size: 6256 bytes
- Lines: 164
- Modified: 2026-03-06 21:03:39
- SHA256: 04238558fee686d506ca0aad305e34ba60c806be2966ffe7ccc06fab495e3902
- MIME: text/x-script.python

```
from django.contrib.auth import authenticate, get_user_model
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.decorators import method_decorator
from django.utils.encoding import force_str
from django.utils.http import urlsafe_base64_decode
from django_ratelimit.decorators import ratelimit
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from .serializers import (
    OTPVerifySerializer,
    PasswordResetConfirmSerializer,
    PasswordResetRequestSerializer,
    Request2FASerializer,
    SecureTokenObtainPairSerializer,
    SignupSerializer,
    UserSerializer,
)
from .services.auth_service import AuthService

User = get_user_model()


class SecureTokenObtainPairView(TokenObtainPairView):
    permission_classes = [AllowAny]
    serializer_class = SecureTokenObtainPairSerializer


class SecureTokenRefreshView(TokenRefreshView):
    permission_classes = [AllowAny]


class SignupAPIView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="5/m", method="POST", block=True))
    def post(self, request):
        serializer = SignupSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = AuthService.signup(serializer.validated_data)
        return Response({"detail": "Signup created. Verify OTP sent to email.", "user_id": user.id}, status=201)


class VerifyOTPAPIView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="10/m", method="POST", block=True))
    def post(self, request):
        serializer = OTPVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = AuthService.verify_otp(
            email=serializer.validated_data["email"],
            code=serializer.validated_data["code"],
            purpose="signup",
        )
        if not user:
            return Response({"detail": "Invalid or expired OTP"}, status=400)
        return Response({"detail": "OTP verified", "is_email_verified": user.is_email_verified})


class Request2FAAPIView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="5/m", method="POST", block=True))
    def post(self, request):
        serializer = Request2FASerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = authenticate(
            request,
            email=serializer.validated_data["email"],
            password=serializer.validated_data["password"],
        )
        if not user:
            return Response({"detail": "Invalid credentials"}, status=400)
        if not user.is_email_verified:
            return Response({"detail": "Verify email before requesting 2FA code"}, status=403)
        AuthService.send_otp(user, purpose="login_2fa")
        return Response({"detail": "2FA code sent"})


class Verify2FAAPIView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="10/m", method="POST", block=True))
    def post(self, request):
        serializer = OTPVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = AuthService.verify_otp(
            email=serializer.validated_data["email"],
            code=serializer.validated_data["code"],
            purpose="login_2fa",
        )
        if not user:
            return Response({"detail": "Invalid or expired 2FA code"}, status=400)
        return Response({"detail": "2FA verified"})


class PasswordResetRequestAPIView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="5/m", method="POST", block=True))
    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        AuthService.request_password_reset(serializer.validated_data["email"])
        return Response({"detail": "If account exists, reset instructions were sent."})


class PasswordResetConfirmAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            uid = force_str(urlsafe_base64_decode(serializer.validated_data["uid"]))
            user = User.objects.get(pk=uid)
        except Exception:
            return Response({"detail": "Invalid reset payload"}, status=400)

        token = serializer.validated_data["token"]
        if not PasswordResetTokenGenerator().check_token(user, token):
            return Response({"detail": "Invalid token"}, status=400)

        user.set_password(serializer.validated_data["new_password"])
        user.save(update_fields=["password", "updated_at"])
        return Response({"detail": "Password reset successful"})


class GoogleSocialLoginAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        token = request.data.get("id_token")
        if not token:
            return Response({"detail": "id_token required"}, status=400)
        return Response({"detail": "Google social login is not configured on this server."}, status=503)


class AppleSocialLoginAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        token = request.data.get("id_token")
        if not token:
            return Response({"detail": "id_token required"}, status=400)
        return Response({"detail": "Apple social login is not configured on this server."}, status=503)


class UserProfileViewSet(mixins.RetrieveModelMixin, mixins.UpdateModelMixin, viewsets.GenericViewSet):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

    @action(detail=False, methods=["get"], url_path="me")
    def me(self, request):
        serializer = self.get_serializer(request.user)
        return Response(serializer.data)

```

---

## myos_backend/docker-compose.yml

- Size: 501 bytes
- Lines: 28
- Modified: 2026-03-05 18:52:04
- SHA256: 37792ab7675cf31716e9a193823529609d7cfc6314ae9a881ecf8583d69f0408
- MIME: text/plain

```
version: "3.9"

services:
  db:
    image: postgres:16
    environment:
      POSTGRES_DB: myos
      POSTGRES_USER: myos
      POSTGRES_PASSWORD: myos
    volumes:
      - postgres_data:/var/lib/postgresql/data

  web:
    build: .
    command: gunicorn myos_backend.wsgi:application --bind 0.0.0.0:8000 --workers 3
    env_file:
      - .env
    depends_on:
      - db
    ports:
      - "8000:8000"
    volumes:
      - .:/app
      - media_data:/app/media

volumes:
  postgres_data:
  media_data:

```

---

## myos_backend/manage.py

- Size: 397 bytes
- Lines: 16
- Modified: 2026-03-05 18:40:17
- SHA256: 9069f1520ac3e710777a667922379c41dd26a55b5b3ffa74832f449cb94f015f
- MIME: text/x-script.python

```
#!/usr/bin/env python
import os
import sys


def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myos_backend.settings.development")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError("Couldn't import Django.") from exc
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()

```

---

## myos_backend/myos_backend/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/myos_backend/asgi.py

- Size: 183 bytes
- Lines: 5
- Modified: 2026-03-05 18:40:17
- SHA256: e29665a10742cbdddf2a02a22b8162d1c7e77495fe6495a5fc6e0552a106cb42
- MIME: text/x-script.python

```
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myos_backend.settings.development")
application = get_asgi_application()

```

---

## myos_backend/myos_backend/settings/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 18:38:37
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_backend/myos_backend/settings/base.py

- Size: 7305 bytes
- Lines: 225
- Modified: 2026-03-06 21:06:07
- SHA256: 80927bfd6b77df0e793b1e8c6b787922a19764316f59b9a85e742e928df55a1b
- MIME: text/x-script.python

```
import os
from datetime import timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]


def _parse_dotenv(path: Path):
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def env(name, default=None):
    return os.getenv(name, default)


def env_bool(name, default=False):
    value = env(name)
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def env_int(name, default=0):
    value = env(name)
    if value is None or value == "":
        return default
    return int(value)


def env_list(name, default=None):
    value = env(name)
    if value is None:
        return default[:] if isinstance(default, list) else (default or [])
    return [item.strip() for item in value.split(",") if item.strip()]


_parse_dotenv(BASE_DIR / ".env")

SECRET_KEY = env("DJANGO_SECRET_KEY", "change-me-before-production")
DEBUG = env_bool("DJANGO_DEBUG", False)
ALLOWED_HOSTS = env_list("DJANGO_ALLOWED_HOSTS", ["127.0.0.1", "localhost"])
FERNET_KEY = env("FERNET_KEY", "8wqYkBpujISiFDUFxIr05oig3NbS1Ry6j8TDIrS9KuA=")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "rest_framework_simplejwt.token_blacklist",
    "django_filters",
    "corsheaders",
    "apps.common.apps.CommonConfig",
    "apps.users.apps.UsersConfig",
    "apps.projects.apps.ProjectsConfig",
    "apps.finance.apps.FinanceConfig",
    "apps.diary.apps.DiaryConfig",
    "apps.media.apps.MediaConfig",
    "apps.bucket.apps.BucketConfig",
    "apps.notifications.apps.NotificationsConfig",
    "apps.api.apps.ApiConfig",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "apps.common.middleware.LocalhostOnlyMiddleware",
    "apps.common.middleware.AuditLogMiddleware",
]

ROOT_URLCONF = "myos_backend.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "myos_backend.wsgi.application"
ASGI_APPLICATION = "myos_backend.asgi.application"

database_engine = env("DATABASE_ENGINE", "sqlite").lower()
if database_engine == "postgres":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": env("DATABASE_NAME", "myos"),
            "USER": env("DATABASE_USER", "myos"),
            "PASSWORD": env("DATABASE_PASSWORD", "myos"),
            "HOST": env("DATABASE_HOST", "127.0.0.1"),
            "PORT": env("DATABASE_PORT", "5432"),
            "CONN_MAX_AGE": 60,
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

AUTH_USER_MODEL = "users.CustomUser"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework_simplejwt.authentication.JWTAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ),
    "DEFAULT_PERMISSION_CLASSES": (
        "rest_framework.permissions.IsAuthenticated",
    ),
    "DEFAULT_FILTER_BACKENDS": (
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ),
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 20,
}

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=env_int("ACCESS_TOKEN_MINUTES", 5)),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=env_int("REFRESH_TOKEN_DAYS", 1)),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "UPDATE_LAST_LOGIN": True,
    "AUTH_HEADER_TYPES": ("Bearer",),
}

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
FILE_UPLOAD_PERMISSIONS = 0o640
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

CORS_ALLOWED_ORIGINS = env_list("CORS_ALLOWED_ORIGINS", [])

EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
EMAIL_HOST = env("EMAIL_HOST", "localhost")
EMAIL_PORT = env_int("EMAIL_PORT", 25)
EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", False)
EMAIL_HOST_USER = env("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", "")
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", "MyOS <no-reply@myos.local>")

SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SECURE_HSTS_SECONDS = env_int("SECURE_HSTS_SECONDS", 0)
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
X_FRAME_OPTIONS = "DENY"
SECURE_CONTENT_TYPE_NOSNIFF = True
CSRF_COOKIE_HTTPONLY = True
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_AGE = 60 * 60 * 12
SESSION_EXPIRE_AT_BROWSER_CLOSE = False

SECURE_SSL_REDIRECT = env_bool("SECURE_SSL_REDIRECT", False)
SESSION_COOKIE_SECURE = env_bool("SESSION_COOKIE_SECURE", False)
CSRF_COOKIE_SECURE = env_bool("CSRF_COOKIE_SECURE", False)

LOCALHOST_ONLY = env_bool("LOCALHOST_ONLY", False)

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {"class": "logging.StreamHandler"},
    },
    "loggers": {
        "django.security": {"handlers": ["console"], "level": "WARNING", "propagate": False},
        "myos.audit": {"handlers": ["console"], "level": "INFO", "propagate": False},
    },
}

```

---

## myos_backend/myos_backend/settings/development.py

- Size: 257 bytes
- Lines: 9
- Modified: 2026-03-05 18:41:22
- SHA256: ea3059f392f6a7845396395ed8ffc2cbf8aa300f4b8d5b819c86b16320f65de4
- MIME: text/x-script.python

```
from .base import *  # noqa

DEBUG = True
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
ALLOWED_HOSTS = ["127.0.0.1", "localhost"]
LOCALHOST_ONLY = True
SECURE_SSL_REDIRECT = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False

```

---

## myos_backend/myos_backend/settings/production.py

- Size: 179 bytes
- Lines: 8
- Modified: 2026-03-05 18:41:22
- SHA256: aec1345424a4a43b86e603471c9f15ff577f44e576ef1bc2bdf97727d2d97668
- MIME: text/x-script.python

```
from .base import *  # noqa

DEBUG = False
LOCALHOST_ONLY = False
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = 31536000

```

---

## myos_backend/myos_backend/urls.py

- Size: 471 bytes
- Lines: 14
- Modified: 2026-03-05 18:41:22
- SHA256: 23ec284df396179edcdcfc6d05535f561ef4f1a2c5455700e64641566ad931eb
- MIME: text/x-script.python

```
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from django.views.generic import TemplateView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", TemplateView.as_view(template_name="index.html"), name="home"),
    path("api/", include("apps.api.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

```

---

## myos_backend/myos_backend/wsgi.py

- Size: 183 bytes
- Lines: 5
- Modified: 2026-03-05 18:40:17
- SHA256: 1e6aff79a013f56b0f04e0f848475366379cea06e9d8c193d35726db48bad8cb
- MIME: text/x-script.python

```
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myos_backend.settings.development")
application = get_wsgi_application()

```

---

## myos_backend/requirements.txt

- Size: 267 bytes
- Lines: 12
- Modified: 2026-03-05 21:10:42
- SHA256: 546804e140ef9a58b3a4a113e219c7269751d5090f4b326f30ddfdd53b2b76ac
- MIME: text/plain

```
Django>=6.0,<7.0
djangorestframework>=3.15.1
djangorestframework-simplejwt>=5.3.1
django-filter>=24.2
django-cors-headers>=4.4.0
django-ratelimit>=4.1.0
psycopg2-binary>=2.9.9
argon2-cffi>=23.1.0
cryptography>=42.0.8
Pillow>=10.3.0
gunicorn>=22.0.0
whitenoise>=6.7.0

```

---

## myos_backend/templates/index.html

- Size: 314 bytes
- Lines: 12
- Modified: 2026-03-06 21:05:48
- SHA256: a085165ec98d518fe9f36ca35b016c1998a79441ae7b864803ae9bc231171eb7
- MIME: text/html

```
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>MyOS Backend Connected</title>
</head>
<body>
  <h1>MyOS Backend is running</h1>
  <p>Point your frontend client to this backend API base URL.</p>
</body>
</html>

```

---

## myos_project/manage.py

- Size: 668 bytes
- Lines: 22
- Modified: 2026-03-05 17:17:13
- SHA256: f6b471e498efa4265bb9713f71d1abe6c3d838d7040e34332f20de9f913c89bb
- MIME: text/x-script.python

```
#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myos_project.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()

```

---

## myos_project/media_tracker/__init__.py

- Size: 1 bytes
- Lines: 1
- Modified: 2026-03-06 21:40:52
- SHA256: 01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b
- MIME: application/octet-stream

```


```

---

## myos_project/media_tracker/admin.py

- Size: 1390 bytes
- Lines: 57
- Modified: 2026-03-06 21:48:34
- SHA256: 6035281a6d61dd2aac6cb25a28551545101ef771b832ab8a1a816fc8fbeecbc6
- MIME: text/x-script.python

```
from django.contrib import admin

from .models import MediaItem, MediaProgress


class MediaProgressInline(admin.TabularInline):
    model = MediaProgress
    extra = 0
    fields = (
        "date_watched",
        "episodes_watched",
        "current_season",
        "current_episode",
        "completed",
        "rating",
    )


@admin.register(MediaItem)
class MediaItemAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "category",
        "type",
        "status",
        "platform",
        "year",
        "date_added",
    )
    list_filter = ("category", "status", "platform", "year", "type")
    search_fields = ("title", "genre", "studio")
    ordering = ("-date_added", "-id")
    inlines = [MediaProgressInline]


@admin.register(MediaProgress)
class MediaProgressAdmin(admin.ModelAdmin):
    list_display = (
        "media_item",
        "date_watched",
        "episodes_watched",
        "current_season",
        "current_episode",
        "completed",
        "rating",
    )
    list_filter = (
        "completed",
        "date_watched",
        "media_item__category",
        "media_item__status",
        "media_item__platform",
        "media_item__year",
    )
    search_fields = ("media_item__title", "media_item__genre", "media_item__studio", "notes")
    autocomplete_fields = ("media_item",)
    ordering = ("-date_watched", "-id")

```

---

## myos_project/media_tracker/analytics.py

- Size: 6627 bytes
- Lines: 181
- Modified: 2026-03-06 21:52:05
- SHA256: 8fdce4367425aedd3bd4df514b16155baaffc34d9d1fc065b96997259388d6a9
- MIME: text/x-script.python

```
from collections import Counter, defaultdict
from datetime import timedelta
import hashlib

from django.core.cache import cache
from django.db.models import Count, Max, Sum
from django.db.models.functions import TruncMonth
from django.utils import timezone

from .models import MediaItem, MediaProgress
from .services import calculate_completion_rate, calculate_watch_time


CACHE_TIMEOUT_SECONDS = 300


def _analytics_cache_key(prefix):
    last_item_added = MediaItem.objects.aggregate(last=Max("date_added")).get("last")
    last_progress_id = MediaProgress.objects.aggregate(last=Max("id")).get("last")
    item_count = MediaItem.objects.count()
    progress_count = MediaProgress.objects.count()
    signature = "|".join(
        [
            str(prefix),
            str(item_count),
            str(progress_count),
            last_item_added.isoformat() if last_item_added else "",
            str(last_progress_id or ""),
        ]
    )
    digest = hashlib.sha1(signature.encode("utf-8")).hexdigest()
    return f"media_tracker:{prefix}:{digest}"


def _build_genre_distribution(items):
    counter = Counter()
    for item in items:
        raw = (item.genre or "").strip()
        if not raw:
            continue
        genres = [chunk.strip() for chunk in raw.split(",") if chunk.strip()]
        if not genres:
            genres = [raw]
        for genre in genres:
            counter[genre] += 1
    return [{"genre": key, "count": value} for key, value in counter.most_common()]


def _month_series(queryset, field_name, value_name=None):
    rows = (
        queryset.annotate(month=TruncMonth(field_name))
        .values("month")
        .annotate(total=Sum(value_name) if value_name else Count("id"))
        .order_by("month")
    )
    return [
        {
            "month": row["month"].strftime("%Y-%m") if row["month"] else "",
            "value": int(row["total"] or 0),
        }
        for row in rows
    ]


def movies_analytics():
    cache_key = _analytics_cache_key("movies")
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    items = list(MediaItem.objects.filter(category=MediaItem.Category.MOVIE))
    watched = len([item for item in items if item.status == MediaItem.Status.COMPLETED])
    total = len(items)
    completion_rate = round((watched / total) * 100, 2) if total else 0.0

    per_month_rows = (
        MediaItem.objects.filter(category=MediaItem.Category.MOVIE)
        .annotate(month=TruncMonth("date_added"))
        .values("month")
        .annotate(total=Count("id"))
        .order_by("month")
    )
    movies_per_month = [
        {"month": row["month"].strftime("%Y-%m") if row["month"] else "", "count": int(row["total"] or 0)}
        for row in per_month_rows
    ]

    result = {
        "movies_watched_count": watched,
        "movies_remaining_count": max(0, total - watched),
        "movies_per_month": movies_per_month,
        "genre_distribution": _build_genre_distribution(items),
        "completion_rate": completion_rate,
        "watch_time": calculate_watch_time(items),
    }
    cache.set(cache_key, result, CACHE_TIMEOUT_SECONDS)
    return result


def series_analytics():
    cache_key = _analytics_cache_key("series")
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    items = list(MediaItem.objects.filter(category=MediaItem.Category.SERIES))
    completed = len([item for item in items if item.status == MediaItem.Status.COMPLETED])
    in_progress = len([item for item in items if item.status == MediaItem.Status.WATCHING])

    progress_qs = MediaProgress.objects.filter(media_item__category=MediaItem.Category.SERIES)
    episodes_watched_per_month = _month_series(progress_qs, "date_watched", "episodes_watched")

    cutoff = timezone.now().date() - timedelta(days=56)
    weekly_rows = defaultdict(int)
    for row in progress_qs.filter(date_watched__gte=cutoff):
        week = row.date_watched - timedelta(days=row.date_watched.weekday())
        weekly_rows[week] += row.episodes_watched
    weekly_values = list(weekly_rows.values())
    average_per_week = round(sum(weekly_values) / len(weekly_values), 2) if weekly_values else 0.0

    result = {
        "series_completed": completed,
        "series_in_progress": in_progress,
        "episodes_watched_per_month": episodes_watched_per_month,
        "average_episodes_per_week": average_per_week,
        "watch_time": calculate_watch_time(items),
        "completion_rate": calculate_completion_rate(items),
        "genre_distribution": _build_genre_distribution(items),
    }
    cache.set(cache_key, result, CACHE_TIMEOUT_SECONDS)
    return result


def anime_analytics():
    cache_key = _analytics_cache_key("anime")
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    items = list(MediaItem.objects.filter(category=MediaItem.Category.ANIME))
    episodes_watched = (
        MediaProgress.objects.filter(media_item__category=MediaItem.Category.ANIME).aggregate(total=Sum("episodes_watched"))["total"]
        or 0
    )
    result = {
        "anime_completion_rate": calculate_completion_rate(items),
        "anime_by_genre": _build_genre_distribution(items),
        "episodes_watched": int(episodes_watched),
        "watch_time": calculate_watch_time(items),
    }
    cache.set(cache_key, result, CACHE_TIMEOUT_SECONDS)
    return result


def global_media_analytics():
    cache_key = _analytics_cache_key("global")
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    items = list(MediaItem.objects.all().prefetch_related("progress_entries"))
    movies = [item for item in items if item.category == MediaItem.Category.MOVIE]
    series = [item for item in items if item.category == MediaItem.Category.SERIES]
    anime = [item for item in items if item.category == MediaItem.Category.ANIME]

    anime_episodes_watched = (
        MediaProgress.objects.filter(media_item__category=MediaItem.Category.ANIME).aggregate(total=Sum("episodes_watched"))["total"]
        or 0
    )
    watch_time = calculate_watch_time(items)

    result = {
        "movies_watched": len([item for item in movies if item.status == MediaItem.Status.COMPLETED]),
        "movies_total": len(movies),
        "series_completed": len([item for item in series if item.status == MediaItem.Status.COMPLETED]),
        "series_total": len(series),
        "anime_episodes_watched": int(anime_episodes_watched),
        "total_watch_time": watch_time,
    }
    cache.set(cache_key, result, CACHE_TIMEOUT_SECONDS)
    return result

```

---

## myos_project/media_tracker/apps.py

- Size: 158 bytes
- Lines: 7
- Modified: 2026-03-06 21:40:57
- SHA256: 64935e70f198ed485b5532b987c3fea5932e5a8327dd86e6f7fe491a73aead91
- MIME: text/x-script.python

```
from django.apps import AppConfig


class MediaTrackerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "media_tracker"


```

---

## myos_project/media_tracker/forms.py

- Size: 4501 bytes
- Lines: 104
- Modified: 2026-03-06 21:42:02
- SHA256: e2ec1056dd41fbd75fa3688e31b3ca7adc741aef5ab8137913069f7a85ca63c0
- MIME: text/x-script.python

```
from django import forms

from .models import MediaItem, MediaProgress


class MediaItemForm(forms.ModelForm):
    class Meta:
        model = MediaItem
        fields = [
            "title",
            "category",
            "type",
            "genre",
            "studio",
            "country",
            "year",
            "platform",
            "duration",
            "total_seasons",
            "total_episodes",
            "episode_duration",
            "status",
        ]
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "genre": forms.TextInput(attrs={"class": "form-control", "placeholder": "e.g. Action, Drama"}),
            "studio": forms.TextInput(attrs={"class": "form-control"}),
            "country": forms.TextInput(attrs={"class": "form-control"}),
            "year": forms.NumberInput(attrs={"class": "form-control", "min": 1888, "max": 2200}),
            "platform": forms.TextInput(attrs={"class": "form-control"}),
            "duration": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "total_seasons": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "total_episodes": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "episode_duration": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "category": forms.Select(attrs={"class": "form-control"}),
            "type": forms.Select(attrs={"class": "form-control"}),
            "status": forms.Select(attrs={"class": "form-control"}),
        }

    def clean(self):
        cleaned_data = super().clean()
        media_type = cleaned_data.get("type")
        duration = cleaned_data.get("duration")
        total_episodes = cleaned_data.get("total_episodes") or 1
        episode_duration = cleaned_data.get("episode_duration")

        if media_type == MediaItem.MediaType.MOVIE:
            if not duration:
                self.add_error("duration", "Movie duration is required for movie entries.")
            cleaned_data["total_seasons"] = 1
            cleaned_data["total_episodes"] = 1
        else:
            if total_episodes < 1:
                self.add_error("total_episodes", "Series/anime entries must have at least one episode.")
            if not episode_duration:
                self.add_error("episode_duration", "Episode duration is required for series entries.")
        return cleaned_data


class MediaProgressForm(forms.ModelForm):
    class Meta:
        model = MediaProgress
        fields = [
            "episodes_watched",
            "current_season",
            "current_episode",
            "date_watched",
            "completed",
            "rating",
            "notes",
        ]
        widgets = {
            "episodes_watched": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "current_season": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "current_episode": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "date_watched": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "completed": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "rating": forms.NumberInput(attrs={"class": "form-control", "min": 1, "max": 10}),
            "notes": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }

    def __init__(self, *args, media_item=None, **kwargs):
        self.media_item = media_item
        super().__init__(*args, **kwargs)

    def clean(self):
        cleaned_data = super().clean()
        media_item = self.media_item or getattr(self.instance, "media_item", None)
        if not media_item:
            return cleaned_data

        episodes_watched = cleaned_data.get("episodes_watched", 0) or 0
        current_episode = cleaned_data.get("current_episode", 0) or 0

        if media_item.type == MediaItem.MediaType.MOVIE:
            cleaned_data["episodes_watched"] = 1 if cleaned_data.get("completed") else min(episodes_watched, 1)
            cleaned_data["current_season"] = 1
            cleaned_data["current_episode"] = 1 if cleaned_data.get("completed") else min(current_episode, 1)
        else:
            total = media_item.total_episodes or 0
            if total and episodes_watched > total:
                self.add_error("episodes_watched", f"Episodes watched cannot exceed total episodes ({total}).")
        return cleaned_data


```

---

## myos_project/media_tracker/migrations/0001_initial.py

- Size: 4271 bytes
- Lines: 73
- Modified: 2026-03-06 21:51:09
- SHA256: 687e2dabc94f8e7cd97d8be0a2a3173d50ffb7c7e53c28243d7f19626b374ea9
- MIME: text/x-script.python

```
# Generated by Django 4.2.11 on 2026-03-06 18:51

from django.conf import settings
import django.core.validators
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='MediaItem',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=220)),
                ('category', models.CharField(choices=[('MOVIE', 'Movies'), ('SERIES', 'Series'), ('ANIME', 'Anime'), ('ANIMATION', 'Animation')], max_length=20)),
                ('type', models.CharField(choices=[('MOVIE', 'Movie'), ('SERIES', 'Series')], max_length=20)),
                ('genre', models.CharField(blank=True, default='', max_length=160)),
                ('studio', models.CharField(blank=True, default='', max_length=160)),
                ('country', models.CharField(blank=True, default='', max_length=120)),
                ('year', models.PositiveIntegerField(blank=True, null=True, validators=[django.core.validators.MinValueValidator(1888), django.core.validators.MaxValueValidator(2200)])),
                ('platform', models.CharField(blank=True, default='', max_length=120)),
                ('duration', models.PositiveIntegerField(blank=True, help_text='Movie duration in minutes.', null=True)),
                ('total_seasons', models.PositiveIntegerField(default=1)),
                ('total_episodes', models.PositiveIntegerField(default=1)),
                ('episode_duration', models.PositiveIntegerField(blank=True, help_text='Episode duration in minutes.', null=True)),
                ('date_added', models.DateTimeField(auto_now_add=True)),
                ('status', models.CharField(choices=[('PLANNED', 'Planned'), ('WATCHING', 'Watching'), ('COMPLETED', 'Completed')], default='PLANNED', max_length=20)),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name='tracked_media', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'ordering': ['-date_added', '-id'],
            },
        ),
        migrations.CreateModel(
            name='MediaProgress',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('episodes_watched', models.PositiveIntegerField(default=0)),
                ('current_season', models.PositiveIntegerField(default=1)),
                ('current_episode', models.PositiveIntegerField(default=0)),
                ('date_watched', models.DateField(db_index=True, default=django.utils.timezone.now)),
                ('completed', models.BooleanField(default=False)),
                ('rating', models.PositiveSmallIntegerField(blank=True, help_text='Rating from 1 to 10.', null=True, validators=[django.core.validators.MinValueValidator(1), django.core.validators.MaxValueValidator(10)])),
                ('notes', models.TextField(blank=True, default='')),
                ('media_item', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='progress_entries', to='media_tracker.mediaitem')),
            ],
            options={
                'ordering': ['-date_watched', '-id'],
                'indexes': [models.Index(fields=['date_watched'], name='media_track_date_wa_44497b_idx'), models.Index(fields=['completed'], name='media_track_complet_50df6a_idx')],
            },
        ),
        migrations.AddIndex(
            model_name='mediaitem',
            index=models.Index(fields=['category', 'type', 'status'], name='media_track_categor_32d9be_idx'),
        ),
        migrations.AddIndex(
            model_name='mediaitem',
            index=models.Index(fields=['platform'], name='media_track_platfor_c429c1_idx'),
        ),
        migrations.AddIndex(
            model_name='mediaitem',
            index=models.Index(fields=['year'], name='media_track_year_86fb04_idx'),
        ),
    ]

```

---

## myos_project/media_tracker/migrations/__init__.py

- Size: 1 bytes
- Lines: 1
- Modified: 2026-03-06 21:41:00
- SHA256: 01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b
- MIME: application/octet-stream

```


```

---

## myos_project/media_tracker/models.py

- Size: 5030 bytes
- Lines: 136
- Modified: 2026-03-06 21:41:37
- SHA256: c337627af8e63a1e357f7fcf3f2c521fcbd2f2e01070203583e9fc2d6277a91f
- MIME: text/x-script.python

```
from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils import timezone


class MediaItem(models.Model):
    class Category(models.TextChoices):
        MOVIE = "MOVIE", "Movies"
        SERIES = "SERIES", "Series"
        ANIME = "ANIME", "Anime"
        ANIMATION = "ANIMATION", "Animation"

    class MediaType(models.TextChoices):
        MOVIE = "MOVIE", "Movie"
        SERIES = "SERIES", "Series"

    class Status(models.TextChoices):
        PLANNED = "PLANNED", "Planned"
        WATCHING = "WATCHING", "Watching"
        COMPLETED = "COMPLETED", "Completed"

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="tracked_media",
        null=True,
        blank=True,
    )
    title = models.CharField(max_length=220)
    category = models.CharField(max_length=20, choices=Category.choices)
    type = models.CharField(max_length=20, choices=MediaType.choices)
    genre = models.CharField(max_length=160, blank=True, default="")
    studio = models.CharField(max_length=160, blank=True, default="")
    country = models.CharField(max_length=120, blank=True, default="")
    year = models.PositiveIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1888), MaxValueValidator(2200)],
    )
    platform = models.CharField(max_length=120, blank=True, default="")
    duration = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="Movie duration in minutes.",
    )
    total_seasons = models.PositiveIntegerField(default=1)
    total_episodes = models.PositiveIntegerField(default=1)
    episode_duration = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="Episode duration in minutes.",
    )
    date_added = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PLANNED)

    class Meta:
        ordering = ["-date_added", "-id"]
        indexes = [
            models.Index(fields=["category", "type", "status"]),
            models.Index(fields=["platform"]),
            models.Index(fields=["year"]),
        ]

    def __str__(self):
        return self.title

    def latest_progress_entry(self):
        prefetched = getattr(self, "_prefetched_objects_cache", {})
        if "progress_entries" in prefetched:
            entries = prefetched["progress_entries"]
            return entries[0] if entries else None
        return self.progress_entries.order_by("-date_watched", "-id").first()

    def progress_percent(self):
        latest = self.latest_progress_entry()
        if self.type == self.MediaType.MOVIE:
            completed = self.status == self.Status.COMPLETED or bool(latest and latest.completed)
            return 100 if completed else 0
        total = max(self.total_episodes or 0, 0)
        if total <= 0:
            return 0
        watched = latest.episodes_watched if latest else 0
        return int(min(100, max(0, (watched / total) * 100)))


class MediaProgress(models.Model):
    media_item = models.ForeignKey(
        MediaItem,
        on_delete=models.CASCADE,
        related_name="progress_entries",
    )
    episodes_watched = models.PositiveIntegerField(default=0)
    current_season = models.PositiveIntegerField(default=1)
    current_episode = models.PositiveIntegerField(default=0)
    date_watched = models.DateField(default=timezone.now, db_index=True)
    completed = models.BooleanField(default=False)
    rating = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(10)],
        help_text="Rating from 1 to 10.",
    )
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-date_watched", "-id"]
        indexes = [
            models.Index(fields=["date_watched"]),
            models.Index(fields=["completed"]),
        ]

    def __str__(self):
        return f"{self.media_item.title} ({self.date_watched})"

    def save(self, *args, **kwargs):
        media = self.media_item
        if media.type == MediaItem.MediaType.MOVIE:
            self.current_season = 1
            self.current_episode = 1 if self.completed else max(self.current_episode, 0)
            self.episodes_watched = 1 if self.completed else min(self.episodes_watched, 1)
        else:
            total = max(media.total_episodes or 0, 0)
            if total > 0:
                self.episodes_watched = min(self.episodes_watched, total)
                if self.episodes_watched >= total:
                    self.completed = True
        super().save(*args, **kwargs)

    @property
    def watch_time_minutes(self):
        media = self.media_item
        if media.type == MediaItem.MediaType.MOVIE:
            return media.duration or 0
        return (self.episodes_watched or 0) * (media.episode_duration or 0)


```

---

## myos_project/media_tracker/services.py

- Size: 4446 bytes
- Lines: 135
- Modified: 2026-03-06 21:43:32
- SHA256: 39608883c89a49ea55612825925a8cad2bd3e92c4a5bc042c932b850a5389a52
- MIME: text/x-script.python

```
from decimal import Decimal, ROUND_HALF_UP

from django.db.models import Prefetch

from .models import MediaItem, MediaProgress


PROGRESS_PREFETCH = Prefetch(
    "progress_entries",
    queryset=MediaProgress.objects.order_by("-date_watched", "-id"),
)


def _with_progress(queryset):
    if queryset is None:
        queryset = MediaItem.objects.all()
    return queryset.prefetch_related(PROGRESS_PREFETCH)


def _latest_progress(item):
    return item.latest_progress_entry()


def calculate_watch_time(media_items):
    total_minutes = 0
    for item in media_items:
        latest = _latest_progress(item)
        if item.type == MediaItem.MediaType.MOVIE:
            is_watched = item.status == MediaItem.Status.COMPLETED or bool(latest and latest.completed)
            if is_watched:
                total_minutes += item.duration or 0
            continue

        episodes_watched = latest.episodes_watched if latest else 0
        total_minutes += episodes_watched * (item.episode_duration or 0)

    total_hours = (Decimal(total_minutes) / Decimal(60)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return {
        "minutes": total_minutes,
        "hours": float(total_hours),
    }


def calculate_completion_rate(media_items):
    items = list(media_items)
    total = len(items)
    if total == 0:
        return 0.0
    completed = 0
    for item in items:
        latest = _latest_progress(item)
        if item.status == MediaItem.Status.COMPLETED or bool(latest and latest.completed):
            completed += 1
    return round((completed / total) * 100, 2)


def _stats_from_rows(rows):
    watch_time = calculate_watch_time(rows)
    total = len(rows)
    completed = len([item for item in rows if item.status == MediaItem.Status.COMPLETED])
    watching = len([item for item in rows if item.status == MediaItem.Status.WATCHING])
    planned = len([item for item in rows if item.status == MediaItem.Status.PLANNED])
    return {
        "total": total,
        "completed": completed,
        "watching": watching,
        "planned": planned,
        "completion_rate": calculate_completion_rate(rows),
        "watch_time_minutes": watch_time["minutes"],
        "watch_time_hours": watch_time["hours"],
    }


def get_movies_stats(queryset=None):
    if queryset is None:
        queryset = MediaItem.objects.filter(category=MediaItem.Category.MOVIE)
    rows = list(_with_progress(queryset))
    stats = _stats_from_rows(rows)
    stats.update(
        {
            "items": rows,
            "movie_count": len(rows),
        }
    )
    return stats


def get_series_stats(queryset=None):
    if queryset is None:
        queryset = MediaItem.objects.filter(category=MediaItem.Category.SERIES)
    rows = list(_with_progress(queryset))
    stats = _stats_from_rows(rows)
    stats.update(
        {
            "items": rows,
            "series_count": len(rows),
        }
    )
    return stats


def get_anime_stats(queryset=None):
    if queryset is None:
        queryset = MediaItem.objects.filter(category=MediaItem.Category.ANIME)
    rows = list(_with_progress(queryset))
    watch_time = calculate_watch_time(rows)
    anime_movies = [item for item in rows if item.type == MediaItem.MediaType.MOVIE]
    anime_series = [item for item in rows if item.type == MediaItem.MediaType.SERIES]
    return {
        "items": rows,
        "anime_count": len(rows),
        "anime_movies_count": len(anime_movies),
        "anime_series_count": len(anime_series),
        "completion_rate": calculate_completion_rate(rows),
        "watch_time_minutes": watch_time["minutes"],
        "watch_time_hours": watch_time["hours"],
    }


def get_animation_stats(queryset=None):
    if queryset is None:
        queryset = MediaItem.objects.filter(category=MediaItem.Category.ANIMATION)
    rows = list(_with_progress(queryset))
    watch_time = calculate_watch_time(rows)
    animation_movies = [item for item in rows if item.type == MediaItem.MediaType.MOVIE]
    animation_series = [item for item in rows if item.type == MediaItem.MediaType.SERIES]
    return {
        "items": rows,
        "animation_count": len(rows),
        "animation_movies_count": len(animation_movies),
        "animation_series_count": len(animation_series),
        "completion_rate": calculate_completion_rate(rows),
        "watch_time_minutes": watch_time["minutes"],
        "watch_time_hours": watch_time["hours"],
    }

```

---

## myos_project/media_tracker/templates/media/_filters.html

- Size: 1677 bytes
- Lines: 41
- Modified: 2026-03-06 21:52:34
- SHA256: e38cd75c50766f0f43fe0d81f729fca66bb4e94b20562fbdcf27f65f91688ba9
- MIME: text/plain

```
<form method="get" class="dash-card" style="margin-bottom: 1rem;">
  <div class="cards-grid">
    <div>
      <label for="id_q">Search</label>
      <input id="id_q" class="form-control" type="text" name="q" value="{{ filters.q }}" placeholder="Title, genre, studio...">
    </div>
    <div>
      <label for="id_status">Status</label>
      <select id="id_status" class="form-control" name="status">
        <option value="">All</option>
        {% for value, label in status_choices %}
          <option value="{{ value }}" {% if filters.status == value %}selected{% endif %}>{{ label }}</option>
        {% endfor %}
      </select>
    </div>
    <div>
      <label for="id_platform">Platform</label>
      <input id="id_platform" class="form-control" type="text" name="platform" value="{{ filters.platform }}" placeholder="Netflix, Prime...">
    </div>
    <div>
      <label for="id_year">Year</label>
      <input id="id_year" class="form-control" type="number" name="year" value="{{ filters.year }}" min="1888" max="2200">
    </div>
    {% if show_type_filter %}
      <div>
        <label for="id_type">Type</label>
        <select id="id_type" class="form-control" name="type">
          <option value="">All</option>
          {% for value, label in type_choices %}
            <option value="{{ value }}" {% if filters.type == value %}selected{% endif %}>{{ label }}</option>
          {% endfor %}
        </select>
      </div>
    {% endif %}
  </div>

  <div style="margin-top: 0.75rem; display: flex; gap: 0.75rem;">
    <button type="submit" class="btn-add">Apply filters</button>
    <a class="btn-add" href="{{ request.path }}">Reset</a>
  </div>
</form>

```

---

## myos_project/media_tracker/templates/media/_media_table.html

- Size: 1934 bytes
- Lines: 57
- Modified: 2026-03-06 21:53:53
- SHA256: 213c49fc80ca5eb3c93ed020f0fbc06525a487aa23a8b66e922ca806521ad89e
- MIME: text/html

```
{% if items %}
  <div class="dash-card">
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Type</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Watched</th>
            <th>Platform</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {% for item in items %}
            {% with latest=item.latest_progress_entry %}
              <tr>
                <td>{{ item.title }}</td>
                <td>{{ item.get_category_display }}</td>
                <td>{{ item.get_type_display }}</td>
                <td>{{ item.get_status_display }}</td>
                <td>
                  {{ item.progress_percent }}%
                  <div class="media-bar-track"><div class="media-bar-fill" style="width: {{ item.progress_percent }}%;"></div></div>
                </td>
                <td>
                  {% if item.type == 'MOVIE' %}
                    {% if item.status == 'COMPLETED' %}
                      {{ item.duration|default:0 }} min
                    {% else %}
                      0 min
                    {% endif %}
                  {% else %}
                    {{ latest.episodes_watched|default:0 }} eps
                  {% endif %}
                </td>
                <td>{{ item.platform|default:'-' }}</td>
                <td>
                  <a href="{% url 'update_progress' item.id %}">Progress</a> |
                  <a href="{% url 'edit_media' item.id %}">Edit</a> |
                  <a href="{% url 'delete_media' item.id %}">Delete</a>
                </td>
              </tr>
            {% endwith %}
          {% endfor %}
        </tbody>
      </table>
    </div>
  </div>
{% else %}
  <div class="dash-card">
    <div class="table-empty">{{ empty_text|default:'No media items found.' }}</div>
  </div>
{% endif %}

```

---

## myos_project/media_tracker/templates/media/_media_tabs.html

- Size: 585 bytes
- Lines: 7
- Modified: 2026-03-06 21:50:15
- SHA256: 9f598f21c5670b47012b47dea3965c77dee07e685a576ca1c6bbc2628d05e220
- MIME: text/plain

```
<div class="tab-bar">
  <a class="tab-btn {% if tab_name == 'dashboard' %}active{% endif %}" href="{% url 'media' %}">Dashboard</a>
  <a class="tab-btn {% if tab_name == 'movies' %}active{% endif %}" href="{% url 'movies_view' %}">Movies</a>
  <a class="tab-btn {% if tab_name == 'series' %}active{% endif %}" href="{% url 'series_view' %}">Series</a>
  <a class="tab-btn {% if tab_name == 'anime' %}active{% endif %}" href="{% url 'anime_view' %}">Anime</a>
  <a class="tab-btn {% if tab_name == 'animation' %}active{% endif %}" href="{% url 'animation_view' %}">Animation</a>
</div>

```

---

## myos_project/media_tracker/templates/media/_messages.html

- Size: 147 bytes
- Lines: 7
- Modified: 2026-03-06 21:50:15
- SHA256: 2dd05ec73bec9ada54e601cd83aafd155b8b10c83ca5f0c9ef89bd7228284b03
- MIME: text/plain

```
{% if messages %}
  <div class="dash-card">
    {% for message in messages %}
      <div>{{ message }}</div>
    {% endfor %}
  </div>
{% endif %}

```

---

## myos_project/media_tracker/templates/media/animation.html

- Size: 1424 bytes
- Lines: 30
- Modified: 2026-03-06 21:52:55
- SHA256: 9e8ee75a8ba88ba240bd8f7ddb521b8aa4a2aa9beec5c1f42b9912410cd66bd5
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Animation{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">Animation</div>
    <div class="page-title-sub">Track animation movies and animation series.</div>
  </div>
  <a class="btn-add" href="{% url 'add_media' %}?category=ANIMATION&type=SERIES"><i class="fas fa-plus"></i> Add Animation</a>
</div>

{% include 'media/_messages.html' %}
{% include 'media/_media_tabs.html' with tab_name='animation' %}
{% include 'media/_filters.html' with show_type_filter=True %}

<div class="cards-grid">
  <div class="dash-card"><div class="section-title">Total Animation</div><div>{{ stats.animation_count }}</div></div>
  <div class="dash-card"><div class="section-title">Animation Movies</div><div>{{ stats.animation_movies_count }}</div></div>
  <div class="dash-card"><div class="section-title">Animation Series</div><div>{{ stats.animation_series_count }}</div></div>
  <div class="dash-card"><div class="section-title">Completion Rate</div><div>{{ stats.completion_rate }}%</div></div>
</div>

<h3 class="section-title">Animation Movies</h3>
{% include 'media/_media_table.html' with items=animation_movies empty_text='No animation movies found.' %}

<h3 class="section-title">Animation Series</h3>
{% include 'media/_media_table.html' with items=animation_series empty_text='No animation series found.' %}
{% endblock %}

```

---

## myos_project/media_tracker/templates/media/anime.html

- Size: 1506 bytes
- Lines: 35
- Modified: 2026-03-06 21:52:51
- SHA256: 86846f9309915770df43e1cb701e771ba13377777232ed4679b609312dd70f9c
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Anime{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">Anime</div>
    <div class="page-title-sub">Track anime movies and anime series separately.</div>
  </div>
  <a class="btn-add" href="{% url 'add_media' %}?category=ANIME&type=SERIES"><i class="fas fa-plus"></i> Add Anime</a>
</div>

{% include 'media/_messages.html' %}
{% include 'media/_media_tabs.html' with tab_name='anime' %}
{% include 'media/_filters.html' with show_type_filter=True %}

<div class="cards-grid">
  <div class="dash-card"><div class="section-title">Total Anime</div><div>{{ stats.anime_count }}</div></div>
  <div class="dash-card"><div class="section-title">Anime Movies</div><div>{{ stats.anime_movies_count }}</div></div>
  <div class="dash-card"><div class="section-title">Anime Series</div><div>{{ stats.anime_series_count }}</div></div>
  <div class="dash-card"><div class="section-title">Completion Rate</div><div>{{ stats.completion_rate }}%</div></div>
</div>

<div class="dash-card">
  <div class="section-title">Anime Analytics</div>
  <div>Episodes watched: {{ analytics.episodes_watched }}</div>
</div>

<h3 class="section-title">Anime Movies</h3>
{% include 'media/_media_table.html' with items=anime_movies empty_text='No anime movies found.' %}

<h3 class="section-title">Anime Series</h3>
{% include 'media/_media_table.html' with items=anime_series empty_text='No anime series found.' %}
{% endblock %}

```

---

## myos_project/media_tracker/templates/media/media.html

- Size: 2886 bytes
- Lines: 62
- Modified: 2026-03-06 21:52:39
- SHA256: 1f3413f3f1c382441360de2b3c501d663eb0c8ddb240ba305424c556d4a04771
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Media Dashboard{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">Media Dashboard</div>
    <div class="page-title-sub">Track movies, series, anime and animation from one place.</div>
  </div>
  <a class="btn-add" href="{% url 'add_media' %}"><i class="fas fa-plus"></i> Add Media</a>
</div>

{% include 'media/_messages.html' %}
{% include 'media/_media_tabs.html' with tab_name='dashboard' %}
{% include 'media/_filters.html' with show_type_filter=True %}

<div class="media-overview">
  <div class="media-stat">
    <div class="media-stat-label">Movies Watched</div>
    <div class="media-stat-value">{{ global_analytics.movies_watched }}/{{ global_analytics.movies_total }}</div>
    <div class="media-bar-track"><div class="media-bar-fill" style="width:{% widthratio global_analytics.movies_watched global_analytics.movies_total 100 %}%"></div></div>
  </div>
  <div class="media-stat">
    <div class="media-stat-label">Series Completed</div>
    <div class="media-stat-value">{{ global_analytics.series_completed }}/{{ global_analytics.series_total }}</div>
    <div class="media-bar-track"><div class="media-bar-fill" style="width:{% widthratio global_analytics.series_completed global_analytics.series_total 100 %}%"></div></div>
  </div>
  <div class="media-stat">
    <div class="media-stat-label">Anime Episodes Watched</div>
    <div class="media-stat-value">{{ global_analytics.anime_episodes_watched }}</div>
  </div>
  <div class="media-stat">
    <div class="media-stat-label">Total Watch Time</div>
    <div class="media-stat-value">{{ global_analytics.total_watch_time.hours }}h</div>
  </div>
</div>

<div class="dash-card">{{ watch_time_message }}</div>

<div class="cards-grid">
  <div class="dash-card">
    <div class="section-title">Movies</div>
    <div>Total: {{ movies_stats.total }} | Completed: {{ movies_stats.completed }} | Completion: {{ movies_stats.completion_rate }}%</div>
  </div>
  <div class="dash-card">
    <div class="section-title">Series</div>
    <div>Total: {{ series_stats.total }} | Completed: {{ series_stats.completed }} | Completion: {{ series_stats.completion_rate }}%</div>
  </div>
  <div class="dash-card">
    <div class="section-title">Anime</div>
    <div>Total: {{ anime_stats.anime_count }} | Movies: {{ anime_stats.anime_movies_count }} | Series: {{ anime_stats.anime_series_count }}</div>
  </div>
  <div class="dash-card">
    <div class="section-title">Animation</div>
    <div>Total: {{ animation_stats.animation_count }} | Movies: {{ animation_stats.animation_movies_count }} | Series: {{ animation_stats.animation_series_count }}</div>
  </div>
</div>

<h3 class="section-title">Recently Added</h3>
{% include 'media/_media_table.html' with items=recent_media empty_text='No media tracked yet.' %}
{% endblock %}

```

---

## myos_project/media_tracker/templates/media/media_confirm_delete.html

- Size: 674 bytes
- Lines: 24
- Modified: 2026-03-06 21:50:15
- SHA256: 1a7ac1c5d6f429792772433c0609e501b9e9e5429b087559e1784a836870a7f1
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Delete Media{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">Delete Media</div>
    <div class="page-title-sub">This action cannot be undone.</div>
  </div>
  <a class="btn-add" href="{% url 'media' %}">Back to Media</a>
</div>

{% include 'media/_messages.html' %}

<div class="dash-card">
  <p>Delete <strong>{{ media_item.title }}</strong> from your tracker?</p>
  <form method="post">
    {% csrf_token %}
    <button type="submit" class="btn-add">Confirm delete</button>
    <a class="btn-add" href="{% url 'media' %}">Cancel</a>
  </form>
</div>
{% endblock %}

```

---

## myos_project/media_tracker/templates/media/media_form.html

- Size: 1381 bytes
- Lines: 48
- Modified: 2026-03-06 21:51:00
- SHA256: 127eb32d44061a45b332eef5cd33fac63b56391ec5c1cf955ee79e6b718bdea2
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — {{ page_title }}{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">{{ page_title }}</div>
    <div class="page-title-sub">Create or edit media entries for your tracker.</div>
  </div>
  <a class="btn-add" href="{% url 'media' %}">Back to Media</a>
</div>

{% include 'media/_messages.html' %}
{% include 'media/_media_tabs.html' with tab_name='dashboard' %}

<div class="dash-card">
  <form method="post" novalidate>
    {% csrf_token %}

    {% if form.non_field_errors %}
      <div>
        {% for error in form.non_field_errors %}
          <div>{{ error }}</div>
        {% endfor %}
      </div>
    {% endif %}

    <div class="cards-grid">
      {% for field in form %}
        <div>
          <label for="{{ field.id_for_label }}">{{ field.label }}</label>
          {{ field }}
          {% if field.help_text %}<small>{{ field.help_text }}</small>{% endif %}
          {% for error in field.errors %}
            <div>{{ error }}</div>
          {% endfor %}
        </div>
      {% endfor %}
    </div>

    <div class="u-inline-1" style="margin-top: 1rem; display: flex; gap: 0.75rem;">
      <button type="submit" class="btn-add">{{ submit_label }}</button>
      <a class="btn-add" href="{% url 'media' %}">Cancel</a>
    </div>
  </form>
</div>
{% endblock %}

```

---

## myos_project/media_tracker/templates/media/movies.html

- Size: 1326 bytes
- Lines: 31
- Modified: 2026-03-06 21:52:43
- SHA256: 671847477f10355e29d907c7027bbe1347a7f844c51b0700a7e30af9395a9e32
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Movies{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">Movies</div>
    <div class="page-title-sub">Manage movie entries and completion.</div>
  </div>
  <a class="btn-add" href="{% url 'add_media' %}?category=MOVIE&type=MOVIE"><i class="fas fa-plus"></i> Add Movie</a>
</div>

{% include 'media/_messages.html' %}
{% include 'media/_media_tabs.html' with tab_name='movies' %}
{% include 'media/_filters.html' with show_type_filter=False %}

<div class="cards-grid">
  <div class="dash-card"><div class="section-title">Tracked Movies</div><div>{{ stats.total }}</div></div>
  <div class="dash-card"><div class="section-title">Completed</div><div>{{ stats.completed }}</div></div>
  <div class="dash-card"><div class="section-title">Completion Rate</div><div>{{ stats.completion_rate }}%</div></div>
  <div class="dash-card"><div class="section-title">Watch Time</div><div>{{ stats.watch_time_hours }}h</div></div>
</div>

<div class="dash-card">
  <div class="section-title">Movie Analytics</div>
  <div>Watched: {{ analytics.movies_watched_count }} | Remaining: {{ analytics.movies_remaining_count }}</div>
</div>

{% include 'media/_media_table.html' with items=movies empty_text='No movies found.' %}
{% endblock %}

```

---

## myos_project/media_tracker/templates/media/progress_form.html

- Size: 1621 bytes
- Lines: 55
- Modified: 2026-03-06 21:50:15
- SHA256: 9a3ba5c1e0f7c86f4d0a380e4c9df6eb03cb243fbaf1bea2af76fab5097f687c
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Update Progress{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">Update Progress</div>
    <div class="page-title-sub">{{ media_item.title }}</div>
  </div>
  <a class="btn-add" href="{% url 'media' %}">Back to Media</a>
</div>

{% include 'media/_messages.html' %}
{% include 'media/_media_tabs.html' with tab_name='dashboard' %}

{% if latest_progress %}
  <div class="dash-card">
    Last saved: {{ latest_progress.date_watched }} | Episodes watched: {{ latest_progress.episodes_watched }}
    {% if latest_progress.rating %}| Rating: {{ latest_progress.rating }}/10{% endif %}
  </div>
{% endif %}

<div class="dash-card">
  <form method="post" novalidate>
    {% csrf_token %}

    {% if form.non_field_errors %}
      <div>
        {% for error in form.non_field_errors %}
          <div>{{ error }}</div>
        {% endfor %}
      </div>
    {% endif %}

    <div class="cards-grid">
      {% for field in form %}
        <div>
          <label for="{{ field.id_for_label }}">{{ field.label }}</label>
          {{ field }}
          {% if field.help_text %}<small>{{ field.help_text }}</small>{% endif %}
          {% for error in field.errors %}
            <div>{{ error }}</div>
          {% endfor %}
        </div>
      {% endfor %}
    </div>

    <div class="u-inline-1" style="margin-top: 1rem; display: flex; gap: 0.75rem;">
      <button type="submit" class="btn-add">Save progress</button>
      <a class="btn-add" href="{% url 'media' %}">Cancel</a>
    </div>
  </form>
</div>
{% endblock %}

```

---

## myos_project/media_tracker/templates/media/series.html

- Size: 1166 bytes
- Lines: 26
- Modified: 2026-03-06 21:52:46
- SHA256: d7d2d986b1cfcca6eb1e9eafdab3c5d58e4c0a5f4acccee5acc05a22f6928797
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Series{% endblock %}

{% block page_content %}
<div class="page-header">
  <div>
    <div class="page-title">Series</div>
    <div class="page-title-sub">Track episodic progress and completion pace.</div>
  </div>
  <a class="btn-add" href="{% url 'add_media' %}?category=SERIES&type=SERIES"><i class="fas fa-plus"></i> Add Series</a>
</div>

{% include 'media/_messages.html' %}
{% include 'media/_media_tabs.html' with tab_name='series' %}
{% include 'media/_filters.html' with show_type_filter=False %}

<div class="cards-grid">
  <div class="dash-card"><div class="section-title">Tracked Series</div><div>{{ stats.total }}</div></div>
  <div class="dash-card"><div class="section-title">Completed</div><div>{{ stats.completed }}</div></div>
  <div class="dash-card"><div class="section-title">In Progress</div><div>{{ analytics.series_in_progress }}</div></div>
  <div class="dash-card"><div class="section-title">Avg Episodes / Week</div><div>{{ analytics.average_episodes_per_week }}</div></div>
</div>

{% include 'media/_media_table.html' with items=series empty_text='No series found.' %}
{% endblock %}

```

---

## myos_project/media_tracker/tests.py

- Size: 3611 bytes
- Lines: 97
- Modified: 2026-03-06 21:51:38
- SHA256: 2740438548202168cd9e56e916dfa9af23cd2262c0c3d39922e00598ded5d593
- MIME: text/x-script.python

```
from datetime import date

from django.test import TestCase
from django.urls import reverse

from .models import MediaItem, MediaProgress


class MediaTrackerViewsTests(TestCase):
    def setUp(self):
        self.movie = MediaItem.objects.create(
            title="Interstellar",
            category=MediaItem.Category.MOVIE,
            type=MediaItem.MediaType.MOVIE,
            genre="Sci-Fi",
            duration=169,
            status=MediaItem.Status.PLANNED,
        )
        self.series = MediaItem.objects.create(
            title="Dark",
            category=MediaItem.Category.SERIES,
            type=MediaItem.MediaType.SERIES,
            genre="Sci-Fi, Thriller",
            total_seasons=3,
            total_episodes=26,
            episode_duration=55,
            status=MediaItem.Status.WATCHING,
        )

    def test_dashboard_renders(self):
        response = self.client.get(reverse("media"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Media Dashboard")

    def test_add_media_creates_record(self):
        payload = {
            "title": "Arcane",
            "category": MediaItem.Category.ANIMATION,
            "type": MediaItem.MediaType.SERIES,
            "genre": "Fantasy",
            "studio": "Fortiche",
            "country": "France",
            "year": 2021,
            "platform": "Netflix",
            "duration": "",
            "total_seasons": 2,
            "total_episodes": 18,
            "episode_duration": 42,
            "status": MediaItem.Status.PLANNED,
        }
        response = self.client.post(reverse("add_media"), payload)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(MediaItem.objects.filter(title="Arcane").exists())

    def test_update_progress_marks_item_completed(self):
        payload = {
            "episodes_watched": 26,
            "current_season": 3,
            "current_episode": 8,
            "date_watched": date.today().isoformat(),
            "completed": "on",
            "rating": 9,
            "notes": "Finished",
        }
        response = self.client.post(reverse("update_progress", args=[self.series.id]), payload)
        self.assertEqual(response.status_code, 302)

        self.series.refresh_from_db()
        self.assertEqual(self.series.status, MediaItem.Status.COMPLETED)
        self.assertTrue(MediaProgress.objects.filter(media_item=self.series).exists())

    def test_media_api_endpoints(self):
        MediaProgress.objects.create(
            media_item=self.series,
            episodes_watched=10,
            current_season=2,
            current_episode=1,
            completed=False,
        )

        stats_response = self.client.get(reverse("api_media_stats"))
        self.assertEqual(stats_response.status_code, 200)
        stats_data = stats_response.json()
        for key in ("completion_rate", "genre_distribution", "watch_time", "episodes_per_month"):
            self.assertIn(key, stats_data)

        movies_response = self.client.get(reverse("api_media_movies"))
        self.assertEqual(movies_response.status_code, 200)
        self.assertIn("movies_watched_count", movies_response.json())

        series_response = self.client.get(reverse("api_media_series"))
        self.assertEqual(series_response.status_code, 200)
        self.assertIn("episodes_per_month", series_response.json())

        anime_response = self.client.get(reverse("api_media_anime"))
        self.assertEqual(anime_response.status_code, 200)
        self.assertIn("completion_rate", anime_response.json())

```

---

## myos_project/media_tracker/urls.py

- Size: 1094 bytes
- Lines: 20
- Modified: 2026-03-06 21:50:30
- SHA256: b0e9cd5c00fc76c46a870ee782c41d8d9c2d730d53b2debe776c04b73ac777ca
- MIME: text/x-script.python

```
from django.urls import path

from . import views

urlpatterns = [
    path("media/", views.media_dashboard, name="media"),
    path("media/dashboard/", views.media_dashboard, name="media_dashboard"),
    path("media/movies/", views.movies_view, name="movies_view"),
    path("media/series/", views.series_view, name="series_view"),
    path("media/anime/", views.anime_view, name="anime_view"),
    path("media/animation/", views.animation_view, name="animation_view"),
    path("media/add/", views.add_media, name="add_media"),
    path("media/edit/<int:item_id>/", views.edit_media, name="edit_media"),
    path("media/delete/<int:item_id>/", views.delete_media, name="delete_media"),
    path("media/progress/<int:item_id>/", views.update_progress, name="update_progress"),
    path("api/media/stats/", views.api_media_stats, name="api_media_stats"),
    path("api/media/movies/", views.api_media_movies, name="api_media_movies"),
    path("api/media/series/", views.api_media_series, name="api_media_series"),
    path("api/media/anime/", views.api_media_anime, name="api_media_anime"),
]

```

---

## myos_project/media_tracker/views.py

- Size: 13892 bytes
- Lines: 389
- Modified: 2026-03-06 21:53:06
- SHA256: 23385b79a0374564faf324ac0f532fed399e6edc397fdc04fd9f31e5a2caed7d
- MIME: text/x-script.python

```
from collections import Counter

from django.contrib import messages
from django.db.models import Q, Sum
from django.db.models.functions import TruncMonth
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_http_methods

from .analytics import anime_analytics, global_media_analytics, movies_analytics, series_analytics
from .forms import MediaItemForm, MediaProgressForm
from .models import MediaItem, MediaProgress
from .services import (
    PROGRESS_PREFETCH,
    calculate_completion_rate,
    calculate_watch_time,
    get_animation_stats,
    get_anime_stats,
    get_movies_stats,
    get_series_stats,
)


CATEGORY_ROUTE_MAP = {
    MediaItem.Category.MOVIE: "movies_view",
    MediaItem.Category.SERIES: "series_view",
    MediaItem.Category.ANIME: "anime_view",
    MediaItem.Category.ANIMATION: "animation_view",
}


def _base_queryset(request):
    queryset = MediaItem.objects.select_related("user")
    if request.user.is_authenticated:
        return queryset.filter(Q(user=request.user) | Q(user__isnull=True))
    return queryset.filter(user__isnull=True)


def _safe_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _apply_filters(queryset, request):
    q = (request.GET.get("q") or "").strip()
    status = (request.GET.get("status") or "").strip()
    media_type = (request.GET.get("type") or "").strip()
    platform = (request.GET.get("platform") or "").strip()
    genre = (request.GET.get("genre") or "").strip()
    year = _safe_int(request.GET.get("year"))

    if q:
        queryset = queryset.filter(
            Q(title__icontains=q)
            | Q(genre__icontains=q)
            | Q(studio__icontains=q)
            | Q(platform__icontains=q)
            | Q(country__icontains=q)
        )
    if status in {choice for choice, _ in MediaItem.Status.choices}:
        queryset = queryset.filter(status=status)
    if media_type in {choice for choice, _ in MediaItem.MediaType.choices}:
        queryset = queryset.filter(type=media_type)
    if platform:
        queryset = queryset.filter(platform__icontains=platform)
    if genre:
        queryset = queryset.filter(genre__icontains=genre)
    if year is not None:
        queryset = queryset.filter(year=year)

    return queryset


def _genre_distribution(items):
    counter = Counter()
    for item in items:
        raw = (item.genre or "").strip()
        if not raw:
            continue
        for chunk in [piece.strip() for piece in raw.split(",") if piece.strip()]:
            counter[chunk] += 1
    return [{"genre": genre, "count": count} for genre, count in counter.most_common()]


def _episodes_per_month(progress_queryset):
    rows = (
        progress_queryset.annotate(month=TruncMonth("date_watched"))
        .values("month")
        .annotate(total=Sum("episodes_watched"))
        .order_by("month")
    )
    return [
        {
            "month": row["month"].strftime("%Y-%m") if row["month"] else "",
            "value": int(row["total"] or 0),
        }
        for row in rows
    ]


def _category_route_name(category):
    return CATEGORY_ROUTE_MAP.get(category, "media")


def _filters_context(request):
    return {
        "q": (request.GET.get("q") or "").strip(),
        "status": (request.GET.get("status") or "").strip(),
        "type": (request.GET.get("type") or "").strip(),
        "platform": (request.GET.get("platform") or "").strip(),
        "genre": (request.GET.get("genre") or "").strip(),
        "year": (request.GET.get("year") or "").strip(),
    }


def media_dashboard(request):
    base_qs = _apply_filters(_base_queryset(request), request)
    recent_media = list(
        base_qs.prefetch_related(PROGRESS_PREFETCH).order_by("-date_added", "-id")[:12]
    )

    movies_qs = base_qs.filter(category=MediaItem.Category.MOVIE)
    series_qs = base_qs.filter(category=MediaItem.Category.SERIES)
    anime_qs = base_qs.filter(category=MediaItem.Category.ANIME)
    animation_qs = base_qs.filter(category=MediaItem.Category.ANIMATION)

    global_analytics = global_media_analytics()
    watch_hours = global_analytics.get("total_watch_time", {}).get("hours", 0)

    context = {
        "active_page": "media",
        "recent_media": recent_media,
        "movies_stats": get_movies_stats(movies_qs),
        "series_stats": get_series_stats(series_qs),
        "anime_stats": get_anime_stats(anime_qs),
        "animation_stats": get_animation_stats(animation_qs),
        "global_analytics": global_analytics,
        "watch_time_message": f"You watched {watch_hours:.2f} hours of content this year.",
        "filters": _filters_context(request),
        "status_choices": MediaItem.Status.choices,
        "type_choices": MediaItem.MediaType.choices,
    }
    return render(request, "media/media.html", context)


def movies_view(request):
    queryset = _apply_filters(_base_queryset(request).filter(category=MediaItem.Category.MOVIE), request)
    stats = get_movies_stats(queryset)
    context = {
        "active_page": "media",
        "movies": stats["items"],
        "stats": stats,
        "analytics": movies_analytics(),
        "filters": _filters_context(request),
        "status_choices": MediaItem.Status.choices,
    }
    return render(request, "media/movies.html", context)


def series_view(request):
    queryset = _apply_filters(_base_queryset(request).filter(category=MediaItem.Category.SERIES), request)
    stats = get_series_stats(queryset)
    context = {
        "active_page": "media",
        "series": stats["items"],
        "stats": stats,
        "analytics": series_analytics(),
        "filters": _filters_context(request),
        "status_choices": MediaItem.Status.choices,
    }
    return render(request, "media/series.html", context)


def anime_view(request):
    queryset = _apply_filters(_base_queryset(request).filter(category=MediaItem.Category.ANIME), request)
    stats = get_anime_stats(queryset)
    items = stats["items"]
    context = {
        "active_page": "media",
        "anime": items,
        "anime_movies": [item for item in items if item.type == MediaItem.MediaType.MOVIE],
        "anime_series": [item for item in items if item.type == MediaItem.MediaType.SERIES],
        "stats": stats,
        "analytics": anime_analytics(),
        "filters": _filters_context(request),
        "status_choices": MediaItem.Status.choices,
        "type_choices": MediaItem.MediaType.choices,
    }
    return render(request, "media/anime.html", context)


def animation_view(request):
    queryset = _apply_filters(_base_queryset(request).filter(category=MediaItem.Category.ANIMATION), request)
    stats = get_animation_stats(queryset)
    items = stats["items"]
    context = {
        "active_page": "media",
        "animation": items,
        "animation_movies": [item for item in items if item.type == MediaItem.MediaType.MOVIE],
        "animation_series": [item for item in items if item.type == MediaItem.MediaType.SERIES],
        "stats": stats,
        "filters": _filters_context(request),
        "status_choices": MediaItem.Status.choices,
        "type_choices": MediaItem.MediaType.choices,
    }
    return render(request, "media/animation.html", context)


@require_http_methods(["GET", "POST"])
def add_media(request):
    initial = {
        key: request.GET.get(key)
        for key in ("category", "type", "status")
        if request.GET.get(key)
    }

    if request.method == "POST":
        form = MediaItemForm(request.POST)
        if form.is_valid():
            media_item = form.save(commit=False)
            if request.user.is_authenticated:
                media_item.user = request.user
            media_item.save()
            messages.success(request, f'Added "{media_item.title}" to your media tracker.')
            return redirect(_category_route_name(media_item.category))
    else:
        form = MediaItemForm(initial=initial)

    context = {
        "active_page": "media",
        "form": form,
        "page_title": "Add Media",
        "submit_label": "Create",
    }
    return render(request, "media/media_form.html", context)


@require_http_methods(["GET", "POST"])
def edit_media(request, item_id):
    media_item = get_object_or_404(_base_queryset(request), id=item_id)

    if request.method == "POST":
        form = MediaItemForm(request.POST, instance=media_item)
        if form.is_valid():
            updated_item = form.save()
            messages.success(request, f'Updated "{updated_item.title}".')
            return redirect(_category_route_name(updated_item.category))
    else:
        form = MediaItemForm(instance=media_item)

    context = {
        "active_page": "media",
        "form": form,
        "media_item": media_item,
        "page_title": "Edit Media",
        "submit_label": "Save changes",
    }
    return render(request, "media/media_form.html", context)


@require_http_methods(["GET", "POST"])
def delete_media(request, item_id):
    media_item = get_object_or_404(_base_queryset(request), id=item_id)

    if request.method == "POST":
        route_name = _category_route_name(media_item.category)
        deleted_title = media_item.title
        media_item.delete()
        messages.success(request, f'Deleted "{deleted_title}".')
        return redirect(route_name)

    context = {
        "active_page": "media",
        "media_item": media_item,
    }
    return render(request, "media/media_confirm_delete.html", context)


@require_http_methods(["GET", "POST"])
def update_progress(request, item_id):
    media_item = get_object_or_404(_base_queryset(request), id=item_id)
    latest = media_item.latest_progress_entry()

    if request.method == "POST":
        form = MediaProgressForm(request.POST, media_item=media_item)
        if form.is_valid():
            progress = form.save(commit=False)
            progress.media_item = media_item
            progress.save()

            if progress.completed:
                new_status = MediaItem.Status.COMPLETED
            elif (progress.episodes_watched or 0) > 0:
                new_status = MediaItem.Status.WATCHING
            else:
                new_status = media_item.status

            if new_status != media_item.status:
                media_item.status = new_status
                media_item.save(update_fields=["status"])

            messages.success(request, f'Progress updated for "{media_item.title}".')
            return redirect(_category_route_name(media_item.category))
    else:
        initial = {}
        if latest:
            initial = {
                "episodes_watched": latest.episodes_watched,
                "current_season": latest.current_season,
                "current_episode": latest.current_episode,
                "date_watched": latest.date_watched,
                "completed": latest.completed,
                "rating": latest.rating,
                "notes": latest.notes,
            }
        form = MediaProgressForm(media_item=media_item, initial=initial)

    context = {
        "active_page": "media",
        "form": form,
        "media_item": media_item,
        "latest_progress": latest,
    }
    return render(request, "media/progress_form.html", context)


@require_GET
def api_media_stats(request):
    queryset = _apply_filters(_base_queryset(request), request)
    items = list(queryset.prefetch_related(PROGRESS_PREFETCH))

    payload = {
        "completion_rate": calculate_completion_rate(items),
        "genre_distribution": _genre_distribution(items),
        "watch_time": calculate_watch_time(items),
        "episodes_per_month": _episodes_per_month(MediaProgress.objects.filter(media_item__in=queryset)),
        "global": global_media_analytics(),
    }
    return JsonResponse(payload)


@require_GET
def api_media_movies(request):
    analytics = movies_analytics()
    payload = {
        "completion_rate": analytics.get("completion_rate", 0.0),
        "genre_distribution": analytics.get("genre_distribution", []),
        "watch_time": analytics.get("watch_time", {"minutes": 0, "hours": 0.0}),
        "episodes_per_month": [
            {"month": row.get("month", ""), "value": int(row.get("count", 0))}
            for row in analytics.get("movies_per_month", [])
        ],
        "movies_watched_count": analytics.get("movies_watched_count", 0),
        "movies_remaining_count": analytics.get("movies_remaining_count", 0),
        "movies_per_month": analytics.get("movies_per_month", []),
    }
    return JsonResponse(payload)


@require_GET
def api_media_series(request):
    analytics = series_analytics()
    payload = {
        "completion_rate": analytics.get("completion_rate", 0.0),
        "genre_distribution": analytics.get("genre_distribution", []),
        "watch_time": analytics.get("watch_time", {"minutes": 0, "hours": 0.0}),
        "episodes_per_month": analytics.get("episodes_watched_per_month", []),
        "series_completed": analytics.get("series_completed", 0),
        "series_in_progress": analytics.get("series_in_progress", 0),
        "average_episodes_per_week": analytics.get("average_episodes_per_week", 0.0),
    }
    return JsonResponse(payload)


@require_GET
def api_media_anime(request):
    analytics = anime_analytics()
    payload = {
        "completion_rate": analytics.get("anime_completion_rate", 0.0),
        "genre_distribution": analytics.get("anime_by_genre", []),
        "watch_time": analytics.get("watch_time", {"minutes": 0, "hours": 0.0}),
        "episodes_per_month": _episodes_per_month(
            MediaProgress.objects.filter(media_item__category=MediaItem.Category.ANIME)
        ),
        "episodes_watched": analytics.get("episodes_watched", 0),
    }
    return JsonResponse(payload)

```

---

## myos_project/myos_app/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 17:18:56
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_project/myos_app/admin.py

- Size: 7681 bytes
- Lines: 215
- Modified: 2026-03-06 21:30:59
- SHA256: 53e69a50ffbe03ed35b8d4c24d79ffd6b5e57efbb74e279280b1ce6353c84879
- MIME: text/x-script.python

```
from django.contrib import admin

from .models import (
    AcademicLevel,
    ApplicationDocument,
    ApplicationCost,
    Budget,
    Category,
    DiaryEntry,
    ExamCertification,
    FinanceAlert,
    IdentityDocuments,
    IdentityUploadedFile,
    NotificationPreference,
    PageFormData,
    PasswordReferences,
    PersonalIdentityVault,
    ContactInfo,
    DigitalAccounts,
    Project,
    ProjectBudget,
    RecurringExpenseTemplate,
    SavingsGoal,
    Scholarship,
    ScholarshipApplication,
    ScholarshipRequirement,
    SocialProfiles,
    Task,
    Transaction,
    UploadedDocument,
    UserProfile,
)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("display_name", "email", "timezone", "updated_at")


@admin.register(NotificationPreference)
class NotificationPreferenceAdmin(admin.ModelAdmin):
    list_display = ("scholarship_deadlines", "task_due_alerts", "diary_prompt", "finance_alerts", "updated_at")


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ("title", "is_done", "sort_order", "updated_at")
    list_editable = ("is_done", "sort_order")
    ordering = ("sort_order", "id")


@admin.register(DiaryEntry)
class DiaryEntryAdmin(admin.ModelAdmin):
    list_display = ("entry_date", "mood", "created_at")
    ordering = ("-entry_date", "-id")


@admin.register(PageFormData)
class PageFormDataAdmin(admin.ModelAdmin):
    list_display = ("page_slug", "updated_at")
    search_fields = ("page_slug",)


@admin.register(UploadedDocument)
class UploadedDocumentAdmin(admin.ModelAdmin):
    list_display = ("page_slug", "field_key", "original_name", "file_size", "uploaded_at")
    search_fields = ("page_slug", "field_key", "original_name", "label")
    list_filter = ("page_slug", "field_key")


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "color", "is_active", "sort_order", "updated_at")
    search_fields = ("name", "slug")
    list_filter = ("kind", "is_active")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ("tx_date", "description", "category", "account", "tx_type", "amount")
    list_filter = ("tx_type", "account", "category")
    search_fields = ("description", "notes")
    date_hierarchy = "tx_date"


@admin.register(Budget)
class BudgetAdmin(admin.ModelAdmin):
    list_display = ("category", "period_start", "monthly_limit", "warning_threshold_pct", "is_active")
    list_filter = ("is_active", "period_start")


@admin.register(SavingsGoal)
class SavingsGoalAdmin(admin.ModelAdmin):
    list_display = ("name", "target_amount", "starting_amount", "deadline", "status")
    list_filter = ("status",)
    search_fields = ("name",)


@admin.register(ApplicationCost)
class ApplicationCostAdmin(admin.ModelAdmin):
    list_display = ("item_type", "estimated_cost", "actual_cost", "status", "deadline")
    list_filter = ("item_type", "status")


@admin.register(ProjectBudget)
class ProjectBudgetAdmin(admin.ModelAdmin):
    list_display = ("project_name", "budget_amount", "manual_spent_adjustment", "roi_target_pct", "roi_actual_pct", "status")
    list_filter = ("status",)
    search_fields = ("project_name",)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("title", "status", "progress", "start_date", "end_date", "updated_at")
    list_filter = ("status",)
    search_fields = ("title", "description")


@admin.register(RecurringExpenseTemplate)
class RecurringExpenseTemplateAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "account", "amount", "cadence", "next_due_date", "is_active")
    list_filter = ("cadence", "is_active", "account")


@admin.register(FinanceAlert)
class FinanceAlertAdmin(admin.ModelAdmin):
    list_display = ("alert_type", "severity", "message", "related_model", "related_id", "period_key", "is_read", "created_at")
    list_filter = ("alert_type", "severity", "is_read")
    search_fields = ("message", "related_model", "period_key")


@admin.register(AcademicLevel)
class AcademicLevelAdmin(admin.ModelAdmin):
    list_display = ("level_type", "school_name", "status", "start_year", "end_year", "updated_at")
    list_filter = ("level_type", "status", "certification_exam_completed")
    search_fields = ("school_name", "university_name", "admission_number", "student_number")


@admin.register(ExamCertification)
class ExamCertificationAdmin(admin.ModelAdmin):
    list_display = ("exam_name", "academic_level", "exam_year", "candidate_number", "grade_score", "updated_at")
    list_filter = ("exam_year",)
    search_fields = ("exam_name", "candidate_number", "grade_score", "academic_level__school_name")


@admin.register(ApplicationDocument)
class ApplicationDocumentAdmin(admin.ModelAdmin):
    list_display = ("title", "document_type", "version", "expiration_date", "updated_at")
    list_filter = ("document_type",)
    search_fields = ("title", "version", "notes")


@admin.register(Scholarship)
class ScholarshipAdmin(admin.ModelAdmin):
    list_display = ("name", "country", "university", "degree_level", "application_deadline", "is_active")
    list_filter = ("country", "degree_level", "is_active")
    search_fields = ("name", "country", "university", "field_of_study")


@admin.register(ScholarshipApplication)
class ScholarshipApplicationAdmin(admin.ModelAdmin):
    list_display = ("scholarship", "status", "is_submitted", "submission_date", "application_id", "updated_at")
    list_filter = ("status", "is_submitted")
    search_fields = ("scholarship__name", "application_id")


@admin.register(ScholarshipRequirement)
class ScholarshipRequirementAdmin(admin.ModelAdmin):
    list_display = ("scholarship", "requirement_name", "is_required", "is_completed", "linked_document", "sort_order")
    list_filter = ("is_required", "is_completed")
    search_fields = ("scholarship__name", "requirement_name")


@admin.register(PersonalIdentityVault)
class PersonalIdentityVaultAdmin(admin.ModelAdmin):
    list_display = ("first_name", "last_name", "dob", "gender", "nationality", "updated_at")
    search_fields = ("first_name", "last_name", "nationality")


@admin.register(ContactInfo)
class ContactInfoAdmin(admin.ModelAdmin):
    list_display = ("vault", "primary_email", "primary_phone", "city", "country", "updated_at")
    search_fields = ("primary_email", "primary_phone", "city", "country")


@admin.register(IdentityDocuments)
class IdentityDocumentsAdmin(admin.ModelAdmin):
    list_display = ("vault", "passport_expiry", "updated_at")


@admin.register(IdentityUploadedFile)
class IdentityUploadedFileAdmin(admin.ModelAdmin):
    list_display = ("vault", "file_type", "original_name", "file_size", "updated_at")
    list_filter = ("file_type",)
    search_fields = ("original_name", "vault__first_name", "vault__last_name")


@admin.register(DigitalAccounts)
class DigitalAccountsAdmin(admin.ModelAdmin):
    list_display = ("vault", "platform", "username", "email_used", "updated_at")
    list_filter = ("platform",)
    search_fields = ("username", "email_used", "custom_platform")


@admin.register(SocialProfiles)
class SocialProfilesAdmin(admin.ModelAdmin):
    list_display = ("vault", "linkedin", "twitter_x", "github", "updated_at")


@admin.register(PasswordReferences)
class PasswordReferencesAdmin(admin.ModelAdmin):
    list_display = ("vault", "platform", "username", "email_used", "two_factor_enabled", "password_manager", "updated_at")
    list_filter = ("two_factor_enabled", "password_manager")
    search_fields = ("platform", "username", "email_used", "backup_codes_location")

```

---

## myos_project/myos_app/apps.py

- Size: 147 bytes
- Lines: 6
- Modified: 2026-03-05 17:18:56
- SHA256: 1cbc4f3178ecab599574f5543ed3af6b913a67d27ee1b525f8b58b82f9614b30
- MIME: text/x-script.python

```
from django.apps import AppConfig


class MyosAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myos_app'

```

---

## myos_project/myos_app/migrations/0001_initial.py

- Size: 2821 bytes
- Lines: 65
- Modified: 2026-03-06 21:05:10
- SHA256: c9d1c010393010296e5eca9d403edf6f82be76c23ed5eeb3e3403c514600ea05
- MIME: text/x-script.python

```
# Generated by Django 4.2.11 on 2026-03-05 15:28

from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='DiaryEntry',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('entry_date', models.DateField()),
                ('mood', models.CharField(blank=True, default='', max_length=80)),
                ('content', models.TextField(blank=True, default='')),
                ('achievements', models.TextField(blank=True, default='')),
                ('lessons', models.TextField(blank=True, default='')),
                ('ideas', models.TextField(blank=True, default='')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={
                'ordering': ['-entry_date', '-id'],
            },
        ),
        migrations.CreateModel(
            name='NotificationPreference',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('scholarship_deadlines', models.BooleanField(default=True)),
                ('task_due_alerts', models.BooleanField(default=True)),
                ('diary_prompt', models.BooleanField(default=False)),
                ('finance_alerts', models.BooleanField(default=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='Task',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=255)),
                ('is_done', models.BooleanField(default=False)),
                ('sort_order', models.PositiveIntegerField(default=0)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'ordering': ['sort_order', 'id'],
            },
        ),
        migrations.CreateModel(
            name='UserProfile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('display_name', models.CharField(blank=True, default='', max_length=120)),
                ('email', models.EmailField(blank=True, default='', max_length=254)),
                ('timezone', models.CharField(default='UTC', max_length=80)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
        ),
    ]

```

---

## myos_project/myos_app/migrations/0002_pageformdata.py

- Size: 749 bytes
- Lines: 25
- Modified: 2026-03-05 19:54:52
- SHA256: dda051d0a369827b1ca50de1d30dbf2a7825994bd7fe25e66e6f0d2553849689
- MIME: text/x-script.python

```
# Generated by Django 6.0.3 on 2026-03-05 16:54

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('myos_app', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='PageFormData',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('page_slug', models.CharField(max_length=50, unique=True)),
                ('data', models.JSONField(blank=True, default=dict)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'ordering': ['page_slug'],
            },
        ),
    ]

```

---

## myos_project/myos_app/migrations/0003_uploadeddocument.py

- Size: 1242 bytes
- Lines: 31
- Modified: 2026-03-05 20:33:07
- SHA256: bb6e6590e7523ead11e1d84d501f0dcb1ade312dc9e64225ad9466d27123aa94
- MIME: text/x-script.python

```
# Generated by Django 6.0.3 on 2026-03-05 17:33

import myos_app.models
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('myos_app', '0002_pageformdata'),
    ]

    operations = [
        migrations.CreateModel(
            name='UploadedDocument',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('page_slug', models.CharField(db_index=True, max_length=50)),
                ('field_key', models.CharField(db_index=True, max_length=80)),
                ('label', models.CharField(blank=True, default='', max_length=120)),
                ('file', models.FileField(upload_to=myos_app.models.uploaded_document_path)),
                ('original_name', models.CharField(blank=True, default='', max_length=255)),
                ('content_type', models.CharField(blank=True, default='', max_length=120)),
                ('file_size', models.PositiveIntegerField(default=0)),
                ('uploaded_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={
                'ordering': ['-uploaded_at', '-id'],
            },
        ),
    ]

```

---

## myos_project/myos_app/migrations/0004_applicationcost_category_projectbudget_savingsgoal_and_more.py

- Size: 11673 bytes
- Lines: 163
- Modified: 2026-03-05 21:45:02
- SHA256: 0ac84c3b53b76d97330509433b225a7e22828ca9acf12eea4a1bf41cb6f5d0bc
- MIME: text/x-script.python

```
# Generated by Django 6.0.3 on 2026-03-05 18:45

import django.core.validators
import django.db.models.deletion
from decimal import Decimal
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('myos_app', '0003_uploadeddocument'),
    ]

    operations = [
        migrations.CreateModel(
            name='ApplicationCost',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('item_type', models.CharField(choices=[('passport', 'Passport'), ('sat', 'SAT'), ('ielts', 'IELTS'), ('toefl', 'TOEFL'), ('goethe', 'Goethe'), ('visa', 'Visa'), ('certified_documents', 'Certified Documents'), ('application_fees', 'Application Fees'), ('travel', 'Travel'), ('other', 'Other')], default='other', max_length=32)),
                ('estimated_cost', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.00'))])),
                ('actual_cost', models.DecimalField(blank=True, decimal_places=2, max_digits=14, null=True, validators=[django.core.validators.MinValueValidator(Decimal('0.00'))])),
                ('status', models.CharField(choices=[('planned', 'Planned'), ('in_progress', 'In Progress'), ('paid', 'Paid'), ('waived', 'Waived'), ('cancelled', 'Cancelled')], default='planned', max_length=20)),
                ('deadline', models.DateField(blank=True, null=True)),
                ('notes', models.TextField(blank=True, default='')),
            ],
            options={
                'ordering': ['deadline', 'item_type'],
            },
        ),
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('name', models.CharField(max_length=80)),
                ('slug', models.SlugField(max_length=90, unique=True)),
                ('kind', models.CharField(choices=[('income', 'Income'), ('expense', 'Expense'), ('savings', 'Savings'), ('application', 'Application'), ('business', 'Business'), ('investment', 'Investment'), ('transfer', 'Transfer'), ('other', 'Other')], default='expense', max_length=20)),
                ('color', models.CharField(default='#8B5A2B', max_length=16)),
                ('icon', models.CharField(default='fa-wallet', max_length=40)),
                ('is_active', models.BooleanField(default=True)),
                ('sort_order', models.PositiveIntegerField(default=0)),
            ],
            options={
                'ordering': ['sort_order', 'name'],
            },
        ),
        migrations.CreateModel(
            name='ProjectBudget',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('project_name', models.CharField(max_length=160)),
                ('budget_amount', models.DecimalField(decimal_places=2, max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.01'))])),
                ('manual_spent_adjustment', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.00'))])),
                ('roi_target_pct', models.DecimalField(blank=True, decimal_places=2, max_digits=7, null=True)),
                ('roi_actual_pct', models.DecimalField(blank=True, decimal_places=2, max_digits=7, null=True)),
                ('status', models.CharField(choices=[('active', 'Active'), ('completed', 'Completed'), ('on_hold', 'On Hold')], default='active', max_length=20)),
            ],
            options={
                'ordering': ['project_name'],
            },
        ),
        migrations.CreateModel(
            name='SavingsGoal',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('name', models.CharField(max_length=120)),
                ('target_amount', models.DecimalField(decimal_places=2, max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.01'))])),
                ('starting_amount', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.00'))])),
                ('deadline', models.DateField(blank=True, null=True)),
                ('status', models.CharField(choices=[('active', 'Active'), ('completed', 'Completed'), ('paused', 'Paused')], default='active', max_length=20)),
                ('monthly_target_suggestion', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.00'))])),
            ],
            options={
                'ordering': ['deadline', 'name'],
            },
        ),
        migrations.CreateModel(
            name='FinanceAlert',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('alert_type', models.CharField(choices=[('budget_overrun', 'Budget Overrun'), ('deadline', 'Deadline'), ('cashflow', 'Cashflow'), ('goal_risk', 'Goal Risk')], max_length=32)),
                ('severity', models.CharField(choices=[('info', 'Info'), ('warning', 'Warning'), ('critical', 'Critical')], default='info', max_length=16)),
                ('message', models.CharField(max_length=255)),
                ('related_model', models.CharField(blank=True, default='', max_length=40)),
                ('related_id', models.PositiveIntegerField(blank=True, null=True)),
                ('period_key', models.CharField(default='', max_length=20)),
                ('is_read', models.BooleanField(default=False)),
            ],
            options={
                'ordering': ['-created_at'],
                'constraints': [models.UniqueConstraint(fields=('alert_type', 'related_model', 'related_id', 'period_key'), name='unique_finance_alert_scope')],
            },
        ),
        migrations.CreateModel(
            name='RecurringExpenseTemplate',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('name', models.CharField(max_length=140)),
                ('account', models.CharField(choices=[('cash', 'Cash'), ('bank', 'Bank'), ('mobile_money', 'Mobile Money')], default='bank', max_length=20)),
                ('amount', models.DecimalField(decimal_places=2, max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.01'))])),
                ('cadence', models.CharField(choices=[('weekly', 'Weekly'), ('monthly', 'Monthly'), ('yearly', 'Yearly')], default='monthly', max_length=20)),
                ('next_due_date', models.DateField(db_index=True)),
                ('end_date', models.DateField(blank=True, null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('category', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='recurring_templates', to='myos_app.category')),
            ],
            options={
                'ordering': ['next_due_date', 'name'],
            },
        ),
        migrations.CreateModel(
            name='Budget',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('period_start', models.DateField(db_index=True)),
                ('monthly_limit', models.DecimalField(decimal_places=2, max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.01'))])),
                ('warning_threshold_pct', models.PositiveSmallIntegerField(default=90, validators=[django.core.validators.MinValueValidator(1), django.core.validators.MaxValueValidator(100)])),
                ('is_active', models.BooleanField(default=True)),
                ('category', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='budgets', to='myos_app.category')),
            ],
            options={
                'ordering': ['-period_start', 'category__name'],
                'constraints': [models.UniqueConstraint(fields=('category', 'period_start'), name='unique_budget_category_period')],
            },
        ),
        migrations.CreateModel(
            name='Transaction',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('tx_date', models.DateField(db_index=True)),
                ('description', models.CharField(max_length=220)),
                ('account', models.CharField(choices=[('cash', 'Cash'), ('bank', 'Bank'), ('mobile_money', 'Mobile Money')], default='bank', max_length=20)),
                ('tx_type', models.CharField(choices=[('income', 'Income'), ('expense', 'Expense'), ('transfer', 'Transfer'), ('savings', 'Savings')], default='expense', max_length=20)),
                ('amount', models.DecimalField(db_index=True, decimal_places=2, max_digits=14, validators=[django.core.validators.MinValueValidator(Decimal('0.01'))])),
                ('tags', models.JSONField(blank=True, default=list)),
                ('notes', models.TextField(blank=True, default='')),
                ('application_cost', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='transactions', to='myos_app.applicationcost')),
                ('category', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='transactions', to='myos_app.category')),
                ('project_budget', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='transactions', to='myos_app.projectbudget')),
                ('savings_goal', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='transactions', to='myos_app.savingsgoal')),
            ],
            options={
                'ordering': ['-tx_date', '-id'],
                'indexes': [models.Index(fields=['tx_date', 'category'], name='myos_app_tr_tx_date_651646_idx'), models.Index(fields=['tx_date', 'account'], name='myos_app_tr_tx_date_9cd894_idx')],
            },
        ),
    ]

```

---

## myos_project/myos_app/migrations/0005_seed_finance_defaults.py

- Size: 452 bytes
- Lines: 21
- Modified: 2026-03-06 21:00:38
- SHA256: e7bbd95dabfcb30dd6f788cb7a859cc21044ecf4c3bee085db3f47619ed30cd9
- MIME: text/x-script.python

```
from django.db import migrations


def seed_finance_defaults(apps, schema_editor):
    # Intentionally no-op in production-ready setups.
    return


def reverse_noop(apps, schema_editor):
    return


class Migration(migrations.Migration):

    dependencies = [
        ("myos_app", "0004_applicationcost_category_projectbudget_savingsgoal_and_more"),
    ]

    operations = [
        migrations.RunPython(seed_finance_defaults, reverse_noop),
    ]

```

---

## myos_project/myos_app/migrations/0006_academiclevel_applicationdocument_scholarship_and_more.py

- Size: 9706 bytes
- Lines: 146
- Modified: 2026-03-05 22:56:45
- SHA256: 01ec69e1b3267eefe68b6bb7b4c8152ec48b5f57597c3c548bc4b9b144585b72
- MIME: text/x-script.python

```
# Generated by Django 6.0.3 on 2026-03-05 19:56

import django.core.validators
import django.db.models.deletion
import myos_app.models
from decimal import Decimal
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('myos_app', '0005_seed_finance_defaults'),
    ]

    operations = [
        migrations.CreateModel(
            name='AcademicLevel',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('level_type', models.CharField(choices=[('primary', 'Primary School'), ('secondary', 'Secondary School'), ('university', 'University'), ('certification', 'Certifications / Courses')], max_length=24)),
                ('status', models.CharField(choices=[('completed', 'Completed'), ('in_progress', 'In Progress'), ('planned', 'Planned')], default='planned', max_length=20)),
                ('school_name', models.CharField(blank=True, default='', max_length=180)),
                ('admission_number', models.CharField(blank=True, default='', max_length=80)),
                ('location', models.CharField(blank=True, default='', max_length=160)),
                ('start_year', models.PositiveIntegerField(blank=True, null=True)),
                ('end_year', models.PositiveIntegerField(blank=True, null=True)),
                ('subjects_taken', models.TextField(blank=True, default='')),
                ('grades', models.TextField(blank=True, default='')),
                ('certification_exam_completed', models.BooleanField(default=False)),
                ('certificate_file', models.FileField(blank=True, null=True, upload_to=myos_app.models.academic_file_upload_path)),
                ('university_name', models.CharField(blank=True, default='', max_length=180)),
                ('country', models.CharField(blank=True, default='', max_length=120)),
                ('degree', models.CharField(blank=True, default='', max_length=120)),
                ('major_program', models.CharField(blank=True, default='', max_length=180)),
                ('expected_graduation_year', models.PositiveIntegerField(blank=True, null=True)),
                ('student_number', models.CharField(blank=True, default='', max_length=80)),
                ('gpa', models.CharField(blank=True, default='', max_length=20)),
                ('transcript_file', models.FileField(blank=True, null=True, upload_to=myos_app.models.academic_file_upload_path)),
                ('research_topic', models.TextField(blank=True, default='')),
                ('internships', models.TextField(blank=True, default='')),
                ('clubs_activities', models.TextField(blank=True, default='')),
                ('awards', models.TextField(blank=True, default='')),
                ('notes', models.TextField(blank=True, default='')),
            ],
            options={
                'ordering': ['level_type', '-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='ApplicationDocument',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('title', models.CharField(max_length=180)),
                ('document_type', models.CharField(choices=[('personal_statement', 'Personal Statement'), ('cv_resume', 'CV / Resume'), ('financial_statement', 'Financial Statement'), ('academic_transcript', 'Academic Transcript'), ('recommendation_letter', 'Recommendation Letter'), ('passport_copy', 'Passport Copy'), ('certificate', 'Certificate'), ('other', 'Other')], default='other', max_length=32)),
                ('file', models.FileField(upload_to=myos_app.models.document_file_upload_path)),
                ('version', models.CharField(blank=True, default='v1', max_length=40)),
                ('notes', models.TextField(blank=True, default='')),
                ('expiration_date', models.DateField(blank=True, null=True)),
            ],
            options={
                'ordering': ['document_type', '-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='Scholarship',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('name', models.CharField(max_length=220)),
                ('country', models.CharField(blank=True, default='', max_length=120)),
                ('university', models.CharField(blank=True, default='', max_length=180)),
                ('field_of_study', models.CharField(blank=True, default='', max_length=180)),
                ('degree_level', models.CharField(blank=True, default='', max_length=120)),
                ('official_website', models.URLField(blank=True, default='')),
                ('application_deadline', models.DateField(blank=True, null=True)),
                ('tuition_coverage', models.CharField(blank=True, default='', max_length=120)),
                ('monthly_stipend', models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True, validators=[django.core.validators.MinValueValidator(Decimal('0.00'))])),
                ('travel_coverage', models.BooleanField(default=False)),
                ('accommodation', models.BooleanField(default=False)),
                ('other_benefits', models.TextField(blank=True, default='')),
                ('is_active', models.BooleanField(default=True)),
            ],
            options={
                'ordering': ['application_deadline', 'name'],
            },
        ),
        migrations.CreateModel(
            name='ExamCertification',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('exam_name', models.CharField(max_length=120)),
                ('exam_year', models.PositiveIntegerField(blank=True, null=True)),
                ('candidate_number', models.CharField(blank=True, default='', max_length=80)),
                ('grade_score', models.CharField(blank=True, default='', max_length=80)),
                ('certificate_file', models.FileField(blank=True, null=True, upload_to=myos_app.models.exam_file_upload_path)),
                ('notes', models.TextField(blank=True, default='')),
                ('academic_level', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='exam_certifications', to='myos_app.academiclevel')),
            ],
            options={
                'ordering': ['-exam_year', '-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='ScholarshipApplication',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('status', models.CharField(choices=[('researching', 'Researching'), ('preparing_documents', 'Preparing Documents'), ('application_submitted', 'Application Submitted'), ('interview_stage', 'Interview Stage'), ('accepted', 'Accepted'), ('rejected', 'Rejected'), ('waitlisted', 'Waitlisted')], default='researching', max_length=32)),
                ('is_submitted', models.BooleanField(default=False)),
                ('submission_date', models.DateField(blank=True, null=True)),
                ('application_id', models.CharField(blank=True, default='', max_length=120)),
                ('portal_link', models.URLField(blank=True, default='')),
                ('notes', models.TextField(blank=True, default='')),
                ('scholarship', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='application', to='myos_app.scholarship')),
            ],
            options={
                'ordering': ['-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='ScholarshipRequirement',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('requirement_name', models.CharField(max_length=180)),
                ('is_required', models.BooleanField(default=True)),
                ('is_completed', models.BooleanField(default=False)),
                ('sort_order', models.PositiveIntegerField(default=0)),
                ('linked_document', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='linked_requirements', to='myos_app.applicationdocument')),
                ('scholarship', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='requirements', to='myos_app.scholarship')),
            ],
            options={
                'ordering': ['sort_order', 'id'],
            },
        ),
    ]

```

---

## myos_project/myos_app/migrations/0007_personalidentityvault_passwordreferences_and_more.py

- Size: 9234 bytes
- Lines: 145
- Modified: 2026-03-05 23:36:19
- SHA256: 91c642e17a7556a8165fff4ccf2812047b86b84c4246121c02b45d77e655c92d
- MIME: text/x-script.python

```
# Generated by Django 6.0.3 on 2026-03-05 20:36

import django.db.models.deletion
import myos_app.models
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('myos_app', '0006_academiclevel_applicationdocument_scholarship_and_more'),
    ]

    operations = [
        migrations.CreateModel(
            name='PersonalIdentityVault',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('first_name', models.CharField(blank=True, default='', max_length=120)),
                ('last_name', models.CharField(blank=True, default='', max_length=120)),
                ('dob', models.DateField(blank=True, null=True)),
                ('gender', models.CharField(blank=True, choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other'), ('prefer_not_to_say', 'Prefer not to say')], default='', max_length=24)),
                ('nationality', models.CharField(blank=True, default='', max_length=120)),
                ('languages', models.JSONField(blank=True, default=list)),
                ('profile_photo', models.FileField(blank=True, null=True, upload_to=myos_app.models.personal_vault_upload_path)),
            ],
            options={
                'ordering': ['-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='PasswordReferences',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('platform', models.CharField(max_length=120)),
                ('username', models.CharField(blank=True, default='', max_length=180)),
                ('email_used', models.EmailField(blank=True, default='', max_length=254)),
                ('password_hint', models.CharField(blank=True, default='', max_length=255)),
                ('two_factor_enabled', models.BooleanField(default=False)),
                ('backup_codes_location', models.CharField(blank=True, default='', max_length=255)),
                ('password_manager', models.CharField(choices=[('bitwarden', 'Bitwarden'), ('1password', '1Password'), ('proton_pass', 'Proton Pass'), ('other', 'Other')], default='bitwarden', max_length=32)),
                ('notes', models.TextField(blank=True, default='')),
                ('vault', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='password_references', to='myos_app.personalidentityvault')),
            ],
            options={
                'ordering': ['platform', '-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='IdentityUploadedFile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('file_type', models.CharField(choices=[('national_id_scan', 'National ID Scan'), ('passport_scan', 'Passport Scan'), ('certificate', 'Certificate'), ('academic_document', 'Academic Document'), ('other', 'Other Identity Document')], default='other', max_length=32)),
                ('file', models.FileField(upload_to=myos_app.models.personal_vault_upload_path)),
                ('original_name', models.CharField(blank=True, default='', max_length=255)),
                ('file_size', models.PositiveIntegerField(default=0)),
                ('vault', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='uploaded_files', to='myos_app.personalidentityvault')),
            ],
            options={
                'ordering': ['-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='IdentityDocuments',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('national_id_encrypted', models.TextField(blank=True, default='')),
                ('passport_number_encrypted', models.TextField(blank=True, default='')),
                ('passport_expiry', models.DateField(blank=True, null=True)),
                ('drivers_license_encrypted', models.TextField(blank=True, default='')),
                ('student_id_encrypted', models.TextField(blank=True, default='')),
                ('vault', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='identity_documents', to='myos_app.personalidentityvault')),
            ],
            options={
                'ordering': ['-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='DigitalAccounts',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('platform', models.CharField(choices=[('google', 'Google'), ('github', 'GitHub'), ('linkedin', 'LinkedIn'), ('twitter_x', 'Twitter / X'), ('instagram', 'Instagram'), ('facebook', 'Facebook'), ('tiktok', 'TikTok'), ('discord', 'Discord'), ('reddit', 'Reddit'), ('custom', 'Custom')], max_length=24)),
                ('custom_platform', models.CharField(blank=True, default='', max_length=120)),
                ('username', models.CharField(blank=True, default='', max_length=180)),
                ('email_used', models.EmailField(blank=True, default='', max_length=254)),
                ('profile_link', models.URLField(blank=True, default='')),
                ('notes', models.TextField(blank=True, default='')),
                ('vault', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='digital_accounts', to='myos_app.personalidentityvault')),
            ],
            options={
                'ordering': ['platform', '-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='ContactInfo',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('primary_email', models.EmailField(blank=True, default='', max_length=254)),
                ('secondary_email', models.EmailField(blank=True, default='', max_length=254)),
                ('additional_emails', models.JSONField(blank=True, default=list)),
                ('primary_phone', models.CharField(blank=True, default='', max_length=40)),
                ('secondary_phone', models.CharField(blank=True, default='', max_length=40)),
                ('other_phone_numbers', models.JSONField(blank=True, default=list)),
                ('home_address', models.CharField(blank=True, default='', max_length=240)),
                ('city', models.CharField(blank=True, default='', max_length=120)),
                ('country', models.CharField(blank=True, default='', max_length=120)),
                ('postal_code', models.CharField(blank=True, default='', max_length=40)),
                ('vault', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='contact_info', to='myos_app.personalidentityvault')),
            ],
            options={
                'ordering': ['-updated_at', '-id'],
            },
        ),
        migrations.CreateModel(
            name='SocialProfiles',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('linkedin', models.URLField(blank=True, default='')),
                ('twitter_x', models.URLField(blank=True, default='')),
                ('instagram', models.URLField(blank=True, default='')),
                ('github', models.URLField(blank=True, default='')),
                ('portfolio_website', models.URLField(blank=True, default='')),
                ('personal_blog', models.URLField(blank=True, default='')),
                ('youtube_channel', models.URLField(blank=True, default='')),
                ('vault', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='social_profiles', to='myos_app.personalidentityvault')),
            ],
            options={
                'ordering': ['-updated_at', '-id'],
            },
        ),
    ]

```

---

## myos_project/myos_app/migrations/0008_project.py

- Size: 1400 bytes
- Lines: 31
- Modified: 2026-03-06 21:33:50
- SHA256: 3a928c4c3bac0b1d969963471d8ea7f87fd523a833f612efd76b3b3cd05831ab
- MIME: text/x-script.python

```
# Generated by Django 6.0.3 on 2026-03-06 18:33

import django.core.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('myos_app', '0007_personalidentityvault_passwordreferences_and_more'),
    ]

    operations = [
        migrations.CreateModel(
            name='Project',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('title', models.CharField(max_length=160)),
                ('description', models.TextField(blank=True, default='')),
                ('status', models.CharField(choices=[('idea', 'Idea'), ('pending', 'Pending'), ('in_progress', 'In Progress'), ('completed', 'Completed')], default='idea', max_length=20)),
                ('progress', models.PositiveSmallIntegerField(default=0, validators=[django.core.validators.MinValueValidator(0), django.core.validators.MaxValueValidator(100)])),
                ('start_date', models.DateField(blank=True, null=True)),
                ('end_date', models.DateField(blank=True, null=True)),
            ],
            options={
                'ordering': ['-updated_at', '-id'],
            },
        ),
    ]

```

---

## myos_project/myos_app/migrations/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 17:18:56
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_project/myos_app/models.py

- Size: 29857 bytes
- Lines: 780
- Modified: 2026-03-06 21:30:51
- SHA256: 88a8a339b8f02f0279e0bd8b829da30fbee98989075bb1f2e6c4e7c2f4df4268
- MIME: text/x-script.python

```
from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils.text import slugify


class UserProfile(models.Model):
    display_name = models.CharField(max_length=120, blank=True, default="")
    email = models.EmailField(blank=True, default="")
    timezone = models.CharField(max_length=80, default="UTC")
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.display_name


class NotificationPreference(models.Model):
    scholarship_deadlines = models.BooleanField(default=True)
    task_due_alerts = models.BooleanField(default=True)
    diary_prompt = models.BooleanField(default=False)
    finance_alerts = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "Notification Preferences"


class Task(models.Model):
    title = models.CharField(max_length=255)
    is_done = models.BooleanField(default=False)
    sort_order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["sort_order", "id"]

    def __str__(self):
        return self.title


class DiaryEntry(models.Model):
    entry_date = models.DateField()
    mood = models.CharField(max_length=80, blank=True, default="")
    content = models.TextField(blank=True, default="")
    achievements = models.TextField(blank=True, default="")
    lessons = models.TextField(blank=True, default="")
    ideas = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-entry_date", "-id"]

    def __str__(self):
        return f"{self.entry_date} - {self.mood or 'No mood'}"


class PageFormData(models.Model):
    page_slug = models.CharField(max_length=50, unique=True)
    data = models.JSONField(default=dict, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["page_slug"]

    def __str__(self):
        return self.page_slug


def uploaded_document_path(instance, filename):
    safe_page = (instance.page_slug or "general").replace("/", "_")
    safe_key = (instance.field_key or "files").replace("/", "_")
    return f"uploads/{safe_page}/{safe_key}/{filename}"


class UploadedDocument(models.Model):
    page_slug = models.CharField(max_length=50, db_index=True)
    field_key = models.CharField(max_length=80, db_index=True)
    label = models.CharField(max_length=120, blank=True, default="")
    file = models.FileField(upload_to=uploaded_document_path)
    original_name = models.CharField(max_length=255, blank=True, default="")
    content_type = models.CharField(max_length=120, blank=True, default="")
    file_size = models.PositiveIntegerField(default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-uploaded_at", "-id"]

    def __str__(self):
        return f"{self.page_slug}:{self.field_key}:{self.original_name or self.file.name}"


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Category(TimeStampedModel):
    KIND_INCOME = "income"
    KIND_EXPENSE = "expense"
    KIND_SAVINGS = "savings"
    KIND_APPLICATION = "application"
    KIND_BUSINESS = "business"
    KIND_INVESTMENT = "investment"
    KIND_TRANSFER = "transfer"
    KIND_OTHER = "other"

    KIND_CHOICES = (
        (KIND_INCOME, "Income"),
        (KIND_EXPENSE, "Expense"),
        (KIND_SAVINGS, "Savings"),
        (KIND_APPLICATION, "Application"),
        (KIND_BUSINESS, "Business"),
        (KIND_INVESTMENT, "Investment"),
        (KIND_TRANSFER, "Transfer"),
        (KIND_OTHER, "Other"),
    )

    name = models.CharField(max_length=80)
    slug = models.SlugField(max_length=90, unique=True)
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default=KIND_EXPENSE)
    color = models.CharField(max_length=16, default="#8B5A2B")
    icon = models.CharField(max_length=40, default="fa-wallet")
    is_active = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "name"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class SavingsGoal(TimeStampedModel):
    STATUS_ACTIVE = "active"
    STATUS_COMPLETED = "completed"
    STATUS_PAUSED = "paused"

    STATUS_CHOICES = (
        (STATUS_ACTIVE, "Active"),
        (STATUS_COMPLETED, "Completed"),
        (STATUS_PAUSED, "Paused"),
    )

    name = models.CharField(max_length=120)
    target_amount = models.DecimalField(max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    starting_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"), validators=[MinValueValidator(Decimal("0.00"))])
    deadline = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_ACTIVE)
    monthly_target_suggestion = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"), validators=[MinValueValidator(Decimal("0.00"))])

    class Meta:
        ordering = ["deadline", "name"]

    def __str__(self):
        return self.name


class ApplicationCost(TimeStampedModel):
    TYPE_PASSPORT = "passport"
    TYPE_SAT = "sat"
    TYPE_IELTS = "ielts"
    TYPE_TOEFL = "toefl"
    TYPE_GOETHE = "goethe"
    TYPE_VISA = "visa"
    TYPE_CERTIFIED_DOCUMENTS = "certified_documents"
    TYPE_APPLICATION_FEES = "application_fees"
    TYPE_TRAVEL = "travel"
    TYPE_OTHER = "other"

    ITEM_TYPE_CHOICES = (
        (TYPE_PASSPORT, "Passport"),
        (TYPE_SAT, "SAT"),
        (TYPE_IELTS, "IELTS"),
        (TYPE_TOEFL, "TOEFL"),
        (TYPE_GOETHE, "Goethe"),
        (TYPE_VISA, "Visa"),
        (TYPE_CERTIFIED_DOCUMENTS, "Certified Documents"),
        (TYPE_APPLICATION_FEES, "Application Fees"),
        (TYPE_TRAVEL, "Travel"),
        (TYPE_OTHER, "Other"),
    )

    STATUS_PLANNED = "planned"
    STATUS_IN_PROGRESS = "in_progress"
    STATUS_PAID = "paid"
    STATUS_WAIVED = "waived"
    STATUS_CANCELLED = "cancelled"

    STATUS_CHOICES = (
        (STATUS_PLANNED, "Planned"),
        (STATUS_IN_PROGRESS, "In Progress"),
        (STATUS_PAID, "Paid"),
        (STATUS_WAIVED, "Waived"),
        (STATUS_CANCELLED, "Cancelled"),
    )

    item_type = models.CharField(max_length=32, choices=ITEM_TYPE_CHOICES, default=TYPE_OTHER)
    estimated_cost = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"), validators=[MinValueValidator(Decimal("0.00"))])
    actual_cost = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0.00"))])
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PLANNED)
    deadline = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["deadline", "item_type"]

    def __str__(self):
        return self.get_item_type_display()


class ProjectBudget(TimeStampedModel):
    STATUS_ACTIVE = "active"
    STATUS_COMPLETED = "completed"
    STATUS_ON_HOLD = "on_hold"

    STATUS_CHOICES = (
        (STATUS_ACTIVE, "Active"),
        (STATUS_COMPLETED, "Completed"),
        (STATUS_ON_HOLD, "On Hold"),
    )

    project_name = models.CharField(max_length=160)
    budget_amount = models.DecimalField(max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    manual_spent_adjustment = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"), validators=[MinValueValidator(Decimal("0.00"))])
    roi_target_pct = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    roi_actual_pct = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_ACTIVE)

    class Meta:
        ordering = ["project_name"]

    def __str__(self):
        return self.project_name


class Project(TimeStampedModel):
    STATUS_IDEA = "idea"
    STATUS_PENDING = "pending"
    STATUS_IN_PROGRESS = "in_progress"
    STATUS_COMPLETED = "completed"

    STATUS_CHOICES = (
        (STATUS_IDEA, "Idea"),
        (STATUS_PENDING, "Pending"),
        (STATUS_IN_PROGRESS, "In Progress"),
        (STATUS_COMPLETED, "Completed"),
    )

    title = models.CharField(max_length=160)
    description = models.TextField(blank=True, default="")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_IDEA)
    progress = models.PositiveSmallIntegerField(default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)

    class Meta:
        ordering = ["-updated_at", "-id"]

    def __str__(self):
        return self.title


class Transaction(TimeStampedModel):
    ACCOUNT_CASH = "cash"
    ACCOUNT_BANK = "bank"
    ACCOUNT_MOBILE_MONEY = "mobile_money"

    ACCOUNT_CHOICES = (
        (ACCOUNT_CASH, "Cash"),
        (ACCOUNT_BANK, "Bank"),
        (ACCOUNT_MOBILE_MONEY, "Mobile Money"),
    )

    TYPE_INCOME = "income"
    TYPE_EXPENSE = "expense"
    TYPE_TRANSFER = "transfer"
    TYPE_SAVINGS = "savings"

    TYPE_CHOICES = (
        (TYPE_INCOME, "Income"),
        (TYPE_EXPENSE, "Expense"),
        (TYPE_TRANSFER, "Transfer"),
        (TYPE_SAVINGS, "Savings"),
    )

    tx_date = models.DateField(db_index=True)
    description = models.CharField(max_length=220)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="transactions")
    account = models.CharField(max_length=20, choices=ACCOUNT_CHOICES, default=ACCOUNT_BANK)
    tx_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_EXPENSE)
    amount = models.DecimalField(max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))], db_index=True)
    tags = models.JSONField(default=list, blank=True)
    savings_goal = models.ForeignKey("SavingsGoal", on_delete=models.SET_NULL, null=True, blank=True, related_name="transactions")
    application_cost = models.ForeignKey("ApplicationCost", on_delete=models.SET_NULL, null=True, blank=True, related_name="transactions")
    project_budget = models.ForeignKey("ProjectBudget", on_delete=models.SET_NULL, null=True, blank=True, related_name="transactions")
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-tx_date", "-id"]
        indexes = [
            models.Index(fields=["tx_date", "category"]),
            models.Index(fields=["tx_date", "account"]),
        ]

    def __str__(self):
        return f"{self.tx_date} {self.description}"


class Budget(TimeStampedModel):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="budgets")
    period_start = models.DateField(db_index=True)
    monthly_limit = models.DecimalField(max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    warning_threshold_pct = models.PositiveSmallIntegerField(default=90, validators=[MinValueValidator(1), MaxValueValidator(100)])
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-period_start", "category__name"]
        constraints = [
            models.UniqueConstraint(fields=["category", "period_start"], name="unique_budget_category_period"),
        ]

    def __str__(self):
        return f"{self.category.name} {self.period_start}"


class RecurringExpenseTemplate(TimeStampedModel):
    CADENCE_WEEKLY = "weekly"
    CADENCE_MONTHLY = "monthly"
    CADENCE_YEARLY = "yearly"

    CADENCE_CHOICES = (
        (CADENCE_WEEKLY, "Weekly"),
        (CADENCE_MONTHLY, "Monthly"),
        (CADENCE_YEARLY, "Yearly"),
    )

    name = models.CharField(max_length=140)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="recurring_templates")
    account = models.CharField(max_length=20, choices=Transaction.ACCOUNT_CHOICES, default=Transaction.ACCOUNT_BANK)
    amount = models.DecimalField(max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    cadence = models.CharField(max_length=20, choices=CADENCE_CHOICES, default=CADENCE_MONTHLY)
    next_due_date = models.DateField(db_index=True)
    end_date = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["next_due_date", "name"]

    def __str__(self):
        return self.name


class FinanceAlert(TimeStampedModel):
    TYPE_BUDGET_OVERRUN = "budget_overrun"
    TYPE_DEADLINE = "deadline"
    TYPE_CASHFLOW = "cashflow"
    TYPE_GOAL_RISK = "goal_risk"

    ALERT_TYPE_CHOICES = (
        (TYPE_BUDGET_OVERRUN, "Budget Overrun"),
        (TYPE_DEADLINE, "Deadline"),
        (TYPE_CASHFLOW, "Cashflow"),
        (TYPE_GOAL_RISK, "Goal Risk"),
    )

    SEVERITY_INFO = "info"
    SEVERITY_WARNING = "warning"
    SEVERITY_CRITICAL = "critical"

    SEVERITY_CHOICES = (
        (SEVERITY_INFO, "Info"),
        (SEVERITY_WARNING, "Warning"),
        (SEVERITY_CRITICAL, "Critical"),
    )

    alert_type = models.CharField(max_length=32, choices=ALERT_TYPE_CHOICES)
    severity = models.CharField(max_length=16, choices=SEVERITY_CHOICES, default=SEVERITY_INFO)
    message = models.CharField(max_length=255)
    related_model = models.CharField(max_length=40, blank=True, default="")
    related_id = models.PositiveIntegerField(null=True, blank=True)
    period_key = models.CharField(max_length=20, default="")
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["alert_type", "related_model", "related_id", "period_key"],
                name="unique_finance_alert_scope",
            )
        ]

    def __str__(self):
        return self.message


def academic_file_upload_path(instance, filename):
    level = getattr(instance, "level_type", "general")
    return f"uploads/education/levels/{level}/{filename}"


def exam_file_upload_path(instance, filename):
    return f"uploads/education/exams/{instance.academic_level_id or 'general'}/{filename}"


def document_file_upload_path(instance, filename):
    return f"uploads/education/documents/{instance.document_type}/{filename}"


class AcademicLevel(TimeStampedModel):
    LEVEL_PRIMARY = "primary"
    LEVEL_SECONDARY = "secondary"
    LEVEL_UNIVERSITY = "university"
    LEVEL_CERTIFICATION = "certification"

    LEVEL_CHOICES = (
        (LEVEL_PRIMARY, "Primary School"),
        (LEVEL_SECONDARY, "Secondary School"),
        (LEVEL_UNIVERSITY, "University"),
        (LEVEL_CERTIFICATION, "Certifications / Courses"),
    )

    STATUS_COMPLETED = "completed"
    STATUS_IN_PROGRESS = "in_progress"
    STATUS_PLANNED = "planned"

    STATUS_CHOICES = (
        (STATUS_COMPLETED, "Completed"),
        (STATUS_IN_PROGRESS, "In Progress"),
        (STATUS_PLANNED, "Planned"),
    )

    level_type = models.CharField(max_length=24, choices=LEVEL_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PLANNED)
    school_name = models.CharField(max_length=180, blank=True, default="")
    admission_number = models.CharField(max_length=80, blank=True, default="")
    location = models.CharField(max_length=160, blank=True, default="")
    start_year = models.PositiveIntegerField(null=True, blank=True)
    end_year = models.PositiveIntegerField(null=True, blank=True)
    subjects_taken = models.TextField(blank=True, default="")
    grades = models.TextField(blank=True, default="")
    certification_exam_completed = models.BooleanField(default=False)
    certificate_file = models.FileField(upload_to=academic_file_upload_path, null=True, blank=True)

    # University and future-proof fields
    university_name = models.CharField(max_length=180, blank=True, default="")
    country = models.CharField(max_length=120, blank=True, default="")
    degree = models.CharField(max_length=120, blank=True, default="")
    major_program = models.CharField(max_length=180, blank=True, default="")
    expected_graduation_year = models.PositiveIntegerField(null=True, blank=True)
    student_number = models.CharField(max_length=80, blank=True, default="")
    gpa = models.CharField(max_length=20, blank=True, default="")
    transcript_file = models.FileField(upload_to=academic_file_upload_path, null=True, blank=True)
    research_topic = models.TextField(blank=True, default="")
    internships = models.TextField(blank=True, default="")
    clubs_activities = models.TextField(blank=True, default="")
    awards = models.TextField(blank=True, default="")
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["level_type", "-updated_at", "-id"]

    def __str__(self):
        return f"{self.get_level_type_display()} - {self.school_name or 'Untitled'}"


class ExamCertification(TimeStampedModel):
    academic_level = models.ForeignKey(AcademicLevel, on_delete=models.CASCADE, related_name="exam_certifications")
    exam_name = models.CharField(max_length=120)
    exam_year = models.PositiveIntegerField(null=True, blank=True)
    candidate_number = models.CharField(max_length=80, blank=True, default="")
    grade_score = models.CharField(max_length=80, blank=True, default="")
    certificate_file = models.FileField(upload_to=exam_file_upload_path, null=True, blank=True)
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-exam_year", "-updated_at", "-id"]

    def __str__(self):
        return f"{self.exam_name} ({self.exam_year or 'N/A'})"


class ApplicationDocument(TimeStampedModel):
    TYPE_PERSONAL_STATEMENT = "personal_statement"
    TYPE_CV = "cv_resume"
    TYPE_FINANCIAL_STATEMENT = "financial_statement"
    TYPE_TRANSCRIPT = "academic_transcript"
    TYPE_RECOMMENDATION = "recommendation_letter"
    TYPE_PASSPORT = "passport_copy"
    TYPE_CERTIFICATE = "certificate"
    TYPE_OTHER = "other"

    DOCUMENT_TYPE_CHOICES = (
        (TYPE_PERSONAL_STATEMENT, "Personal Statement"),
        (TYPE_CV, "CV / Resume"),
        (TYPE_FINANCIAL_STATEMENT, "Financial Statement"),
        (TYPE_TRANSCRIPT, "Academic Transcript"),
        (TYPE_RECOMMENDATION, "Recommendation Letter"),
        (TYPE_PASSPORT, "Passport Copy"),
        (TYPE_CERTIFICATE, "Certificate"),
        (TYPE_OTHER, "Other"),
    )

    title = models.CharField(max_length=180)
    document_type = models.CharField(max_length=32, choices=DOCUMENT_TYPE_CHOICES, default=TYPE_OTHER)
    file = models.FileField(upload_to=document_file_upload_path)
    version = models.CharField(max_length=40, blank=True, default="v1")
    notes = models.TextField(blank=True, default="")
    expiration_date = models.DateField(null=True, blank=True)

    class Meta:
        ordering = ["document_type", "-updated_at", "-id"]

    def __str__(self):
        return self.title


class Scholarship(TimeStampedModel):
    name = models.CharField(max_length=220)
    country = models.CharField(max_length=120, blank=True, default="")
    university = models.CharField(max_length=180, blank=True, default="")
    field_of_study = models.CharField(max_length=180, blank=True, default="")
    degree_level = models.CharField(max_length=120, blank=True, default="")
    official_website = models.URLField(blank=True, default="")
    application_deadline = models.DateField(null=True, blank=True)

    tuition_coverage = models.CharField(max_length=120, blank=True, default="")
    monthly_stipend = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0.00"))])
    travel_coverage = models.BooleanField(default=False)
    accommodation = models.BooleanField(default=False)
    other_benefits = models.TextField(blank=True, default="")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["application_deadline", "name"]

    def __str__(self):
        return self.name


class ScholarshipApplication(TimeStampedModel):
    STATUS_RESEARCHING = "researching"
    STATUS_PREPARING = "preparing_documents"
    STATUS_SUBMITTED = "application_submitted"
    STATUS_INTERVIEW = "interview_stage"
    STATUS_ACCEPTED = "accepted"
    STATUS_REJECTED = "rejected"
    STATUS_WAITLISTED = "waitlisted"

    STATUS_CHOICES = (
        (STATUS_RESEARCHING, "Researching"),
        (STATUS_PREPARING, "Preparing Documents"),
        (STATUS_SUBMITTED, "Application Submitted"),
        (STATUS_INTERVIEW, "Interview Stage"),
        (STATUS_ACCEPTED, "Accepted"),
        (STATUS_REJECTED, "Rejected"),
        (STATUS_WAITLISTED, "Waitlisted"),
    )

    scholarship = models.OneToOneField(Scholarship, on_delete=models.CASCADE, related_name="application")
    status = models.CharField(max_length=32, choices=STATUS_CHOICES, default=STATUS_RESEARCHING)
    is_submitted = models.BooleanField(default=False)
    submission_date = models.DateField(null=True, blank=True)
    application_id = models.CharField(max_length=120, blank=True, default="")
    portal_link = models.URLField(blank=True, default="")
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-updated_at", "-id"]

    def __str__(self):
        return f"{self.scholarship.name} ({self.get_status_display()})"


class ScholarshipRequirement(TimeStampedModel):
    scholarship = models.ForeignKey(Scholarship, on_delete=models.CASCADE, related_name="requirements")
    requirement_name = models.CharField(max_length=180)
    is_required = models.BooleanField(default=True)
    is_completed = models.BooleanField(default=False)
    linked_document = models.ForeignKey(ApplicationDocument, on_delete=models.SET_NULL, null=True, blank=True, related_name="linked_requirements")
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "id"]

    def __str__(self):
        return f"{self.scholarship.name}: {self.requirement_name}"


def personal_vault_upload_path(instance, filename):
    file_type = getattr(instance, "file_type", "general")
    return f"uploads/personal_vault/{file_type}/{filename}"


class PersonalIdentityVault(TimeStampedModel):
    GENDER_MALE = "male"
    GENDER_FEMALE = "female"
    GENDER_OTHER = "other"
    GENDER_PREFER_NOT = "prefer_not_to_say"

    GENDER_CHOICES = (
        (GENDER_MALE, "Male"),
        (GENDER_FEMALE, "Female"),
        (GENDER_OTHER, "Other"),
        (GENDER_PREFER_NOT, "Prefer not to say"),
    )

    first_name = models.CharField(max_length=120, blank=True, default="")
    last_name = models.CharField(max_length=120, blank=True, default="")
    dob = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=24, choices=GENDER_CHOICES, blank=True, default="")
    nationality = models.CharField(max_length=120, blank=True, default="")
    languages = models.JSONField(default=list, blank=True)
    profile_photo = models.FileField(upload_to=personal_vault_upload_path, null=True, blank=True)

    class Meta:
        ordering = ["-updated_at", "-id"]

    def __str__(self):
        return f"Identity Vault ({self.first_name} {self.last_name})".strip()


class ContactInfo(TimeStampedModel):
    vault = models.OneToOneField(PersonalIdentityVault, on_delete=models.CASCADE, related_name="contact_info")
    primary_email = models.EmailField(blank=True, default="")
    secondary_email = models.EmailField(blank=True, default="")
    additional_emails = models.JSONField(default=list, blank=True)
    primary_phone = models.CharField(max_length=40, blank=True, default="")
    secondary_phone = models.CharField(max_length=40, blank=True, default="")
    other_phone_numbers = models.JSONField(default=list, blank=True)
    home_address = models.CharField(max_length=240, blank=True, default="")
    city = models.CharField(max_length=120, blank=True, default="")
    country = models.CharField(max_length=120, blank=True, default="")
    postal_code = models.CharField(max_length=40, blank=True, default="")

    class Meta:
        ordering = ["-updated_at", "-id"]

    def __str__(self):
        return f"Contact Info ({self.primary_email or 'No email'})"


class IdentityDocuments(TimeStampedModel):
    vault = models.OneToOneField(PersonalIdentityVault, on_delete=models.CASCADE, related_name="identity_documents")
    national_id_encrypted = models.TextField(blank=True, default="")
    passport_number_encrypted = models.TextField(blank=True, default="")
    passport_expiry = models.DateField(null=True, blank=True)
    drivers_license_encrypted = models.TextField(blank=True, default="")
    student_id_encrypted = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-updated_at", "-id"]

    def __str__(self):
        return "Identity Documents"


class IdentityUploadedFile(TimeStampedModel):
    TYPE_NATIONAL_ID = "national_id_scan"
    TYPE_PASSPORT = "passport_scan"
    TYPE_CERTIFICATE = "certificate"
    TYPE_ACADEMIC = "academic_document"
    TYPE_OTHER = "other"

    FILE_TYPE_CHOICES = (
        (TYPE_NATIONAL_ID, "National ID Scan"),
        (TYPE_PASSPORT, "Passport Scan"),
        (TYPE_CERTIFICATE, "Certificate"),
        (TYPE_ACADEMIC, "Academic Document"),
        (TYPE_OTHER, "Other Identity Document"),
    )

    vault = models.ForeignKey(PersonalIdentityVault, on_delete=models.CASCADE, related_name="uploaded_files")
    file_type = models.CharField(max_length=32, choices=FILE_TYPE_CHOICES, default=TYPE_OTHER)
    file = models.FileField(upload_to=personal_vault_upload_path)
    original_name = models.CharField(max_length=255, blank=True, default="")
    file_size = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-updated_at", "-id"]

    def __str__(self):
        return f"{self.file_type}: {self.original_name or self.file.name}"


class DigitalAccounts(TimeStampedModel):
    PLATFORM_GOOGLE = "google"
    PLATFORM_GITHUB = "github"
    PLATFORM_LINKEDIN = "linkedin"
    PLATFORM_TWITTER = "twitter_x"
    PLATFORM_INSTAGRAM = "instagram"
    PLATFORM_FACEBOOK = "facebook"
    PLATFORM_TIKTOK = "tiktok"
    PLATFORM_DISCORD = "discord"
    PLATFORM_REDDIT = "reddit"
    PLATFORM_CUSTOM = "custom"

    PLATFORM_CHOICES = (
        (PLATFORM_GOOGLE, "Google"),
        (PLATFORM_GITHUB, "GitHub"),
        (PLATFORM_LINKEDIN, "LinkedIn"),
        (PLATFORM_TWITTER, "Twitter / X"),
        (PLATFORM_INSTAGRAM, "Instagram"),
        (PLATFORM_FACEBOOK, "Facebook"),
        (PLATFORM_TIKTOK, "TikTok"),
        (PLATFORM_DISCORD, "Discord"),
        (PLATFORM_REDDIT, "Reddit"),
        (PLATFORM_CUSTOM, "Custom"),
    )

    vault = models.ForeignKey(PersonalIdentityVault, on_delete=models.CASCADE, related_name="digital_accounts")
    platform = models.CharField(max_length=24, choices=PLATFORM_CHOICES)
    custom_platform = models.CharField(max_length=120, blank=True, default="")
    username = models.CharField(max_length=180, blank=True, default="")
    email_used = models.EmailField(blank=True, default="")
    profile_link = models.URLField(blank=True, default="")
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["platform", "-updated_at", "-id"]

    def __str__(self):
        return f"{self.get_platform_display()} ({self.username})"


class SocialProfiles(TimeStampedModel):
    vault = models.OneToOneField(PersonalIdentityVault, on_delete=models.CASCADE, related_name="social_profiles")
    linkedin = models.URLField(blank=True, default="")
    twitter_x = models.URLField(blank=True, default="")
    instagram = models.URLField(blank=True, default="")
    github = models.URLField(blank=True, default="")
    portfolio_website = models.URLField(blank=True, default="")
    personal_blog = models.URLField(blank=True, default="")
    youtube_channel = models.URLField(blank=True, default="")

    class Meta:
        ordering = ["-updated_at", "-id"]

    def __str__(self):
        return "Social Profiles"


class PasswordReferences(TimeStampedModel):
    MANAGER_BITWARDEN = "bitwarden"
    MANAGER_1PASSWORD = "1password"
    MANAGER_PROTON_PASS = "proton_pass"
    MANAGER_OTHER = "other"

    PASSWORD_MANAGER_CHOICES = (
        (MANAGER_BITWARDEN, "Bitwarden"),
        (MANAGER_1PASSWORD, "1Password"),
        (MANAGER_PROTON_PASS, "Proton Pass"),
        (MANAGER_OTHER, "Other"),
    )

    vault = models.ForeignKey(PersonalIdentityVault, on_delete=models.CASCADE, related_name="password_references")
    platform = models.CharField(max_length=120)
    username = models.CharField(max_length=180, blank=True, default="")
    email_used = models.EmailField(blank=True, default="")
    password_hint = models.CharField(max_length=255, blank=True, default="")
    two_factor_enabled = models.BooleanField(default=False)
    backup_codes_location = models.CharField(max_length=255, blank=True, default="")
    password_manager = models.CharField(max_length=32, choices=PASSWORD_MANAGER_CHOICES, default=MANAGER_BITWARDEN)
    notes = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["platform", "-updated_at", "-id"]

    def __str__(self):
        return f"{self.platform} ({self.username})"

```

---

## myos_project/myos_app/static/css/style.css

- Size: 53314 bytes
- Lines: 1691
- Modified: 2026-03-06 21:10:45
- SHA256: 85415179f031bb5b5b23fcbf5193cb9727c08698bd7a7f41a12d106bf5a74129
- MIME: text/plain

```
:root{--coffee:#3B1E12;--coffee-light:#4A2315;--gold:#E2B56D;--gold-deep:#D4A35A;--cream:#F0D7A6;--cream-soft:#EBD0A2;--cocoa:#6B3A1F;--bronze:#8B5A2B;--white:#FDF6EC;--text-dark:#2A1208;--text-mid:#5C3010;--shadow:rgba(59,30,18,.18);--sidebar-w:270px}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Quicksand',sans-serif;background:var(--cream);color:var(--text-dark);min-height:100vh;overflow-x:hidden}

/* AUTH */
#auth-overlay{position:fixed;inset:0;z-index:9999;background:linear-gradient(135deg,var(--coffee) 0%,var(--cocoa) 50%,var(--bronze) 100%);display:flex;align-items:center;justify-content:center;transition:opacity .6s ease}
#auth-overlay.hide{opacity:0;pointer-events:none}
.auth-box{background:var(--white);border-radius:20px;padding:48px 42px;width:420px;max-width:95vw;box-shadow:0 30px 80px rgba(0,0,0,.35);animation:slideUp .5s ease both}
@keyframes slideUp{from{transform:translateY(40px);opacity:0}to{transform:translateY(0);opacity:1}}
.auth-logo{text-align:center;margin-bottom:28px}
.auth-logo .brand-name{font-family:'Quicksand',sans-serif;font-size:2.4rem;color:var(--coffee);letter-spacing:-1px}
.auth-logo .brand-sub{font-size:.78rem;color:var(--bronze);letter-spacing:3px;text-transform:uppercase;margin-top:2px}
.auth-tabs{display:flex;border-radius:10px;overflow:hidden;border:2px solid var(--cream-soft);margin-bottom:28px}
.auth-tab{flex:1;padding:10px;background:none;border:none;font-family:'Quicksand',sans-serif;font-size:.9rem;cursor:pointer;color:var(--bronze);transition:all .25s}
.auth-tab.active{background:var(--coffee);color:var(--cream)}
.auth-form{display:none;flex-direction:column;gap:14px}
.auth-form.active{display:flex}
.field-group label{display:block;font-size:.75rem;color:var(--bronze);letter-spacing:1px;text-transform:uppercase;margin-bottom:5px}
.field-group input,.field-group select{width:100%;padding:11px 14px;border:1.5px solid var(--cream-soft);border-radius:8px;font-size:.9rem;font-family:'Quicksand',sans-serif;background:var(--cream);color:var(--text-dark);transition:border-color .2s}
.field-group input:focus,.field-group select:focus{outline:none;border-color:var(--gold)}
.auth-row{display:flex;gap:10px}
.auth-row .field-group{flex:1}
.checkbox-row{display:flex;align-items:center;gap:8px;font-size:.82rem;color:var(--text-mid)}
.checkbox-row input[type=checkbox]{accent-color:var(--gold-deep)}
.btn-primary{background:linear-gradient(135deg,var(--coffee),var(--cocoa));color:var(--cream);border:none;border-radius:10px;padding:13px;font-size:.95rem;cursor:pointer;font-family:'Quicksand',sans-serif;transition:transform .15s,box-shadow .15s;box-shadow:0 4px 18px var(--shadow)}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 26px var(--shadow)}
.sso-divider{text-align:center;font-size:.78rem;color:var(--bronze);position:relative;margin:4px 0}
.sso-divider::before,.sso-divider::after{content:'';position:absolute;top:50%;width:38%;height:1px;background:var(--cream-soft)}
.sso-divider::before{left:0}
.sso-divider::after{right:0}
.sso-buttons{display:flex;gap:10px}
.btn-sso{flex:1;padding:10px;border-radius:8px;border:1.5px solid var(--cream-soft);background:var(--white);cursor:pointer;font-size:.82rem;display:flex;align-items:center;justify-content:center;gap:7px;transition:background .2s;font-family:'Quicksand',sans-serif}
.btn-sso:hover{background:var(--cream)}
.otp-section{display:none;flex-direction:column;gap:14px}
.otp-section.active{display:flex}
.otp-inputs{display:flex;gap:10px;justify-content:center}
.otp-inputs input{width:50px;height:56px;text-align:center;font-size:1.5rem;border:2px solid var(--cream-soft);border-radius:10px;background:var(--cream);font-family:'Quicksand',sans-serif;color:var(--coffee);transition:border-color .2s}
.otp-inputs input:focus{outline:none;border-color:var(--gold)}
.otp-hint{font-size:.8rem;color:var(--bronze);text-align:center}

/* APP */
#app{display:none;min-height:100vh}
#app.show{display:flex}

/* SIDEBAR */
.sidebar{width:var(--sidebar-w);background:linear-gradient(180deg,var(--coffee) 0%,var(--coffee-light) 100%);min-height:100vh;display:flex;flex-direction:column;position:fixed;left:0;top:0;z-index:100;box-shadow:4px 0 24px rgba(0,0,0,.2)}
.sidebar-brand{padding:28px 24px 20px;border-bottom:1px solid rgba(226,181,109,.15)}
.sidebar-brand .brand-name{font-family:'Quicksand',sans-serif;font-size:1.6rem;color:var(--gold);letter-spacing:-.5px}
.sidebar-brand .brand-sub{font-size:.65rem;letter-spacing:3px;text-transform:uppercase;color:rgba(226,181,109,.55);margin-top:2px}
.sidebar-clock{padding:14px 24px;border-bottom:1px solid rgba(226,181,109,.1)}
#clock-display{font-family:'Quicksand',sans-serif;font-size:2.1rem;color:var(--gold);letter-spacing:2px}
#clock-date{font-size:.72rem;color:rgba(240,215,166,.5);margin-top:2px;letter-spacing:1px}
.sidebar-nav{flex:1;padding:16px 0;overflow-y:auto}
.nav-section-label{font-size:.6rem;letter-spacing:3px;text-transform:uppercase;color:rgba(226,181,109,.4);padding:8px 24px 4px}
.nav-item{display:flex;align-items:center;gap:12px;padding:11px 24px;cursor:pointer;transition:all .2s;position:relative;color:rgba(240,215,166,.7);font-size:.88rem;text-decoration:none}
.nav-item:hover{color:var(--gold);background:rgba(226,181,109,.07)}
.nav-item.active{color:var(--gold);background:rgba(226,181,109,.12)}
.nav-item.active::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--gold);border-radius:0 2px 2px 0}
.nav-item i{width:18px;text-align:center;font-size:.9rem}
.sidebar-footer{padding:16px 20px;border-top:1px solid rgba(226,181,109,.12)}
.user-card{display:flex;align-items:center;gap:10px;padding:10px;border-radius:10px;background:rgba(226,181,109,.07)}
.user-avatar{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--bronze));display:flex;align-items:center;justify-content:center;font-family:'Quicksand',sans-serif;font-size:1rem;color:var(--white);font-weight:700}
.user-name{font-size:.85rem;color:var(--cream);font-weight:500}
.user-email{font-size:.7rem;color:rgba(240,215,166,.5)}

/* MAIN */
.main{margin-left:var(--sidebar-w);flex:1;min-height:100vh;display:flex;flex-direction:column;background:var(--cream)}
.topbar{background:var(--white);padding:0 32px;height:60px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(59,30,18,.08);position:sticky;top:0;z-index:50}
.topbar-search{display:flex;align-items:center;gap:10px;background:var(--cream);border-radius:10px;padding:8px 14px;flex:1;max-width:400px;border:1.5px solid rgba(59,30,18,.1);transition:border-color .2s}
.topbar-search:focus-within{border-color:var(--gold)}
.topbar-search input{border:none;background:none;outline:none;font-family:'Quicksand',sans-serif;font-size:.88rem;color:var(--text-dark);flex:1}
.topbar-search i{color:var(--bronze);font-size:.85rem}
.topbar-actions{display:flex;align-items:center;gap:14px}
.topbar-btn{width:36px;height:36px;border-radius:8px;background:none;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--bronze);transition:background .2s;font-size:.95rem}
.topbar-btn:hover{background:var(--cream);color:var(--coffee)}

/* PAGES */
.page-content{flex:1;padding:32px;display:none;animation:fadeIn .35s ease both}
.page-content.active{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}

/* GREETING BANNER */
.greeting-banner{background:linear-gradient(135deg,var(--coffee) 0%,var(--cocoa) 60%,var(--bronze) 100%);border-radius:20px;padding:32px 36px;display:flex;align-items:center;gap:24px;margin-bottom:28px;overflow:hidden;position:relative}
.greeting-banner::before{content:'';position:absolute;right:-40px;top:-40px;width:220px;height:220px;border-radius:50%;background:rgba(226,181,109,.1)}
.greeting-banner::after{content:'';position:absolute;right:60px;bottom:-60px;width:160px;height:160px;border-radius:50%;background:rgba(226,181,109,.07)}
.greeting-text{flex:1;position:relative;z-index:1}
.greeting-text .time-greeting{font-family:'Quicksand',sans-serif;font-size:2.2rem;color:var(--gold);font-style:italic}
.greeting-text .greeting-sub{font-size:.85rem;color:rgba(240,215,166,.65);margin-top:6px;line-height:1.6}
.greeting-clock{text-align:right;position:relative;z-index:1}
.greeting-clock .big-time{font-family:'Quicksand',sans-serif;font-size:3.2rem;color:var(--cream);letter-spacing:3px;line-height:1}
.greeting-clock .big-date{font-size:.78rem;color:rgba(240,215,166,.55);margin-top:4px;letter-spacing:2px;text-transform:uppercase}

/* DASH GRID */
.dash-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px}
.dash-card{background:var(--white);border-radius:16px;padding:22px 24px;box-shadow:0 2px 16px rgba(59,30,18,.07);border:1px solid rgba(59,30,18,.06);transition:transform .2s,box-shadow .2s}
.dash-card:hover{transform:translateY(-3px);box-shadow:0 8px 28px rgba(59,30,18,.12)}
.card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.card-title{font-family:'Quicksand',sans-serif;font-size:1.05rem;font-weight:600;color:var(--coffee);letter-spacing:.3px}
.card-icon{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--cream),var(--cream-soft));display:flex;align-items:center;justify-content:center;color:var(--bronze);font-size:.9rem}

/* PROGRESS */
.progress-track{height:6px;background:var(--cream-soft);border-radius:10px;overflow:hidden;margin:10px 0}
.progress-fill{height:100%;border-radius:10px;background:linear-gradient(90deg,var(--gold),var(--bronze));transition:width .8s cubic-bezier(.4,0,.2,1)}
.progress-label{display:flex;justify-content:space-between;font-size:.75rem;color:var(--bronze);margin-top:4px}

/* TASK LIST */
.task-item{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(59,30,18,.05);font-size:.84rem}
.task-item:last-child{border-bottom:none}
.task-check{width:18px;height:18px;border-radius:4px;border:2px solid var(--cream-soft);cursor:pointer;transition:all .15s;flex-shrink:0;display:flex;align-items:center;justify-content:center}
.task-check.done{background:var(--gold);border-color:var(--gold);color:var(--white)}
.task-text{flex:1;color:var(--text-mid)}
.task-text.done{text-decoration:line-through;opacity:.5}

/* FINANCE */
.finance-row{display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid rgba(59,30,18,.05);font-size:.83rem}
.finance-row:last-child{border-bottom:none}
.finance-label{color:var(--text-mid)}
.finance-amount{font-family:'Quicksand',sans-serif;font-size:1rem;font-weight:600}
.finance-amount.income{color:#3a7d44}
.finance-amount.expense{color:#b34040}
.finance-amount.savings{color:var(--gold-deep)}

/* DIARY PREVIEW */
.diary-preview{background:linear-gradient(135deg,var(--cream),var(--cream-soft));border-radius:10px;padding:14px;font-size:.83rem;line-height:1.7;color:var(--text-mid);font-style:italic;border-left:3px solid var(--gold)}
.diary-date{font-size:.72rem;color:var(--bronze);margin-bottom:6px;letter-spacing:1px}
.mood-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:20px;font-size:.72rem;background:var(--cream-soft);color:var(--bronze)}

/* PAGE HEADERS */
.page-header{margin-bottom:26px;display:flex;align-items:flex-end;justify-content:space-between}
.page-title{font-family:'Quicksand',sans-serif;font-size:2rem;color:var(--coffee);letter-spacing:-.5px}
.page-title-sub{font-size:.82rem;color:var(--bronze);margin-top:3px}
.btn-add{background:linear-gradient(135deg,var(--coffee),var(--cocoa));color:var(--cream);border:none;border-radius:10px;padding:10px 20px;font-size:.84rem;cursor:pointer;font-family:'Quicksand',sans-serif;display:flex;align-items:center;gap:8px;transition:transform .15s,box-shadow .15s;box-shadow:0 4px 14px var(--shadow)}
.btn-add:hover{transform:translateY(-2px);box-shadow:0 8px 22px var(--shadow)}

/* WIZARD */
.wizard-steps{display:flex;gap:6px;margin-bottom:28px;flex-wrap:wrap}
.wizard-step{flex:1;min-width:80px;padding:10px 8px;text-align:center;border-radius:8px;font-size:.75rem;cursor:pointer;transition:all .2s;border:2px solid transparent;background:var(--white);color:var(--bronze)}
.wizard-step.active{background:var(--coffee);color:var(--cream);border-color:var(--coffee)}
.wizard-step.completed{background:rgba(226,181,109,.2);color:var(--gold-deep);border-color:var(--gold-deep)}
.wizard-step .step-num{font-family:'Quicksand',sans-serif;font-size:1.1rem;display:block;margin-bottom:2px}
.wizard-panel{display:none}
.wizard-panel.active{display:block;animation:fadeIn .3s ease}
.form-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
.form-field label{display:block;font-size:.72rem;letter-spacing:1px;text-transform:uppercase;color:var(--bronze);margin-bottom:5px}
.form-field input,.form-field select,.form-field textarea{width:100%;padding:10px 13px;border:1.5px solid rgba(59,30,18,.15);border-radius:8px;font-size:.88rem;font-family:'Quicksand',sans-serif;background:var(--white);color:var(--text-dark);transition:border-color .2s}
.form-field input:focus,.form-field select:focus,.form-field textarea:focus{outline:none;border-color:var(--gold)}
.form-field textarea{resize:vertical;min-height:90px}
.wizard-nav{display:flex;justify-content:space-between;margin-top:26px}
.btn-outline{padding:10px 22px;border-radius:10px;border:2px solid var(--coffee);background:none;color:var(--coffee);font-family:'Quicksand',sans-serif;font-size:.88rem;cursor:pointer;transition:all .2s}
.btn-outline:hover{background:var(--coffee);color:var(--cream)}

/* CARDS GRID */
.cards-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px}
.item-card{background:var(--white);border-radius:16px;padding:20px;border:1px solid rgba(59,30,18,.06);box-shadow:0 2px 14px rgba(59,30,18,.06);transition:transform .2s,box-shadow .2s;position:relative;overflow:hidden}
.item-card:hover{transform:translateY(-3px);box-shadow:0 10px 30px rgba(59,30,18,.12)}
.item-card .card-status{position:absolute;top:16px;right:16px;padding:3px 10px;border-radius:20px;font-size:.68rem;letter-spacing:.5px;text-transform:uppercase}
.status-inprogress{background:rgba(226,181,109,.2);color:var(--gold-deep)}
.status-completed{background:rgba(58,125,68,.15);color:#3a7d44}
.status-idea{background:rgba(139,90,43,.15);color:var(--bronze)}
.status-pending{background:rgba(179,64,64,.1);color:#b34040}
.item-card .item-title{font-family:'Quicksand',sans-serif;font-size:1.2rem;color:var(--coffee);margin-bottom:6px;margin-right:90px;font-weight:600}
.item-card .item-meta{font-size:.78rem;color:var(--bronze);margin-bottom:12px}

/* TABS */
.tab-bar{display:flex;margin-bottom:24px;background:var(--white);border-radius:12px;padding:5px;border:1px solid rgba(59,30,18,.07);width:fit-content}
.tab-btn{padding:8px 20px;border:none;background:none;border-radius:8px;cursor:pointer;font-family:'Quicksand',sans-serif;font-size:.85rem;color:var(--bronze);transition:all .2s}
.tab-btn.active{background:var(--coffee);color:var(--cream)}
.tab-panel{display:none}
.tab-panel.active{display:block;animation:fadeIn .3s ease}

/* MEDIA OVERVIEW */
.media-overview{background:linear-gradient(135deg,var(--coffee),var(--cocoa));border-radius:20px;padding:28px;display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:20px;margin-bottom:28px}
.media-stat{color:var(--cream)}
.media-stat-label{font-size:.72rem;letter-spacing:2px;text-transform:uppercase;color:rgba(240,215,166,.55);margin-bottom:8px}
.media-stat-value{font-family:'Quicksand',sans-serif;font-size:1.8rem;color:var(--gold);margin-bottom:8px}
.media-bar-track{height:4px;background:rgba(255,255,255,.12);border-radius:4px}
.media-bar-fill{height:100%;border-radius:4px;background:linear-gradient(90deg,var(--gold),var(--cream))}

/* CHECKLIST */
.checklist-item{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(59,30,18,.05);font-size:.84rem;cursor:pointer}
.checklist-item:last-child{border-bottom:none}
.check-box{width:18px;height:18px;border-radius:4px;border:2px solid var(--cream-soft);flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .15s}
.check-box.checked{background:var(--gold);border-color:var(--gold);color:var(--white);font-size:.6rem}

/* DIARY */
.diary-editor{background:var(--white);border-radius:16px;padding:24px;border:1px solid rgba(59,30,18,.06)}
.diary-editor textarea{width:100%;min-height:200px;border:none;outline:none;font-family:'Quicksand',sans-serif;font-size:1.05rem;color:var(--text-dark);line-height:1.9;resize:none;background:none}
.mood-selector{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px}
.mood-btn{padding:6px 14px;border-radius:20px;border:2px solid var(--cream-soft);background:none;cursor:pointer;font-size:.82rem;transition:all .2s}
.mood-btn.selected{background:var(--gold);border-color:var(--gold);color:var(--white)}

/* BUCKET LIST */
.bucket-categories{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:24px}
.bucket-cat{background:var(--white);border-radius:12px;padding:16px 18px;cursor:pointer;border:2px solid transparent;transition:all .2s;text-align:center}
.bucket-cat:hover,.bucket-cat.active{border-color:var(--gold);background:rgba(226,181,109,.08)}
.bucket-cat .cat-icon{font-size:1.6rem;margin-bottom:6px}
.bucket-cat .cat-name{font-size:.82rem;color:var(--bronze)}
.bucket-cat .cat-count{font-family:'Quicksand',sans-serif;font-size:1.4rem;color:var(--coffee)}
.bucket-item{display:flex;align-items:center;gap:12px;padding:12px 16px;background:var(--white);border-radius:10px;margin-bottom:8px;border:1px solid rgba(59,30,18,.06);transition:transform .15s}
.bucket-item:hover{transform:translateX(4px)}
.bucket-star{color:var(--cream-soft);font-size:.9rem;cursor:pointer;transition:color .15s}
.bucket-star.starred{color:var(--gold)}

/* FINANCE CARDS */
.finance-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;margin-bottom:26px}
.finance-stat-card{background:var(--white);border-radius:14px;padding:20px;border:1px solid rgba(59,30,18,.06);text-align:center}
.finance-stat-card .fsc-icon{font-size:1.8rem;margin-bottom:10px}
.finance-stat-card .fsc-value{font-family:'Quicksand',sans-serif;font-size:1.8rem;color:var(--coffee);margin-bottom:4px}
.finance-stat-card .fsc-label{font-size:.72rem;color:var(--bronze);letter-spacing:1px;text-transform:uppercase}

/* MISC */
.notif-dot{width:7px;height:7px;border-radius:50%;background:var(--gold);position:absolute;top:8px;right:8px}
.alert-banner{background:rgba(226,181,109,.15);border:1px solid rgba(226,181,109,.35);border-radius:10px;padding:12px 16px;font-size:.83rem;color:var(--bronze);display:flex;align-items:center;gap:10px;margin-bottom:14px}
.schol-status{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;border-radius:20px;font-size:.72rem;font-weight:500}
.schol-status.accepted{background:rgba(58,125,68,.15);color:#3a7d44}
.schol-status.rejected{background:rgba(179,64,64,.1);color:#b34040}
.schol-status.pending{background:rgba(226,181,109,.2);color:var(--gold-deep)}
.schol-status.preparing{background:rgba(139,90,43,.15);color:var(--bronze)}
::-webkit-scrollbar{width:5px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:rgba(139,90,43,.3);border-radius:4px}
::-webkit-scrollbar-thumb:hover{background:var(--bronze)}
.gantt-bar{height:22px;border-radius:4px;background:linear-gradient(90deg,var(--gold),var(--bronze));transition:width .6s ease;display:flex;align-items:center;padding:0 8px;font-size:.68rem;color:var(--white);white-space:nowrap;overflow:hidden}
.data-table{width:100%;border-collapse:collapse;font-size:.84rem}
.data-table th{background:var(--coffee);color:var(--gold);padding:10px 14px;text-align:left;font-family:'Quicksand',sans-serif;font-size:.88rem;font-weight:600}
.data-table th:first-child{border-radius:10px 0 0 10px}
.data-table th:last-child{border-radius:0 10px 10px 0}
.data-table td{padding:10px 14px;border-bottom:1px solid rgba(59,30,18,.06);color:var(--text-mid)}
.data-table tr:hover td{background:rgba(226,181,109,.05)}
.data-table tr:last-child td{border-bottom:none}
.tag{display:inline-block;padding:2px 9px;border-radius:12px;background:rgba(226,181,109,.18);color:var(--gold-deep);font-size:.7rem;margin:1px}
.section-divider{display:flex;align-items:center;gap:12px;margin:24px 0 16px}
.section-divider span{font-family:'Quicksand',sans-serif;font-size:1rem;font-weight:600;color:var(--coffee);white-space:nowrap}
.section-divider::before,.section-divider::after{content:'';flex:1;height:1px;background:rgba(59,30,18,.1)}
.upload-zone{border:2px dashed rgba(139,90,43,.3);border-radius:12px;padding:24px;text-align:center;cursor:pointer;transition:all .2s;color:var(--bronze);font-size:.84rem}
.upload-zone:hover{border-color:var(--gold);background:rgba(226,181,109,.05)}
.upload-zone i{font-size:1.8rem;margin-bottom:8px;display:block;color:var(--gold-deep)}
.upload-input-hidden{position:absolute;left:-9999px;width:1px;height:1px;opacity:0;pointer-events:none}
.upload-file-list{margin-top:8px;display:flex;flex-direction:column;gap:6px}
.upload-file-item{display:flex;justify-content:space-between;align-items:center;gap:10px;background:var(--white);border:1px solid rgba(59,30,18,.09);border-radius:8px;padding:7px 10px;font-size:.76rem}
.upload-file-item a{color:var(--coffee);text-decoration:none;word-break:break-word}
.upload-file-item a:hover{text-decoration:underline}
.upload-file-meta{color:var(--bronze);white-space:nowrap}
.chart-placeholder{height:180px;background:linear-gradient(135deg,var(--cream),var(--cream-soft));border-radius:12px;display:flex;align-items:center;justify-content:center;color:var(--bronze);font-size:.82rem;flex-direction:column;gap:8px}
.chart-bars{display:flex;align-items:flex-end;gap:6px;height:80px}
.chart-bar{width:20px;border-radius:4px 4px 0 0;background:linear-gradient(0deg,var(--gold),var(--bronze));transition:height .6s ease}

/* ANALYTICS */
.split-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px;margin-bottom:22px}
.chart-card{min-height:330px}
.chart-canvas-wrap{position:relative;height:250px;width:100%}
.insight-list{display:flex;flex-direction:column;gap:10px}
.insight-item{display:flex;align-items:center;gap:10px;padding:10px;background:var(--cream);border-radius:8px;color:var(--text-mid);font-size:.85rem}
.insight-item .tag{flex-shrink:0}

/* JS UX HELPERS */
.btn-primary.is-loading{opacity:.85;cursor:wait}
.btn-primary:disabled,.btn-add:disabled,.btn-outline:disabled{opacity:.7;cursor:not-allowed}
#toast-container{position:fixed;right:18px;bottom:18px;display:flex;flex-direction:column;gap:10px;z-index:10001;pointer-events:none}
.toast{background:var(--coffee);color:var(--cream);padding:10px 14px;border-radius:10px;box-shadow:0 8px 26px rgba(0,0,0,.22);font-size:.82rem;transform:translateY(10px);opacity:0;transition:transform .22s ease,opacity .22s ease}
.toast.show{transform:translateY(0);opacity:1}
.check-icon-small{font-size:.55rem}
.check-icon-normal{font-size:.6rem}

/* RESPONSIVE */
@media (max-width:1100px){
  :root{--sidebar-w:240px}
}

@media (max-width:900px){
  #app.show{display:block}
  .sidebar{position:relative;width:100%;min-height:auto;box-shadow:none}
  .sidebar-nav{display:grid;grid-template-columns:repeat(2,minmax(140px,1fr));gap:6px;padding:12px}
  .nav-item{border-radius:8px;padding:10px 12px}
  .nav-item.active::before{display:none}
  .sidebar-footer{display:none}
  .main{margin-left:0}
  .topbar{padding:0 16px}
  .page-content{padding:20px 16px}
  .greeting-banner{flex-direction:column;align-items:flex-start}
  .greeting-clock{text-align:left}
  .u-inline-92{grid-template-columns:1fr}
}

@media (max-width:560px){
  .dash-grid,.cards-grid,.finance-cards,.form-grid,.bucket-categories{grid-template-columns:1fr}
  .sidebar-nav{grid-template-columns:1fr}
  .topbar{flex-direction:column;height:auto;gap:10px;padding:12px 14px}
  .topbar-search{max-width:none;width:100%}
  .tab-bar{display:grid;grid-template-columns:repeat(2,minmax(120px,1fr));width:100%}
  .tab-btn{width:100%}
  .chart-canvas-wrap{height:220px}
}

/* Extracted Inline Styles */
.u-inline-1{font-size:.74rem;color:var(--bronze);background:var(--cream);padding:8px 12px;border-radius:8px;line-height:1.5}
.u-inline-2{color:#ea4335}
.u-inline-3{font-size:.72rem}
.u-inline-4{margin-top:10px}
.u-inline-5{position:relative}
.u-inline-6{font-size:.55rem}
.u-inline-7{margin-top:12px}
.u-inline-8{width:25%}
.u-inline-9{display:flex;flex-direction:column;gap:12px}
.u-inline-10{display:flex;justify-content:space-between;font-size:.78rem;color:var(--bronze);margin-bottom:4px}
.u-inline-11{width:40%}
.u-inline-12{width:30%}
.u-inline-13{width:15%}
.u-inline-14{width:60%}
.u-inline-15{width:59%}
.u-inline-16{display:flex;flex-direction:column;gap:10px}
.u-inline-17{padding:10px;background:var(--cream);border-radius:8px}
.u-inline-18{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.u-inline-19{font-size:.84rem;font-weight:500;color:var(--coffee)}
.u-inline-20{padding:2px 8px;border-radius:10px;font-size:.65rem}
.u-inline-21{width:5%}
.u-inline-22{width:70%}
.u-inline-23{margin-top:12px;text-align:right}
.u-inline-24{font-size:.78rem;color:var(--gold-deep);text-decoration:none}
.u-inline-25{display:flex;flex-direction:column;gap:8px}
.u-inline-26{display:flex;gap:12px;align-items:center}
.u-inline-27{background:var(--coffee);color:var(--gold);border-radius:8px;padding:6px 10px;text-align:center;min-width:44px}
.u-inline-28{font-size:.62rem;letter-spacing:1px}
.u-inline-29{font-family:'Quicksand',sans-serif;font-size:1.3rem;line-height:1}
.u-inline-30{font-size:.84rem;color:var(--coffee);font-weight:500}
.u-inline-31{font-size:.72rem;color:var(--bronze)}
.u-inline-32{background:var(--cocoa);color:var(--gold);border-radius:8px;padding:6px 10px;text-align:center;min-width:44px}
.u-inline-33{background:var(--bronze);color:var(--white);border-radius:8px;padding:6px 10px;text-align:center;min-width:44px}
.u-inline-34{margin-bottom:20px}
.u-inline-35{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}
.u-inline-36{font-size:.82rem;color:var(--bronze)}
.u-inline-37{margin-bottom:16px}
.u-inline-38{padding:10px 24px}
.u-inline-39{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}
.u-inline-40{margin-top:14px}
.u-inline-41{width:fit-content}
.u-inline-42{width:100%}
.u-inline-43{grid-template-columns:1fr;gap:8px;margin-top:10px}
.u-inline-44{display:flex;align-items:center;gap:14px}
.u-inline-45{width:42px;height:42px;border-radius:10px;background:linear-gradient(135deg,var(--cream),var(--cream-soft));display:flex;align-items:center;justify-content:center;color:var(--bronze);flex-shrink:0}
.u-inline-46{flex:1}
.u-inline-47{font-weight:500;color:var(--coffee);font-size:.9rem}
.u-inline-48{display:flex;gap:8px}
.u-inline-49{padding:5px 12px;font-size:.72rem}
.u-inline-50{padding:5px 12px}
.u-inline-51{display:flex;align-items:center;gap:10px;text-align:left;padding:20px}
.u-inline-52{font-size:1.2rem;display:inline;color:var(--gold-deep)}
.u-inline-53{color:#3a7d44}
.u-inline-54{color:#b34040}
.u-inline-55{color:var(--gold-deep)}
.u-inline-56{color:var(--bronze)}
.u-inline-57{color:#3a7d44;font-weight:500}
.u-inline-58{color:#b34040;font-weight:500}
.u-inline-59{color:var(--gold-deep);font-weight:500}
.u-inline-60{display:flex;flex-direction:column;gap:16px}
.u-inline-61{display:flex;justify-content:space-between;margin-bottom:6px}
.u-inline-62{font-size:.88rem;color:var(--coffee);font-weight:500}
.u-inline-63{width:50%}
.u-inline-64{width:10%}
.u-inline-65{width:89%}
.u-inline-66{width:80%}
.u-inline-67{font-size:.7rem;color:rgba(240,215,166,.5);margin-top:4px}
.u-inline-68{width:45%}
.u-inline-69{width:65%}
.u-inline-70{margin-top:8px}
.u-inline-71{font-size:.75rem;color:var(--bronze)}
.u-inline-72{width:0%}
.u-inline-73{width:48%}
.u-inline-74{flex:1;color:var(--text-mid);font-size:.88rem}
.u-inline-75{flex:1;color:var(--text-mid);font-size:.88rem;text-decoration:line-through;opacity:.5}
.u-inline-76{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}
.u-inline-77{margin-top:12px;font-size:.78rem;color:var(--bronze)}
.u-inline-78{background:var(--cream);border-radius:10px;padding:14px}
.u-inline-79{font-weight:600;color:var(--coffee);font-size:.9rem;margin-bottom:10px}
.u-inline-80{display:flex;gap:10px;align-items:center;font-size:.78rem;color:var(--bronze)}
.u-inline-81{min-width:130px}
.u-inline-82{flex:1;background:var(--cream-soft);border-radius:4px;height:22px;overflow:hidden}
.u-inline-83{margin-bottom:14px}
.u-inline-84{width:66%}
.u-inline-85{width:33%}
.u-inline-86{height:40%}
.u-inline-87{height:60%}
.u-inline-88{height:30%}
.u-inline-89{height:80%}
.u-inline-90{height:55%}
.u-inline-91{height:90%}
.u-inline-92{display:grid;grid-template-columns:1fr 300px;gap:20px}
.u-inline-93{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.u-inline-94{font-family:'Quicksand',sans-serif;font-size:1.3rem;color:var(--coffee)}
.u-inline-95{font-size:.72rem;color:var(--bronze);letter-spacing:1px;text-transform:uppercase;margin-bottom:8px}
.u-inline-96{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}
.u-inline-97{min-height:70px;font-size:.84rem}
.u-inline-98{min-height:60px;font-size:.84rem}
.u-inline-99{margin-top:16px;display:flex;gap:10px}
.u-inline-100{padding:10px 18px}
.u-inline-101{padding:10px;background:var(--cream);border-radius:8px;cursor:pointer;border-left:3px solid var(--gold)}
.u-inline-102{font-size:.82rem;color:var(--text-mid);margin-top:3px;line-height:1.5}
.u-inline-103{margin-top:4px}
.u-inline-104{padding:10px;background:var(--cream);border-radius:8px;cursor:pointer}
.u-inline-105{margin-top:16px}
.u-inline-106{margin-bottom:12px}
.u-inline-107{grid-template-columns:1fr}
.u-inline-108{padding:10px 20px}

/* ============================================
   GLASS UPGRADE (Dashboard + Analytics + Sidebar)
============================================ */
:root{
  --glass-bg:rgba(59,30,18,.42);
  --glass-bg-soft:rgba(59,30,18,.28);
  --glass-border:rgba(240,215,166,.2);
  --glass-highlight:rgba(255,255,255,.16);
  --success:#2f9c57;
  --danger:#bf4a4a;
}

body{
  background:linear-gradient(135deg,#4b2616 0%,#63311c 40%,#8c5f2e 100%);
}

.ambient-bg{
  position:fixed;
  inset:0;
  z-index:-2;
  background:
    radial-gradient(circle at 20% 25%, rgba(226,181,109,.25), transparent 45%),
    radial-gradient(circle at 82% 70%, rgba(107,58,31,.4), transparent 40%),
    radial-gradient(circle at 62% 15%, rgba(240,215,166,.15), transparent 35%);
}

.orb{
  position:fixed;
  border-radius:50%;
  filter:blur(65px);
  z-index:-1;
  opacity:.35;
  pointer-events:none;
}

.orb-1{width:260px;height:260px;background:#d4a35a;top:9%;left:8%}
.orb-2{width:220px;height:220px;background:#6b3a1f;bottom:12%;right:10%}
.orb-3{width:180px;height:180px;background:#f0d7a6;top:62%;left:42%}

.sidebar{
  background:var(--glass-bg);
  backdrop-filter:blur(18px);
  -webkit-backdrop-filter:blur(18px);
  border-right:1px solid var(--glass-border);
  box-shadow:0 20px 42px rgba(0,0,0,.25);
  padding:18px 14px 14px;
}

.sidebar-brand{
  display:flex;
  align-items:center;
  gap:12px;
  border-bottom:1px solid var(--glass-border);
  padding:4px 10px 16px;
  margin-bottom:14px;
}

.brand-logo{
  width:40px;
  height:40px;
  border-radius:12px;
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:700;
  color:#fff;
  background:linear-gradient(145deg,var(--gold),var(--bronze));
  box-shadow:0 12px 24px rgba(212,163,90,.35);
}

.sidebar-brand .brand-name{
  font-size:1.45rem;
  color:var(--gold);
}

.sidebar-brand .brand-sub{
  color:rgba(240,215,166,.65);
}

.sidebar-clock{
  border:1px solid var(--glass-border);
  border-radius:14px;
  padding:10px 12px;
  margin:0 8px 12px;
  background:var(--glass-bg-soft);
}

#clock-display{
  font-size:1.75rem;
}

.sidebar-nav{
  padding:8px 0;
}

.nav-section-label{
  padding:8px 14px 6px;
  color:rgba(240,215,166,.6);
}

.nav-item{
  margin:2px 8px;
  border-radius:12px;
  padding:11px 13px;
  color:rgba(253,246,236,.8);
  background:transparent;
}

.nav-item:hover{
  background:rgba(240,215,166,.12);
  color:#fff;
  transform:translateX(2px);
}

.nav-item.active{
  background:linear-gradient(135deg,rgba(226,181,109,.24),rgba(139,90,43,.2));
  color:#fff;
}

.nav-item.active::before{
  display:none;
}

.nav-badge{
  margin-left:auto;
  font-size:.62rem;
  font-weight:700;
  padding:2px 8px;
  border-radius:999px;
  background:linear-gradient(135deg,var(--gold),var(--bronze));
  color:#fff;
}

.sidebar-footer{
  border-top:1px solid var(--glass-border);
}

.user-card{
  border:1px solid rgba(240,215,166,.18);
  background:rgba(240,215,166,.08);
}

.main{
  background:transparent;
}

.topbar{
  background:rgba(253,246,236,.92);
  backdrop-filter:blur(12px);
  -webkit-backdrop-filter:blur(12px);
  border-bottom:1px solid rgba(59,30,18,.14);
}

.topbar-search{
  background:rgba(240,215,166,.58);
  border-color:rgba(59,30,18,.16);
}

.dashboard-hero{
  background:var(--glass-bg);
  border:1px solid var(--glass-border);
  backdrop-filter:blur(16px);
  -webkit-backdrop-filter:blur(16px);
  border-radius:18px;
  padding:28px 30px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:24px;
  margin-bottom:18px;
  box-shadow:0 14px 30px rgba(0,0,0,.22);
}

.dashboard-hero-text .time-greeting{
  color:#fff;
  font-size:2rem;
}

.dashboard-hero-text .greeting-sub{
  color:rgba(253,246,236,.8);
  max-width:760px;
}

.dashboard-hero-clock{
  text-align:right;
}

.dashboard-hero-clock .big-time{
  color:var(--gold);
  font-family:'Quicksand',sans-serif;
  font-size:2.8rem;
  line-height:1;
}

.dashboard-hero-clock .big-date{
  color:rgba(253,246,236,.75);
  margin-top:4px;
}

.stats-grid-glass{
  display:grid;
  grid-template-columns:repeat(4,minmax(0,1fr));
  gap:16px;
  margin-bottom:20px;
}

.metric-link-card{
  display:flex;
  align-items:flex-start;
  justify-content:space-between;
  gap:12px;
  border-radius:14px;
  padding:16px 16px 14px;
  text-decoration:none;
  background:rgba(253,246,236,.9);
  border:1px solid rgba(59,30,18,.12);
  box-shadow:0 6px 22px rgba(0,0,0,.14);
  transition:transform .2s ease,box-shadow .2s ease;
}

.metric-link-card:hover{
  transform:translateY(-3px);
  box-shadow:0 12px 28px rgba(0,0,0,.18);
}

.metric-link-card.static{
  cursor:default;
}

.metric-copy{
  display:flex;
  flex-direction:column;
  gap:4px;
}

.metric-label{
  font-size:.72rem;
  text-transform:uppercase;
  letter-spacing:1px;
  color:var(--bronze);
}

.metric-value{
  font-size:1.65rem;
  line-height:1.1;
  font-weight:700;
  color:var(--coffee);
  font-family:'Quicksand',sans-serif;
}

.metric-trend{
  font-size:.75rem;
  color:var(--text-mid);
}

.metric-trend.positive{color:var(--success)}
.metric-trend.negative{color:var(--danger)}

.metric-icon-wrap{
  width:42px;
  height:42px;
  border-radius:12px;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(145deg,var(--gold),var(--bronze));
  color:#fff;
  flex-shrink:0;
  box-shadow:0 8px 18px rgba(0,0,0,.2);
}

.dashboard-columns{
  display:grid;
  grid-template-columns:minmax(0,2fr) minmax(290px,1fr);
  gap:18px;
}

.dashboard-primary,.dashboard-secondary{
  display:flex;
  flex-direction:column;
  gap:18px;
}

.dash-card{
  background:rgba(253,246,236,.92);
  border:1px solid rgba(59,30,18,.1);
  box-shadow:0 8px 24px rgba(0,0,0,.16);
}

.card-link-inline{
  color:var(--gold-deep);
  text-decoration:none;
  font-size:.78rem;
  font-weight:600;
}

.card-link-inline:hover{
  color:var(--coffee);
}

.compact-list{
  display:flex;
  flex-direction:column;
  gap:8px;
}

.compact-list-item{
  display:flex;
  align-items:center;
  gap:10px;
  text-decoration:none;
  padding:9px 10px;
  background:var(--cream);
  border-radius:10px;
  border:1px solid rgba(59,30,18,.08);
}

.compact-date{
  min-width:58px;
  text-align:center;
  padding:4px 8px;
  border-radius:8px;
  font-size:.7rem;
  letter-spacing:.7px;
  text-transform:uppercase;
  color:#fff;
  background:linear-gradient(145deg,var(--coffee),var(--bronze));
}

.compact-copy{
  font-size:.82rem;
  color:var(--text-mid);
}

.calendar-widget-card .calendar-header{
  margin-bottom:10px;
}

.calendar-nav{
  display:flex;
  gap:8px;
}

.calendar-nav-btn{
  width:30px;
  height:30px;
  border-radius:8px;
  border:1px solid rgba(59,30,18,.15);
  background:var(--cream);
  color:var(--coffee);
  cursor:pointer;
  display:flex;
  align-items:center;
  justify-content:center;
}

.calendar-nav-btn:hover{
  background:var(--cream-soft);
}

.calendar-grid{
  display:grid;
  grid-template-columns:repeat(7,minmax(0,1fr));
  gap:4px;
}

.calendar-day-name{
  text-align:center;
  font-size:.65rem;
  letter-spacing:1px;
  text-transform:uppercase;
  color:var(--bronze);
  padding:6px 0;
}

.calendar-day{
  height:34px;
  border-radius:8px;
  border:1px solid transparent;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:.78rem;
  color:var(--text-mid);
  position:relative;
}

.calendar-day.other-month{
  opacity:.45;
}

.calendar-day.today{
  background:linear-gradient(135deg,var(--gold),var(--bronze));
  color:#fff;
  font-weight:700;
}

.calendar-day.has-event::after{
  content:'';
  position:absolute;
  bottom:4px;
  width:5px;
  height:5px;
  border-radius:50%;
  background:var(--gold-deep);
}

.analytics-hero{
  display:flex;
  align-items:flex-end;
  justify-content:space-between;
  gap:14px;
  margin-bottom:18px;
}

.analytics-hero-actions{
  display:flex;
  align-items:center;
  gap:10px;
}

.analytics-stat-grid{
  margin-bottom:18px;
}

.analytics-grid{
  display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));
  gap:18px;
}

.analytics-main-chart{
  grid-column:span 2;
}

.card-subtitle{
  color:var(--bronze);
  font-size:.78rem;
  margin-top:2px;
}

@media (max-width:1200px){
  .stats-grid-glass{
    grid-template-columns:repeat(2,minmax(0,1fr));
  }
}

@media (max-width:980px){
  .dashboard-columns{
    grid-template-columns:1fr;
  }

  .analytics-grid{
    grid-template-columns:1fr;
  }

  .analytics-main-chart{
    grid-column:auto;
  }
}

@media (max-width:640px){
  .stats-grid-glass{
    grid-template-columns:1fr;
  }

  .dashboard-hero{
    flex-direction:column;
    align-items:flex-start;
  }

  .dashboard-hero-clock{
    text-align:left;
  }
}

/* ============================================
   FINANCE COMMAND CENTER
============================================ */
.hidden{display:none !important}

.finance-hero{
  display:flex;
  align-items:flex-end;
  justify-content:space-between;
  gap:16px;
  margin-bottom:18px;
}

.finance-hero-actions{
  display:flex;
  flex-wrap:wrap;
  gap:10px;
}

.finance-layout{
  display:grid;
  grid-template-columns:minmax(0,2.2fr) minmax(300px,1fr);
  gap:18px;
}

.finance-main-col,.finance-side-col{
  display:flex;
  flex-direction:column;
  gap:18px;
}

.finance-tab-bar{
  width:100%;
  display:flex;
  flex-wrap:wrap;
  gap:4px;
}

.finance-tab-bar .tab-btn{
  flex:1;
  min-width:120px;
}

.finance-metric-grid .metric-link-card{
  min-height:142px;
  position:relative;
}

.metric-with-tooltip{
  position:relative;
}

.metric-tooltip{
  position:absolute;
  left:14px;
  right:14px;
  bottom:14px;
  padding:7px 9px;
  border-radius:8px;
  font-size:.72rem;
  line-height:1.35;
  color:#fff;
  background:rgba(59,30,18,.88);
  opacity:0;
  transform:translateY(6px);
  pointer-events:none;
  transition:all .2s ease;
}

.metric-with-tooltip:hover .metric-tooltip{
  opacity:1;
  transform:translateY(0);
}

.ledger-toolbar{
  display:grid;
  grid-template-columns:repeat(5,minmax(120px,1fr));
  gap:10px;
  margin-bottom:12px;
}

.ledger-toolbar input,.ledger-toolbar select{
  width:100%;
  min-height:40px;
  padding:8px 10px;
  border:1px solid rgba(59,30,18,.16);
  border-radius:8px;
  font-size:.82rem;
  font-family:'Quicksand',sans-serif;
  color:var(--text-dark);
  background:var(--white);
}

.table-wrap{
  width:100%;
  overflow:auto;
}

.ledger-table{
  min-width:930px;
}

.action-cell{
  display:flex;
  flex-wrap:wrap;
  justify-content:flex-end;
  gap:6px;
}

.btn-mini{
  padding:6px 10px;
  border-radius:8px;
  font-size:.72rem;
  line-height:1.2;
}

.btn-outline.danger{
  border-color:var(--danger);
  color:var(--danger);
}

.btn-outline.danger:hover{
  background:var(--danger);
  color:#fff;
}

.amount-positive{color:var(--success);font-weight:600}
.amount-negative{color:var(--danger);font-weight:600}

.ledger-pagination{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  margin-top:12px;
  padding-top:10px;
  border-top:1px solid rgba(59,30,18,.1);
}

.pagination-meta{
  font-size:.78rem;
  color:var(--bronze);
}

.pagination-controls{
  display:flex;
  gap:8px;
}

.budget-grid,.savings-grid,.project-budget-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(240px,1fr));
  gap:14px;
}

.budget-card,.goal-card{
  border:1px solid rgba(59,30,18,.1);
  border-radius:12px;
  padding:12px;
  background:var(--cream);
}

.budget-card.over-limit{
  border-color:var(--danger);
  box-shadow:0 0 0 1px rgba(191,74,74,.25) inset;
}

.budget-card.warning{
  border-color:var(--gold-deep);
  box-shadow:0 0 0 1px rgba(212,163,90,.25) inset;
}

.budget-card-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  margin-bottom:8px;
}

.application-summary{
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:10px;
  margin-bottom:12px;
  padding:10px;
  border-radius:10px;
  border:1px solid rgba(59,30,18,.08);
  background:var(--cream);
}

.table-empty{
  text-align:center;
  color:var(--bronze);
  font-size:.82rem;
  padding:14px;
  border-radius:8px;
  background:rgba(240,215,166,.5);
}

.alert-read{
  opacity:.65;
}

.category-pill{
  border:1px solid rgba(59,30,18,.08);
}

.finance-categories-list{
  gap:10px;
}

.finance-category-item{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  padding:10px;
  border-radius:10px;
  border:1px solid rgba(59,30,18,.1);
  background:var(--cream);
}

.category-main{
  display:flex;
  align-items:center;
  gap:10px;
  min-width:0;
}

.category-dot{
  width:12px;
  height:12px;
  border-radius:50%;
  border:1px solid rgba(0,0,0,.08);
  flex-shrink:0;
}

.category-name{
  font-size:.84rem;
  font-weight:600;
  color:var(--coffee);
}

.category-meta{
  font-size:.72rem;
  color:var(--bronze);
  text-transform:capitalize;
}

.modal-overlay{
  position:fixed;
  inset:0;
  z-index:10020;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px;
  background:rgba(10,7,5,.58);
}

.modal-card{
  width:min(820px,96vw);
  max-height:90vh;
  overflow:auto;
  border-radius:14px;
  background:var(--white);
  border:1px solid rgba(59,30,18,.14);
  box-shadow:0 24px 64px rgba(0,0,0,.42);
  padding:14px;
}

.modal-header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:12px;
}

.modal-close{
  width:34px;
  height:34px;
  border:none;
  border-radius:8px;
  background:var(--cream);
  color:var(--text-dark);
  font-size:1.2rem;
  cursor:pointer;
}

.modal-form-grid{
  display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));
  gap:12px;
}

.modal-span-2{grid-column:span 2}

.modal-actions{
  display:flex;
  justify-content:flex-end;
  gap:8px;
}

body[data-theme="dark"]{
  --white:#2f2119;
  --cream:#3a281e;
  --cream-soft:#4b3427;
  --text-dark:#f4dfc1;
  --text-mid:#dabf99;
  --shadow:rgba(0,0,0,.5);
}

body[data-theme="dark"] .topbar{
  background:rgba(34,24,19,.9);
  border-bottom-color:rgba(240,215,166,.14);
}

body[data-theme="dark"] .topbar-search{
  background:rgba(240,215,166,.08);
  border-color:rgba(240,215,166,.22);
}

body[data-theme="dark"] .dash-card,
body[data-theme="dark"] .metric-link-card{
  background:rgba(53,37,28,.94);
  border-color:rgba(240,215,166,.18);
}

body[data-theme="dark"] .ledger-toolbar input,
body[data-theme="dark"] .ledger-toolbar select,
body[data-theme="dark"] .modal-close{
  background:rgba(32,22,17,.9);
  border-color:rgba(240,215,166,.2);
  color:var(--text-dark);
}

body[data-theme="dark"] .data-table td{
  border-bottom-color:rgba(240,215,166,.14);
  color:var(--text-mid);
}

body[data-theme="dark"] .data-table tr:hover td{
  background:rgba(240,215,166,.08);
}

body[data-theme="dark"] .table-empty,
body[data-theme="dark"] .budget-card,
body[data-theme="dark"] .goal-card,
body[data-theme="dark"] .application-summary,
body[data-theme="dark"] .finance-category-item,
body[data-theme="dark"] .compact-list-item,
body[data-theme="dark"] .insight-item{
  background:rgba(43,30,23,.9);
  border-color:rgba(240,215,166,.14);
}

body[data-theme="dark"] .modal-card{
  background:#2b1f18;
  border-color:rgba(240,215,166,.2);
}

@media (max-width:1200px){
  .finance-layout{
    grid-template-columns:1fr;
  }

  .finance-side-col{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
  }
}

@media (max-width:900px){
  .ledger-toolbar{
    grid-template-columns:repeat(2,minmax(0,1fr));
  }

  .application-summary{
    grid-template-columns:1fr;
  }
}

@media (max-width:640px){
  .finance-hero{
    flex-direction:column;
    align-items:flex-start;
  }

  .finance-side-col{
    grid-template-columns:1fr;
  }

  .ledger-toolbar{
    grid-template-columns:1fr;
  }

  .ledger-pagination{
    flex-direction:column;
    align-items:flex-start;
  }

  .modal-form-grid{
    grid-template-columns:1fr;
  }

  .modal-span-2{
    grid-column:auto;
  }
}

/* ============================================
   EDUCATION COMMAND CENTER
============================================ */
.education-hero{
  display:flex;
  align-items:flex-end;
  justify-content:space-between;
  gap:14px;
  margin-bottom:14px;
}

.education-hero-actions{
  display:flex;
  flex-wrap:wrap;
  gap:10px;
}

.education-tab-bar{
  width:100%;
  margin-top:12px;
}

.education-tab-bar .tab-btn{
  min-width:160px;
}

.education-toolbar{
  display:grid;
  grid-template-columns:2fr 1fr auto;
  gap:10px;
  margin-bottom:14px;
}

.education-toolbar input,.education-toolbar select{
  width:100%;
  min-height:40px;
  padding:8px 10px;
  border:1px solid rgba(59,30,18,.16);
  border-radius:8px;
  background:var(--white);
  color:var(--text-dark);
  font-family:'Quicksand',sans-serif;
}

.education-level-grid,.education-scholarship-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
  gap:14px;
}

.education-level-card,.education-scholarship-card{
  background:var(--cream);
  border:1px solid rgba(59,30,18,.1);
  border-radius:12px;
  padding:12px;
  display:flex;
  flex-direction:column;
  gap:10px;
}

.education-card-head{
  display:flex;
  align-items:flex-start;
  justify-content:space-between;
  gap:10px;
}

.education-title{
  font-size:.96rem;
  font-weight:700;
  color:var(--coffee);
}

.education-subtitle{
  font-size:.75rem;
  color:var(--bronze);
}

.education-details{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:8px 10px;
}

.education-detail{
  font-size:.78rem;
  color:var(--text-mid);
}

.education-detail strong{
  color:var(--coffee);
}

.education-expand{
  margin-top:2px;
  padding:10px;
  border-radius:10px;
  background:rgba(240,215,166,.35);
  border:1px solid rgba(59,30,18,.08);
}

.education-checklist{
  display:flex;
  flex-direction:column;
  gap:7px;
}

.education-check-item{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:8px;
  font-size:.8rem;
}

.education-check-item .left{
  display:flex;
  align-items:center;
  gap:8px;
}

.education-progress-track{
  height:8px;
  background:var(--cream-soft);
  border-radius:8px;
  overflow:hidden;
}

.education-progress-fill{
  height:100%;
  background:linear-gradient(90deg,var(--gold),var(--bronze));
  border-radius:8px;
}

.scholarship-result{
  display:inline-flex;
  align-items:center;
  gap:6px;
  border-radius:999px;
  padding:3px 10px;
  font-size:.72rem;
  font-weight:600;
  text-transform:capitalize;
}

.scholarship-result.accepted{background:rgba(47,156,87,.15);color:#2f9c57}
.scholarship-result.rejected{background:rgba(191,74,74,.16);color:#bf4a4a}
.scholarship-result.pending{background:rgba(226,181,109,.2);color:#8B5A2B}

.education-upload-dropzone{
  border:2px dashed rgba(139,90,43,.32);
  background:rgba(240,215,166,.35);
  border-radius:12px;
  padding:18px;
  text-align:center;
  margin-bottom:14px;
  display:flex;
  flex-direction:column;
  gap:6px;
  color:var(--text-mid);
}

.education-upload-dropzone.dragover{
  border-color:var(--gold-deep);
  background:rgba(226,181,109,.22);
}

.education-alert-item{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:8px;
  padding:8px 10px;
  border-radius:9px;
  background:var(--cream);
  border:1px solid rgba(59,30,18,.1);
  font-size:.8rem;
}

.education-alert-item .days{
  font-size:.72rem;
  color:var(--bronze);
}

body[data-theme="dark"] .education-level-card,
body[data-theme="dark"] .education-scholarship-card,
body[data-theme="dark"] .education-expand,
body[data-theme="dark"] .education-upload-dropzone,
body[data-theme="dark"] .education-alert-item{
  background:rgba(43,30,23,.9);
  border-color:rgba(240,215,166,.14);
}

body[data-theme="dark"] .education-toolbar input,
body[data-theme="dark"] .education-toolbar select{
  background:rgba(32,22,17,.9);
  border-color:rgba(240,215,166,.2);
  color:var(--text-dark);
}

@media (max-width:900px){
  .education-toolbar{
    grid-template-columns:1fr 1fr;
  }

  .education-toolbar .btn-outline{
    grid-column:span 2;
  }
}

@media (max-width:640px){
  .education-hero{
    flex-direction:column;
    align-items:flex-start;
  }

  .education-toolbar{
    grid-template-columns:1fr;
  }

  .education-toolbar .btn-outline{
    grid-column:auto;
  }

  .education-details{
    grid-template-columns:1fr;
  }
}

/* ============================================
   PERSONAL IDENTITY VAULT
============================================ */
.personal-vault-hero{
  display:flex;
  align-items:flex-end;
  justify-content:space-between;
  gap:14px;
  margin-bottom:16px;
}

.personal-vault-hero-actions{
  display:flex;
  gap:10px;
}

.personal-progress-card{
  margin-bottom:14px;
}

.personal-score{
  font-family:'Quicksand',sans-serif;
  font-size:1.4rem;
  font-weight:700;
  color:var(--coffee);
}

.personal-draft-indicator{
  margin-top:8px;
  font-size:.76rem;
  color:var(--bronze);
}

.personal-draft-indicator.error{
  color:var(--danger);
}

.personal-wizard-steps .wizard-step.in-progress{
  border-color:rgba(212,163,90,.65);
  background:rgba(226,181,109,.18);
  color:var(--gold-deep);
}

.personal-tag-input{
  display:flex;
  align-items:center;
  gap:8px;
}

.personal-tag-input input{
  flex:1;
}

.personal-tags{
  display:flex;
  flex-wrap:wrap;
  gap:8px;
  min-height:36px;
  align-items:center;
}

.personal-tag-chip{
  display:inline-flex;
  align-items:center;
  gap:8px;
  border-radius:999px;
  padding:4px 10px;
  font-size:.75rem;
  border:1px solid rgba(59,30,18,.14);
  background:rgba(240,215,166,.7);
  color:var(--text-mid);
}

.personal-tag-chip button{
  border:none;
  background:none;
  color:var(--coffee);
  cursor:pointer;
  font-size:.9rem;
  line-height:1;
}

.personal-photo-layout{
  display:grid;
  grid-template-columns:1.2fr .9fr;
  gap:12px;
}

.personal-photo-preview{
  border:1px solid rgba(59,30,18,.12);
  border-radius:12px;
  background:rgba(240,215,166,.35);
  min-height:200px;
  padding:10px;
  display:flex;
  flex-direction:column;
  gap:10px;
}

.personal-photo-image{
  width:100%;
  height:180px;
  object-fit:cover;
  border-radius:10px;
  border:1px solid rgba(59,30,18,.12);
}

.personal-photo-meta{
  display:flex;
  flex-direction:column;
  gap:3px;
}

.personal-photo-name{
  font-size:.95rem;
  font-weight:700;
  color:var(--coffee);
}

.personal-photo-sub{
  font-size:.73rem;
  color:var(--bronze);
}

.vault-platform{
  display:inline-flex;
  align-items:center;
  gap:8px;
}

.personal-alert-warning{
  border-color:rgba(212,163,90,.5);
  background:rgba(226,181,109,.2);
}

body[data-theme="dark"] .personal-score{
  color:var(--gold);
}

body[data-theme="dark"] .personal-draft-indicator{
  color:var(--text-mid);
}

body[data-theme="dark"] .personal-tag-chip,
body[data-theme="dark"] .personal-photo-preview{
  background:rgba(43,30,23,.9);
  border-color:rgba(240,215,166,.16);
  color:var(--text-dark);
}

body[data-theme="dark"] .personal-tag-chip button{
  color:var(--gold);
}

@media (max-width:980px){
  .personal-photo-layout{
    grid-template-columns:1fr;
  }
}

@media (max-width:640px){
  .personal-vault-hero{
    flex-direction:column;
    align-items:flex-start;
  }

  .personal-tag-input{
    flex-direction:column;
    align-items:stretch;
  }
}

```

---

## myos_project/myos_app/static/js/main.js

- Size: 165966 bytes
- Lines: 4087
- Modified: 2026-03-06 21:33:43
- SHA256: c59ab3b2cffc4bf5064ec1ca9761f658a36dcd41475c47a612e10a29e902b8ec
- MIME: application/javascript

```
const CHECK_ICON_SMALL = '<i class="fas fa-check check-icon-small"></i>';
const CHECK_ICON = '<i class="fas fa-check check-icon-normal"></i>';
const AUTH_STORAGE_KEY = 'myos-authenticated';
const PAGE_ROUTES = {
  dashboard: '/',
  personal: '/personal/',
  education: '/education/',
  finance: '/finance/',
  media: '/media/',
  bucket: '/bucket/',
  projects: '/projects/',
  diary: '/diary/',
  settings: '/settings/',
};
const FORM_SAVE_DEBOUNCE_MS = 700;
const THEME_STORAGE_KEY = 'myos-theme';

const appState = {
  tasks: [],
  diaryEntries: [],
};

const financeState = {
  metrics: [],
  ledger: [],
  budgets: [],
  goals: [],
  applicationCosts: [],
  projectBudgets: [],
  recurringForecast: [],
  alerts: [],
  insights: [],
  categories: [],
  charts: {},
  chartInstances: {},
  isSetup: false,
  pagination: {
    page: 1,
    page_size: 12,
    total_pages: 1,
    total_items: 0,
  },
  filters: {
    q: '',
    date_from: '',
    date_to: '',
    category_id: '',
    account: '',
    tx_type: '',
    amount_min: '',
    amount_max: '',
    sort: 'date_desc',
    page: 1,
    page_size: 12,
  },
};

const educationState = {
  levels: [],
  exams: [],
  documents: [],
  scholarships: [],
  deadlineAlerts: [],
  filters: {
    q: '',
    status: '',
  },
  pendingDocumentFile: null,
  isSetup: false,
};

const projectsState = {
  rows: [],
  chartInstances: {},
  isSetup: false,
};

const personalState = {
  identity: {},
  contact: {},
  identityDocuments: {},
  uploadedFiles: [],
  digitalAccounts: [],
  socialProfiles: {},
  passwordReferences: [],
  completionScore: 0,
  stepStatus: [],
  suggestions: [],
  expiryAlerts: [],
  tags: {
    languages: [],
    additionalEmails: [],
    otherPhones: [],
  },
  filters: {
    accountSearch: '',
    accountPlatform: '',
  },
  pendingProfilePhoto: null,
  pendingIdentityFile: null,
  currentStep: 1,
  isSetup: false,
  autosaveTimers: {},
};

let pageFormSaveTimer = null;
let pendingUploadContext = null;
const dashboardCalendarState = { cursor: new Date() };
const DASHBOARD_EVENT_DATES = new Set();

function isAuthenticated() {
  try {
    return localStorage.getItem(AUTH_STORAGE_KEY) === '1';
  } catch (err) {
    return false;
  }
}

function setAuthenticatedState(value) {
  try {
    if (value) localStorage.setItem(AUTH_STORAGE_KEY, '1');
    else localStorage.removeItem(AUTH_STORAGE_KEY);
  } catch (err) {
    // Ignore storage issues and continue with session-only behavior.
  }
}

function openApp() {
  const app = document.getElementById('app');
  const overlay = document.getElementById('auth-overlay');
  if (overlay) {
    overlay.classList.add('hide');
    setTimeout(() => {
      overlay.style.display = 'none';
    }, 280);
  }
  if (app) app.classList.add('show');
}

function closeApp() {
  const app = document.getElementById('app');
  const overlay = document.getElementById('auth-overlay');
  if (app) app.classList.remove('show');
  if (overlay) {
    overlay.style.display = 'flex';
    overlay.classList.remove('hide');
  }
}

function getActivePage() {
  return document.body?.dataset?.page || 'dashboard';
}

function escapeSelectorValue(value) {
  if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
  return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
}

function updateClock() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  const dateStr = now.toLocaleDateString('en-KE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const el = (id) => document.getElementById(id);

  if (el('clock-display')) el('clock-display').textContent = timeStr;
  if (el('clock-date')) el('clock-date').textContent = dateStr;
  if (el('big-clock')) el('big-clock').textContent = timeStr;
  if (el('big-date')) el('big-date').textContent = dateStr;

  const h = now.getHours();
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  if (el('greeting-text')) el('greeting-text').textContent = greet;
}

function switchAuth(mode) {
  const isLogin = mode === 'login';
  document.querySelectorAll('.auth-tab').forEach((t, i) => {
    t.classList.toggle('active', isLogin ? i === 0 : i === 1);
  });
  const loginForm = document.getElementById('login-form');
  const signupForm = document.getElementById('signup-form');
  const otpSection = document.getElementById('otp-section');
  const tabsBar = document.getElementById('auth-tabs-bar');

  if (loginForm) loginForm.classList.toggle('active', isLogin);
  if (signupForm) signupForm.classList.toggle('active', !isLogin);
  if (otpSection) otpSection.classList.remove('active');
  if (tabsBar) tabsBar.style.display = 'flex';
}

function withButtonLoading(btn, text, cb) {
  if (!btn) {
    cb();
    return;
  }

  const original = btn.innerHTML;
  btn.disabled = true;
  btn.classList.add('is-loading');
  btn.innerHTML = text;

  setTimeout(() => {
    cb();
    btn.disabled = false;
    btn.classList.remove('is-loading');
    btn.innerHTML = original;
  }, 300);
}

function handleSignup() {
  const emailInput = document.getElementById('signup-email');
  const email = emailInput ? emailInput.value.trim() : '';
  if (!email || !email.includes('@')) {
    showToast('Please enter a valid email address');
    if (emailInput) emailInput.focus();
    return;
  }
  const triggerBtn = document.activeElement && document.activeElement.tagName === 'BUTTON'
    ? document.activeElement
    : null;

  withButtonLoading(triggerBtn, 'Sending OTP...', () => {
    const otpEmailDisplay = document.getElementById('otp-email-display');
    const signupForm = document.getElementById('signup-form');
    const otpSection = document.getElementById('otp-section');
    const tabsBar = document.getElementById('auth-tabs-bar');

    if (otpEmailDisplay) otpEmailDisplay.textContent = email;
    if (signupForm) signupForm.classList.remove('active');
    if (otpSection) otpSection.classList.add('active');
    if (tabsBar) tabsBar.style.display = 'none';
    const firstOtp = document.querySelector('.otp-digit');
    if (firstOtp) firstOtp.focus();
    showToast('OTP sent successfully');
  });
}

function otpNext(el) {
  el.value = el.value.replace(/\D/g, '');
  if (el.value.length === 1 && el.nextElementSibling) el.nextElementSibling.focus();
}

function otpVerify(el) {
  el.value = el.value.replace(/\D/g, '');
  if (el.value.length === 1) setTimeout(handleLogin, 300);
}

function getOtpCode() {
  return Array.from(document.querySelectorAll('.otp-digit')).map((d) => d.value).join('');
}

function handleLogin() {
  const code = getOtpCode();
  const otpSection = document.getElementById('otp-section');
  const inOtpMode = otpSection ? otpSection.classList.contains('active') : false;

  if (inOtpMode && code.length !== 6) {
    showToast('Please enter the full 6-digit OTP');
    return;
  }

  setAuthenticatedState(true);
  openApp();
  animateProgressBars();
  if (!isPersonalPage()) {
    setupPageFormPersistence();
  }
  loadUnlockedPageData();
  showToast('Welcome back');
}

function signOut() {
  setAuthenticatedState(false);
  closeApp();
  switchAuth('login');
  document.querySelectorAll('.otp-digit').forEach((d) => {
    d.value = '';
  });
  showToast('Signed out');
}

function showPage(id) {
  const route = PAGE_ROUTES[id];
  if (route) window.location.href = route;
}

function loadUnlockedPageData() {
  loadBootstrapData();
  if (!isPersonalPage()) {
    loadPageFormData();
  }
  loadUploadedFilesForPage();
  loadDashboardEducationAlerts();
  if (isPersonalPage()) {
    setupPersonalPage();
  } else if (isFinancePage()) {
    setupFinancePage();
  } else if (getActivePage() === 'education') {
    setupEducationPage();
  } else if (getActivePage() === 'projects') {
    setupProjectsPage();
  } else {
    setTimeout(initCharts, 80);
  }
}

function goPersonalStep(n) {
  const target = Number(n || 1);
  const clamped = Math.min(6, Math.max(1, target));
  personalState.currentStep = clamped;

  for (let i = 1; i <= 6; i += 1) {
    const panel = document.getElementById(`personal-panel-${i}`);
    if (panel) panel.classList.toggle('active', i === clamped);
  }
  renderPersonalStepStatus();
}

function switchTab(prefix, id) {
  const panel = document.getElementById(`${prefix}-${id}`);
  if (!panel) return;

  const siblings = panel.parentElement.querySelectorAll(':scope > .tab-panel');
  siblings.forEach((p) => p.classList.remove('active'));
  panel.classList.add('active');

  let prev = panel.previousElementSibling;
  while (prev && !prev.classList.contains('tab-bar')) prev = prev.previousElementSibling;

  if (prev && prev.classList.contains('tab-bar')) {
    prev.querySelectorAll('.tab-btn').forEach((btn) => {
      const onclick = btn.getAttribute('onclick') || '';
      btn.classList.toggle('active', onclick.includes(`'${id}'`));
    });
  }

  if (prefix === 'fin') {
    if (id !== 'analytics') return;
    setTimeout(renderFinanceCharts, 40);
    return;
  }
  if (prefix === 'prj') {
    if (id !== 'analytics') return;
    setTimeout(() => renderProjectsCharts(projectsState.rows), 40);
    return;
  }
  setTimeout(initCharts, 40);
}

function getCookie(name) {
  const match = document.cookie.match(new RegExp(`(^| )${name}=([^;]+)`));
  return match ? decodeURIComponent(match[2]) : '';
}

async function apiRequest(path, method = 'GET', payload = null) {
  const options = {
    method,
    headers: {
      Accept: 'application/json',
    },
    credentials: 'same-origin',
  };

  if (payload !== null) {
    options.headers['Content-Type'] = 'application/json';
    options.headers['X-CSRFToken'] = getCookie('csrftoken');
    options.body = JSON.stringify(payload);
  }

  const response = await fetch(path, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || 'Request failed');
  }
  return data;
}

async function apiRequestForm(path, formData) {
  const response = await fetch(path, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'X-CSRFToken': getCookie('csrftoken'),
    },
    body: formData,
    credentials: 'same-origin',
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || 'Upload failed');
  }
  return data;
}

function getPageContainer() {
  const activePage = getActivePage();
  return document.getElementById(`page-${activePage}`) || document.querySelector('.page-content');
}

function collectPageFormData() {
  const container = getPageContainer();
  if (!container) return {};

  const values = {};
  container.querySelectorAll('input, textarea, select').forEach((field) => {
    const key = field.id || field.name;
    if (!key) return;
    if (field.closest('#auth-overlay')) return;
    if (field.type === 'button' || field.type === 'submit' || field.type === 'file') return;

    if (field.type === 'checkbox') {
      values[key] = field.checked;
      return;
    }

    if (field.type === 'radio') {
      if (field.checked) values[key] = field.value;
      return;
    }

    values[key] = field.value;
  });

  return values;
}

function applyPageFormData(data) {
  if (!data || typeof data !== 'object') return;
  const container = getPageContainer();
  if (!container) return;

  Object.entries(data).forEach(([key, value]) => {
    const escapedKey = escapeSelectorValue(key);
    const field = container.querySelector(`#${escapedKey}`) || container.querySelector(`[name="${escapedKey}"]`);
    if (!field) return;
    if (field.type === 'checkbox') {
      field.checked = Boolean(value);
      return;
    }
    if (field.type === 'radio') {
      const group = container.querySelectorAll(`[name="${escapedKey}"]`);
      group.forEach((item) => {
        item.checked = item.value === value;
      });
      return;
    }
    field.value = value ?? '';
  });
}

async function savePageFormData() {
  if (!isAuthenticated()) return;
  const activePage = getActivePage();

  const data = collectPageFormData();
  try {
    await apiRequest(`/api/forms/${activePage}/save/`, 'POST', { data });
  } catch (err) {
    // Quiet autosave failures; critical saves still use explicit actions.
  }
}

async function loadPageFormData() {
  if (!isAuthenticated()) return;
  const activePage = getActivePage();
  try {
    const result = await apiRequest(`/api/forms/${activePage}/`);
    applyPageFormData(result.data);
  } catch (err) {
    // Ignore when no saved state or when page is still locked.
  }
}

function setupPageFormPersistence() {
  const container = getPageContainer();
  if (!container) return;

  const scheduleSave = () => {
    clearTimeout(pageFormSaveTimer);
    pageFormSaveTimer = setTimeout(savePageFormData, FORM_SAVE_DEBOUNCE_MS);
  };

  container.querySelectorAll('input, textarea, select').forEach((field) => {
    if (field.closest('#auth-overlay')) return;
    field.addEventListener('input', scheduleSave);
    field.addEventListener('change', scheduleSave);
  });
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let unitIdx = 0;
  while (size >= 1024 && unitIdx < units.length - 1) {
    size /= 1024;
    unitIdx += 1;
  }
  return `${size.toFixed(size >= 10 || unitIdx === 0 ? 0 : 1)} ${units[unitIdx]}`;
}

function renderUploadLists(files) {
  const grouped = {};
  files.forEach((file) => {
    if (!grouped[file.field_key]) grouped[file.field_key] = [];
    grouped[file.field_key].push(file);
  });

  document.querySelectorAll('[data-upload-list-for]').forEach((container) => {
    const fieldKey = container.dataset.uploadListFor;
    const fieldFiles = grouped[fieldKey] || [];
    container.innerHTML = '';

    if (!fieldFiles.length) {
      const empty = document.createElement('div');
      empty.className = 'u-inline-31';
      empty.textContent = 'No files uploaded yet';
      container.appendChild(empty);
      return;
    }

    fieldFiles.forEach((item) => {
      const row = document.createElement('div');
      row.className = 'upload-file-item';

      const link = document.createElement('a');
      link.href = item.url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = item.original_name || 'Uploaded file';

      const meta = document.createElement('span');
      meta.className = 'upload-file-meta';
      meta.textContent = formatBytes(item.file_size);

      row.appendChild(link);
      row.appendChild(meta);
      container.appendChild(row);
    });
  });
}

async function loadUploadedFilesForPage() {
  const uploadTargets = document.querySelectorAll('[data-upload-list-for]');
  if (!uploadTargets.length || !isAuthenticated()) return;

  try {
    const activePage = getActivePage();
    const result = await apiRequest(`/api/uploads/${activePage}/`);
    renderUploadLists(result.files || []);
  } catch (err) {
    showToast(err.message || 'Failed to load uploaded files');
  }
}

async function uploadSelectedFile(file, context) {
  if (!file || !context) return;
  const { page, key, label } = context;
  const payload = new FormData();
  payload.append('file', file);
  payload.append('label', label || '');

  try {
    await apiRequestForm(`/api/uploads/${page}/${key}/`, payload);
    showToast('File uploaded successfully');
    loadUploadedFilesForPage();
  } catch (err) {
    showToast(err.message || 'Upload failed');
  }
}

function setupUploadZones() {
  const uploadInput = document.getElementById('global-upload-input');
  if (!uploadInput) return;

  document.querySelectorAll('.upload-zone[data-upload-key]').forEach((zone) => {
    zone.addEventListener('click', () => {
      pendingUploadContext = {
        page: getActivePage(),
        key: zone.dataset.uploadKey,
        label: zone.dataset.uploadLabel || '',
      };
      uploadInput.value = '';
      uploadInput.click();
    });
  });

  uploadInput.addEventListener('change', () => {
    const [file] = uploadInput.files || [];
    if (!file || !pendingUploadContext) return;
    uploadSelectedFile(file, pendingUploadContext);
    pendingUploadContext = null;
  });
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function renderTasks(tasks) {
  appState.tasks = tasks.slice();
  const taskList = document.getElementById('task-list');
  if (!taskList) return;

  taskList.innerHTML = tasks
    .map(
      (task) => `
      <div class="task-item">
        <div class="task-check ${task.is_done ? 'done' : ''}" data-task-id="${task.id}" onclick="toggleTask(this)">${task.is_done ? CHECK_ICON_SMALL : ''}</div>
        <span class="task-text ${task.is_done ? 'done' : ''}">${escapeHtml(task.title)}</span>
      </div>`
    )
    .join('');

  updateTaskProgress();
}

function updateTaskProgress() {
  const total = appState.tasks.length || 0;
  const done = appState.tasks.filter((t) => t.is_done).length;
  const percent = total ? Math.round((done / total) * 100) : 0;

  const textEl = document.getElementById('task-progress-text');
  const percentEl = document.getElementById('task-progress-percent');
  const fillEl = document.getElementById('task-progress-fill');

  if (textEl) textEl.textContent = `${done} / ${total} tasks done`;
  if (percentEl) percentEl.textContent = `${percent}%`;
  if (fillEl) fillEl.style.width = `${percent}%`;
}

async function toggleTask(el) {
  const taskId = Number(el.dataset.taskId || 0);
  const txt = el.nextElementSibling;

  if (!taskId) {
    el.classList.toggle('done');
    if (txt) txt.classList.toggle('done');
    el.innerHTML = el.classList.contains('done') ? CHECK_ICON_SMALL : '';
    return;
  }

  try {
    const res = await apiRequest(`/api/tasks/${taskId}/toggle/`, 'POST', {});
    const task = res.task;
    appState.tasks = appState.tasks.map((t) => (t.id === task.id ? task : t));
    el.classList.toggle('done', task.is_done);
    if (txt) txt.classList.toggle('done', task.is_done);
    el.innerHTML = task.is_done ? CHECK_ICON_SMALL : '';
    updateTaskProgress();
  } catch (err) {
    showToast(err.message || 'Failed to update task');
  }
}

function renderDiaryEntries(entries) {
  appState.diaryEntries = entries.slice();
  const container = document.getElementById('diary-past-entries');
  if (!container) return;

  container.innerHTML = entries
    .slice(0, 8)
    .map((entry, idx) => {
      const date = new Date(entry.entry_date);
      const dateText = Number.isNaN(date.getTime())
        ? entry.entry_date
        : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      const preview = entry.content ? entry.content.slice(0, 80) : 'No content yet...';
      return `
        <div class="${idx === 0 ? 'u-inline-101' : 'u-inline-104'}">
          <div class="u-inline-31">${escapeHtml(dateText)}</div>
          <div class="u-inline-102">${escapeHtml(preview)}${entry.content && entry.content.length > 80 ? '...' : ''}</div>
          <div class="u-inline-103"><span class="mood-badge">${escapeHtml(entry.mood || '🙂 Neutral')}</span></div>
        </div>`;
    })
    .join('');
}

async function saveDiaryEntry() {
  const main = document.getElementById('diary-main-text');
  const achievements = document.getElementById('diary-achievements');
  const lessons = document.getElementById('diary-lessons');
  const ideas = document.getElementById('diary-ideas');
  const selectedMood = document.querySelector('.mood-selector .mood-btn.selected');

  const payload = {
    mood: selectedMood ? selectedMood.textContent.trim() : '🙂 Neutral',
    content: main ? main.value.trim() : '',
    achievements: achievements ? achievements.value.trim() : '',
    lessons: lessons ? lessons.value.trim() : '',
    ideas: ideas ? ideas.value.trim() : '',
  };

  try {
    const res = await apiRequest('/api/diary/save/', 'POST', payload);
    appState.diaryEntries.unshift(res.entry);
    renderDiaryEntries(appState.diaryEntries);
    showToast('Entry saved');
  } catch (err) {
    showToast(err.message || 'Failed to save diary entry');
  }
}

async function saveProfileSettings() {
  const displayName = document.getElementById('settings-display-name');
  const email = document.getElementById('settings-email');
  const timezone = document.getElementById('settings-timezone');

  try {
    await apiRequest('/api/profile/save/', 'POST', {
      display_name: displayName ? displayName.value.trim() : '',
      email: email ? email.value.trim() : '',
      timezone: timezone ? timezone.value.trim() : '',
    });
    showToast('Settings saved');
  } catch (err) {
    showToast(err.message || 'Failed to save settings');
  }
}

async function saveNotificationSettings() {
  const payload = {
    scholarship_deadlines: Boolean(document.getElementById('notif-scholarship')?.checked),
    task_due_alerts: Boolean(document.getElementById('notif-tasks')?.checked),
    diary_prompt: Boolean(document.getElementById('notif-diary')?.checked),
    finance_alerts: Boolean(document.getElementById('notif-finance')?.checked),
  };

  try {
    await apiRequest('/api/notifications/save/', 'POST', payload);
    showToast('Notification preferences saved');
  } catch (err) {
    showToast(err.message || 'Failed to save notification settings');
  }
}

async function loadBootstrapData() {
  try {
    const data = await apiRequest('/api/bootstrap/');
    renderTasks(data.tasks || []);
    renderDiaryEntries(data.diary_entries || []);

    if (data.profile) {
      const displayName = document.getElementById('settings-display-name');
      const email = document.getElementById('settings-email');
      const timezone = document.getElementById('settings-timezone');
      const sidebarName = document.getElementById('sidebar-user-name');
      const sidebarEmail = document.getElementById('sidebar-user-email');
      if (displayName) displayName.value = data.profile.display_name || '';
      if (email) email.value = data.profile.email || '';
      if (timezone) timezone.value = data.profile.timezone || 'UTC';
      if (sidebarName) sidebarName.textContent = data.profile.display_name || 'User';
      if (sidebarEmail) sidebarEmail.textContent = data.profile.email || 'No email set';
    }

    if (data.notifications) {
      const scholarship = document.getElementById('notif-scholarship');
      const tasks = document.getElementById('notif-tasks');
      const diary = document.getElementById('notif-diary');
      const finance = document.getElementById('notif-finance');
      if (scholarship) scholarship.checked = Boolean(data.notifications.scholarship_deadlines);
      if (tasks) tasks.checked = Boolean(data.notifications.task_due_alerts);
      if (diary) diary.checked = Boolean(data.notifications.diary_prompt);
      if (finance) finance.checked = Boolean(data.notifications.finance_alerts);
    }
  } catch (err) {
    showToast('Could not load saved data');
  }
}

function formatMoneyKES(value) {
  const num = Number(value || 0);
  return `KES ${num.toLocaleString('en-KE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function getCurrentTheme() {
  try {
    return localStorage.getItem(THEME_STORAGE_KEY) || 'light';
  } catch (err) {
    return 'light';
  }
}

function applyTheme(theme) {
  const resolved = theme === 'dark' ? 'dark' : 'light';
  document.body.dataset.theme = resolved;
  try {
    localStorage.setItem(THEME_STORAGE_KEY, resolved);
  } catch (err) {
    // Ignore storage failures.
  }

  const btn = document.getElementById('theme-toggle-btn');
  if (btn) {
    btn.innerHTML = resolved === 'dark'
      ? '<i class=\"fas fa-sun\"></i> Light Mode'
      : '<i class=\"fas fa-moon\"></i> Dark Mode';
  }
}

function toggleTheme() {
  const current = getCurrentTheme();
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  renderFinanceCharts();
}

function isFinancePage() {
  return getActivePage() === 'finance';
}

function financeApiGet(path, query = null) {
  if (query) {
    const params = new URLSearchParams(query);
    return apiRequest(`${path}?${params.toString()}`);
  }
  return apiRequest(path);
}

function financeApiPost(path, payload) {
  return apiRequest(path, 'POST', payload || {});
}

function readLedgerFiltersFromUI() {
  const getVal = (id) => (document.getElementById(id)?.value || '').trim();
  financeState.filters = {
    ...financeState.filters,
    q: getVal('ledger-search'),
    date_from: getVal('ledger-date-from'),
    date_to: getVal('ledger-date-to'),
    category_id: getVal('ledger-category-filter'),
    account: getVal('ledger-account-filter'),
    tx_type: getVal('ledger-type-filter'),
    amount_min: getVal('ledger-amount-min'),
    amount_max: getVal('ledger-amount-max'),
    sort: getVal('ledger-sort') || 'date_desc',
  };
}

function updateLedgerFilterUI() {
  const setVal = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value || '';
  };
  setVal('ledger-search', financeState.filters.q);
  setVal('ledger-date-from', financeState.filters.date_from);
  setVal('ledger-date-to', financeState.filters.date_to);
  setVal('ledger-category-filter', financeState.filters.category_id);
  setVal('ledger-account-filter', financeState.filters.account);
  setVal('ledger-type-filter', financeState.filters.tx_type);
  setVal('ledger-amount-min', financeState.filters.amount_min);
  setVal('ledger-amount-max', financeState.filters.amount_max);
  setVal('ledger-sort', financeState.filters.sort);
}

function renderFinanceMetrics(metrics = []) {
  financeState.metrics = metrics.slice();
  const container = document.getElementById('finance-metric-cards');
  if (!container) return;
  container.innerHTML = metrics.map((metric) => {
    const trend = Number(metric.trend || 0);
    const trendClass = trend >= 0 ? 'positive' : 'negative';
    const trendArrow = trend >= 0 ? '▲' : '▼';
    return `
      <div class="metric-link-card static metric-with-tooltip">
        <div class="metric-copy">
          <div class="metric-label">${escapeHtml(metric.label || 'Metric')}</div>
          <div class="metric-value">${formatMoneyKES(metric.value || 0)}</div>
          <div class="metric-trend ${trendClass}">${trendArrow} ${Math.abs(trend).toFixed(1)}%</div>
          <div class="metric-tooltip">${escapeHtml(metric.description || '')}</div>
        </div>
        <div class="metric-icon-wrap"><i class="fas ${escapeHtml(metric.icon || 'fa-chart-line')}"></i></div>
      </div>`;
  }).join('');
}

function formatTxnSign(row) {
  const signed = Number(row.signed_amount || 0);
  const css = signed >= 0 ? 'amount-positive' : 'amount-negative';
  return `<span class="${css}">${signed >= 0 ? '+' : '-'}${formatMoneyKES(Math.abs(signed))}</span>`;
}

function renderLedgerTable(rows = []) {
  financeState.ledger = rows.slice();
  const body = document.getElementById('ledger-table-body');
  if (!body) return;
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" class="table-empty">No transactions found for current filters.</td></tr>';
    return;
  }

  body.innerHTML = rows.map((row) => `
    <tr>
      <td>${escapeHtml(row.tx_date || '')}</td>
      <td>${escapeHtml(row.description || '')}</td>
      <td><span class="tag category-pill" style="background:${escapeHtml(row.category?.color || '#8B5A2B')}33;color:${escapeHtml(row.category?.color || '#8B5A2B')}">${escapeHtml(row.category?.name || 'Uncategorized')}</span></td>
      <td>${escapeHtml((row.account || '').replace('_', ' '))}</td>
      <td>${formatTxnSign(row)}</td>
      <td>${(row.tags || []).map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`).join(' ')}</td>
      <td class="action-cell">
        <button class="btn-outline btn-mini" type="button" data-action="edit-transaction" data-id="${row.id}">Edit</button>
        <button class="btn-outline btn-mini danger" type="button" data-action="delete-transaction" data-id="${row.id}">Delete</button>
      </td>
    </tr>
  `).join('');
}

function renderLedgerPagination(pagination) {
  financeState.pagination = { ...financeState.pagination, ...(pagination || {}) };
  const container = document.getElementById('ledger-pagination');
  if (!container) return;
  const page = financeState.pagination.page || 1;
  const totalPages = financeState.pagination.total_pages || 1;
  const totalItems = financeState.pagination.total_items || 0;
  container.innerHTML = `
    <div class="pagination-meta">Page ${page} of ${totalPages} · ${totalItems} rows</div>
    <div class="pagination-controls">
      <button class="btn-outline btn-mini" type="button" id="ledger-prev-page" ${page <= 1 ? 'disabled' : ''}>Prev</button>
      <button class="btn-outline btn-mini" type="button" id="ledger-next-page" ${page >= totalPages ? 'disabled' : ''}>Next</button>
    </div>`;

  const prev = document.getElementById('ledger-prev-page');
  const next = document.getElementById('ledger-next-page');
  if (prev) {
    prev.addEventListener('click', () => {
      if (financeState.pagination.page > 1) {
        financeState.filters.page = financeState.pagination.page - 1;
        loadFinanceLedger();
      }
    });
  }
  if (next) {
    next.addEventListener('click', () => {
      if (financeState.pagination.page < financeState.pagination.total_pages) {
        financeState.filters.page = financeState.pagination.page + 1;
        loadFinanceLedger();
      }
    });
  }
}

function renderBudgetCards(rows = []) {
  financeState.budgets = rows.slice();
  const grid = document.getElementById('budget-grid');
  if (!grid) return;
  if (!rows.length) {
    grid.innerHTML = '<div class="table-empty">No budgets configured yet.</div>';
    return;
  }

  grid.innerHTML = rows.map((item) => `
    <div class="budget-card ${item.is_over_limit ? 'over-limit' : item.is_warning ? 'warning' : ''}">
      <div class="budget-card-head">
        <span class="tag" style="background:${escapeHtml(item.category.color)}33;color:${escapeHtml(item.category.color)}">${escapeHtml(item.category.name)}</span>
        <div class="action-cell">
          <button class="btn-outline btn-mini" type="button" data-action="edit-budget" data-id="${item.id}">Edit</button>
          <button class="btn-outline btn-mini danger" type="button" data-action="delete-budget" data-id="${item.id}">Delete</button>
        </div>
      </div>
      <div class="finance-row"><span class="finance-label">Monthly Limit</span><span>${formatMoneyKES(item.monthly_limit)}</span></div>
      <div class="finance-row"><span class="finance-label">Current Spend</span><span>${formatMoneyKES(item.current_spending)}</span></div>
      <div class="finance-row"><span class="finance-label">Remaining</span><span>${formatMoneyKES(item.remaining_balance)}</span></div>
      <div class="progress-track"><div class="progress-fill" style="width:${Math.min(100, item.progress_pct)}%"></div></div>
      <div class="progress-label"><span>${item.progress_pct}% used</span><span>${item.is_over_limit ? 'Over limit' : item.is_warning ? 'Warning' : 'Healthy'}</span></div>
    </div>
  `).join('');
}

function renderSavingsGoals(rows = []) {
  financeState.goals = rows.slice();
  const grid = document.getElementById('savings-goals-grid');
  if (!grid) return;
  if (!rows.length) {
    grid.innerHTML = '<div class="table-empty">No savings goals yet.</div>';
    return;
  }

  grid.innerHTML = rows.map((item) => `
    <div class="goal-card">
      <div class="budget-card-head">
        <div class="card-title">${escapeHtml(item.name)}</div>
        <div class="action-cell">
          <button class="btn-outline btn-mini" type="button" data-action="edit-goal" data-id="${item.id}">Edit</button>
          <button class="btn-outline btn-mini danger" type="button" data-action="delete-goal" data-id="${item.id}">Delete</button>
        </div>
      </div>
      <div class="finance-row"><span class="finance-label">Target</span><span>${formatMoneyKES(item.target_amount)}</span></div>
      <div class="finance-row"><span class="finance-label">Current</span><span>${formatMoneyKES(item.current_savings)}</span></div>
      <div class="finance-row"><span class="finance-label">Deadline</span><span>${escapeHtml(item.deadline || 'No deadline')}</span></div>
      <div class="progress-track"><div class="progress-fill" style="width:${item.progress_pct}%"></div></div>
      <div class="progress-label"><span>${item.progress_pct}% complete</span><span>Suggest ${formatMoneyKES(item.monthly_target_suggestion)}/mo</span></div>
    </div>
  `).join('');
}

function renderApplicationPlanner(rows = []) {
  financeState.applicationCosts = rows.slice();
  const body = document.getElementById('application-table-body');
  const summary = document.getElementById('application-summary');
  if (!body || !summary) return;

  let estimatedTotal = 0;
  let actualTotal = 0;
  rows.forEach((row) => {
    estimatedTotal += Number(row.estimated_cost || 0);
    actualTotal += Number(row.actual_cost || 0);
  });

  summary.innerHTML = `
    <div class="finance-row"><span class="finance-label">Total Estimated</span><span>${formatMoneyKES(estimatedTotal)}</span></div>
    <div class="finance-row"><span class="finance-label">Total Actual</span><span>${formatMoneyKES(actualTotal)}</span></div>
    <div class="finance-row"><span class="finance-label">Outstanding</span><span>${formatMoneyKES(Math.max(0, estimatedTotal - actualTotal))}</span></div>
  `;

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" class="table-empty">No application costs tracked yet.</td></tr>';
    return;
  }

  body.innerHTML = rows.map((row) => `
    <tr>
      <td>${escapeHtml(row.item_label || row.item_type || '')}</td>
      <td>${formatMoneyKES(row.estimated_cost || 0)}</td>
      <td>${row.actual_cost !== null ? formatMoneyKES(row.actual_cost) : '—'}</td>
      <td><span class="schol-status">${escapeHtml((row.status || '').replace('_', ' '))}</span></td>
      <td>${escapeHtml(row.deadline || '—')}</td>
      <td>${escapeHtml(row.notes || '—')}</td>
      <td class="action-cell">
        <button class="btn-outline btn-mini" type="button" data-action="edit-application" data-id="${row.id}">Edit</button>
        <button class="btn-outline btn-mini danger" type="button" data-action="delete-application" data-id="${row.id}">Delete</button>
      </td>
    </tr>
  `).join('');
}

function renderProjectBudgets(rows = []) {
  financeState.projectBudgets = rows.slice();
  const grid = document.getElementById('project-budget-grid');
  if (!grid) return;
  if (!rows.length) {
    grid.innerHTML = '<div class="table-empty">No project budgets created.</div>';
    return;
  }
  grid.innerHTML = rows.map((row) => `
    <div class="budget-card">
      <div class="budget-card-head">
        <div class="card-title">${escapeHtml(row.project_name)}</div>
        <div class="action-cell">
          <button class="btn-outline btn-mini" type="button" data-action="edit-project-budget" data-id="${row.id}">Edit</button>
          <button class="btn-outline btn-mini danger" type="button" data-action="delete-project-budget" data-id="${row.id}">Delete</button>
        </div>
      </div>
      <div class="finance-row"><span class="finance-label">Budget</span><span>${formatMoneyKES(row.budget_amount)}</span></div>
      <div class="finance-row"><span class="finance-label">Spent</span><span>${formatMoneyKES(row.spent_amount)}</span></div>
      <div class="finance-row"><span class="finance-label">Remaining</span><span>${formatMoneyKES(row.remaining_funds)}</span></div>
      <div class="finance-row"><span class="finance-label">ROI</span><span>${row.roi_actual_pct ?? 0}% / ${row.roi_target_pct ?? 0}%</span></div>
    </div>
  `).join('');
}

function renderRecurringForecast(rows = []) {
  financeState.recurringForecast = rows.slice();
  const list = document.getElementById('recurring-forecast-list');
  if (!list) return;
  if (!rows.length) {
    list.innerHTML = '<div class="table-empty">No recurring forecast items.</div>';
    return;
  }
  list.innerHTML = rows.slice(0, 20).map((row) => `
    <div class="compact-list-item">
      <span class="compact-date">${escapeHtml(row.due_date)}</span>
      <span class="compact-copy">${escapeHtml(row.template_name)} · ${formatMoneyKES(row.amount)}</span>
    </div>
  `).join('');
}

function renderFinanceAlerts(rows = []) {
  financeState.alerts = rows.slice();
  const list = document.getElementById('budget-alerts-list');
  if (!list) return;
  if (!rows.length) {
    list.innerHTML = '<div class="table-empty">No active alerts.</div>';
    return;
  }
  list.innerHTML = rows.slice(0, 20).map((row) => `
    <div class="insight-item ${row.is_read ? 'alert-read' : ''}">
      <span class="tag">${escapeHtml(row.severity)}</span>
      <span>${escapeHtml(row.message)}</span>
      ${row.is_read ? '' : `<button class="btn-outline btn-mini" type="button" data-action="read-alert" data-id="${row.id}">Read</button>`}
    </div>
  `).join('');
}

function renderFinanceInsights(rows = []) {
  financeState.insights = rows.slice();
  const list = document.getElementById('finance-insights-list');
  if (!list) return;
  if (!rows.length) {
    list.innerHTML = '<div class="table-empty">No insights available yet.</div>';
    return;
  }
  list.innerHTML = rows.map((row) => `
    <div class="insight-item"><span class="tag">${escapeHtml(row.tag || 'Insight')}</span><span>${escapeHtml(row.message || '')}</span></div>
  `).join('');
}

function renderFinanceHealthSnapshot(summary = {}) {
  const box = document.getElementById('finance-health-snapshot');
  if (!box) return;
  box.innerHTML = `
    <div class="finance-row"><span class="finance-label">Cash Flow</span><span>${formatMoneyKES(summary.cash_flow || 0)}</span></div>
    <div class="finance-row"><span class="finance-label">Budget Remaining</span><span>${formatMoneyKES(summary.budget_remaining || 0)}</span></div>
    <div class="finance-row"><span class="finance-label">Total Savings</span><span>${formatMoneyKES(summary.total_savings || 0)}</span></div>
    <div class="finance-row"><span class="finance-label">Budget Warnings</span><span>${summary.budget_warning_count || 0}</span></div>
    <div class="finance-row"><span class="finance-label">Budget Overruns</span><span>${summary.budget_overrun_count || 0}</span></div>
  `;
}

function renderFinanceCategories(rows = []) {
  financeState.categories = rows.slice();
  const list = document.getElementById('finance-categories-list');
  if (!list) return;
  if (!rows.length) {
    list.innerHTML = '<div class="table-empty">No categories created yet.</div>';
    return;
  }
  list.innerHTML = rows.map((row) => `
    <div class="finance-category-item">
      <div class="category-main">
        <span class="category-dot" style="background:${escapeHtml(row.color || '#8B5A2B')}"></span>
        <div>
          <div class="category-name">${escapeHtml(row.name || '')}</div>
          <div class="category-meta">${escapeHtml((row.kind || 'other').replace('_', ' '))}${row.is_active ? '' : ' · inactive'}</div>
        </div>
      </div>
      <div class="action-cell">
        <button class="btn-outline btn-mini" type="button" data-action="edit-category" data-id="${row.id}">Edit</button>
        <button class="btn-outline btn-mini danger" type="button" data-action="delete-category" data-id="${row.id}">Delete</button>
      </div>
    </div>
  `).join('');
}

function getChartDatasetColors(len) {
  const palette = ['#E2B56D', '#8B5A2B', '#3B1E12', '#6B3A1F', '#2f9c57', '#3b5e95', '#bf4a4a'];
  return Array.from({ length: len }).map((_, idx) => palette[idx % palette.length]);
}

function upsertChart(chartId, config) {
  const canvas = document.getElementById(chartId);
  if (!canvas || typeof Chart === 'undefined') return;
  if (financeState.chartInstances[chartId]) {
    financeState.chartInstances[chartId].destroy();
  }
  const ctx = canvas.getContext('2d');
  financeState.chartInstances[chartId] = new Chart(ctx, config);
}

function renderFinanceCharts() {
  if (!isFinancePage()) return;
  const charts = financeState.charts || {};
  if (!charts.monthly_income_vs_expenses) return;

  const labelsA = charts.monthly_income_vs_expenses.labels || [];
  upsertChart('finance-income-expense-chart', {
    type: 'bar',
    data: {
      labels: labelsA,
      datasets: [
        { label: 'Income', data: charts.monthly_income_vs_expenses.income || [], backgroundColor: '#2f9c57', borderRadius: 8 },
        { label: 'Expenses', data: charts.monthly_income_vs_expenses.expenses || [], backgroundColor: '#bf4a4a', borderRadius: 8 },
      ],
    },
    options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } },
  });

  const catRows = charts.expense_category_distribution || [];
  upsertChart('finance-category-chart', {
    type: 'doughnut',
    data: {
      labels: catRows.map((r) => r.label),
      datasets: [{ data: catRows.map((r) => r.value), backgroundColor: catRows.map((r) => r.color || '#8B5A2B') }],
    },
    options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } },
  });

  upsertChart('finance-savings-growth-chart', {
    type: 'line',
    data: {
      labels: charts.savings_growth?.labels || [],
      datasets: [{ label: 'Savings', data: charts.savings_growth?.values || [], borderColor: '#E2B56D', backgroundColor: '#E2B56D33', tension: 0.35, fill: true }],
    },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } } },
  });

  const budgetRows = charts.budget_utilization || [];
  upsertChart('finance-budget-utilization-chart', {
    type: 'bar',
    data: {
      labels: budgetRows.map((r) => r.label),
      datasets: [{ label: 'Utilization %', data: budgetRows.map((r) => r.value), backgroundColor: budgetRows.map((r) => r.color || '#8B5A2B') }],
    },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 100 } } },
  });

  const appRows = charts.application_cost_breakdown || [];
  upsertChart('finance-application-breakdown-chart', {
    type: 'bar',
    data: {
      labels: appRows.map((r) => r.label),
      datasets: [
        { label: 'Estimated', data: appRows.map((r) => r.estimated), backgroundColor: '#8B5A2B' },
        { label: 'Actual', data: appRows.map((r) => r.actual), backgroundColor: '#E2B56D' },
      ],
    },
    options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } },
  });

  const roiRows = charts.project_roi || [];
  upsertChart('finance-project-roi-chart', {
    type: 'bar',
    data: {
      labels: roiRows.map((r) => r.label),
      datasets: [
        { label: 'ROI Target %', data: roiRows.map((r) => r.target), backgroundColor: '#3B1E12' },
        { label: 'ROI Actual %', data: roiRows.map((r) => r.actual), backgroundColor: '#2f9c57' },
      ],
    },
    options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } },
  });
}

function populateFinanceSelects() {
  const categorySelectIds = ['ledger-category-filter', 'transaction-category', 'budget-category', 'recurring-category'];
  categorySelectIds.forEach((id) => {
    const select = document.getElementById(id);
    if (!select) return;
    const current = select.value;
    const hasAnyOption = id === 'ledger-category-filter' ? '<option value=\"\">All categories</option>' : '<option value=\"\">Select category</option>';
    select.innerHTML = hasAnyOption + financeState.categories.map((cat) => `<option value=\"${cat.id}\">${escapeHtml(cat.name)}</option>`).join('');
    select.value = current || select.value;
  });

  const goalSelect = document.getElementById('transaction-savings-goal');
  if (goalSelect) {
    const current = goalSelect.value;
    goalSelect.innerHTML = '<option value=\"\">None</option>' + financeState.goals.map((goal) => `<option value=\"${goal.id}\">${escapeHtml(goal.name)}</option>`).join('');
    goalSelect.value = current || '';
  }

  const appSelect = document.getElementById('transaction-application-cost');
  if (appSelect) {
    const current = appSelect.value;
    appSelect.innerHTML = '<option value=\"\">None</option>' + financeState.applicationCosts.map((item) => `<option value=\"${item.id}\">${escapeHtml(item.item_label || item.item_type)}</option>`).join('');
    appSelect.value = current || '';
  }

  const projectSelect = document.getElementById('transaction-project-budget');
  if (projectSelect) {
    const current = projectSelect.value;
    projectSelect.innerHTML = '<option value=\"\">None</option>' + financeState.projectBudgets.map((item) => `<option value=\"${item.id}\">${escapeHtml(item.project_name)}</option>`).join('');
    projectSelect.value = current || '';
  }

  updateLedgerFilterUI();
}

async function loadFinanceBootstrap() {
  if (!isFinancePage() || !isAuthenticated()) return;
  try {
    const payload = await financeApiGet('/api/finance/bootstrap/', financeState.filters);
    financeState.charts = payload.charts || {};
    renderFinanceMetrics(payload.metrics || []);
    renderLedgerTable(payload.ledger?.rows || []);
    renderLedgerPagination(payload.ledger?.pagination || {});
    renderBudgetCards(payload.budgets || []);
    renderSavingsGoals(payload.savings_goals || []);
    renderApplicationPlanner(payload.application_costs || []);
    renderProjectBudgets(payload.project_budgets || []);
    renderRecurringForecast(payload.recurring_forecast || []);
    renderFinanceAlerts(payload.alerts || []);
    renderFinanceInsights(payload.insights || []);
    renderFinanceHealthSnapshot(payload.summary || {});

    financeState.goals = payload.savings_goals || [];
    financeState.applicationCosts = payload.application_costs || [];
    financeState.projectBudgets = payload.project_budgets || [];

    const categoryData = await financeApiGet('/api/finance/categories/');
    renderFinanceCategories(categoryData.rows || []);
    populateFinanceSelects();
    renderFinanceCharts();
  } catch (err) {
    showToast(err.message || 'Failed to load finance command center');
  }
}

async function loadFinanceLedger() {
  if (!isFinancePage() || !isAuthenticated()) return;
  try {
    const data = await financeApiGet('/api/finance/transactions/', financeState.filters);
    renderLedgerTable(data.rows || []);
    renderLedgerPagination(data.pagination || {});
  } catch (err) {
    showToast(err.message || 'Unable to load ledger data');
  }
}

function openModal(overlayId) {
  const overlay = document.getElementById(overlayId);
  if (overlay) overlay.classList.remove('hidden');
}

function closeModal(overlayId) {
  const overlay = document.getElementById(overlayId);
  if (overlay) overlay.classList.add('hidden');
}

function closeAllModals() {
  document.querySelectorAll('.modal-overlay').forEach((el) => el.classList.add('hidden'));
}

function setTransactionFormValues(row = null) {
  const isEdit = Boolean(row);
  const map = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val ?? '';
  };
  map('transaction-id', row?.id || '');
  map('transaction-date', row?.tx_date || new Date().toISOString().slice(0, 10));
  map('transaction-description', row?.description || '');
  map('transaction-category', row?.category?.id || '');
  map('transaction-account', row?.account || 'bank');
  map('transaction-type', row?.tx_type || 'expense');
  map('transaction-amount', row?.amount || '');
  map('transaction-tags', (row?.tags || []).join(', '));
  map('transaction-savings-goal', row?.savings_goal_id || '');
  map('transaction-application-cost', row?.application_cost_id || '');
  map('transaction-project-budget', row?.project_budget_id || '');
  map('transaction-notes', row?.notes || '');

  const title = document.getElementById('transaction-modal-title');
  if (title) title.textContent = isEdit ? 'Edit Transaction' : 'Add Transaction';
}

async function submitTransactionForm(event) {
  event.preventDefault();
  const transactionId = document.getElementById('transaction-id')?.value;
  const payload = {
    tx_date: document.getElementById('transaction-date')?.value,
    description: document.getElementById('transaction-description')?.value,
    category_id: Number(document.getElementById('transaction-category')?.value || 0),
    account: document.getElementById('transaction-account')?.value,
    tx_type: document.getElementById('transaction-type')?.value,
    amount: document.getElementById('transaction-amount')?.value,
    tags: document.getElementById('transaction-tags')?.value,
    savings_goal_id: document.getElementById('transaction-savings-goal')?.value || null,
    application_cost_id: document.getElementById('transaction-application-cost')?.value || null,
    project_budget_id: document.getElementById('transaction-project-budget')?.value || null,
    notes: document.getElementById('transaction-notes')?.value,
  };
  try {
    if (transactionId) {
      await financeApiPost(`/api/finance/transactions/${transactionId}/update/`, payload);
      showToast('Transaction updated');
    } else {
      await financeApiPost('/api/finance/transactions/create/', payload);
      showToast('Transaction created');
    }
    closeModal('transaction-modal-overlay');
    await loadFinanceBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save transaction');
  }
}

function fillSimpleForm(prefix, row, fieldMap) {
  Object.entries(fieldMap).forEach(([field, source]) => {
    const el = document.getElementById(`${prefix}-${field}`);
    if (!el) return;
    el.value = row?.[source] ?? '';
  });
}

function openBudgetModal(row = null) {
  fillSimpleForm('budget', row, {
    id: 'id',
    category: 'category.id',
  });
  document.getElementById('budget-id').value = row?.id || '';
  document.getElementById('budget-category').value = row?.category?.id || '';
  document.getElementById('budget-period-start').value = row?.period_start || new Date().toISOString().slice(0, 10);
  document.getElementById('budget-monthly-limit').value = row?.monthly_limit || '';
  document.getElementById('budget-threshold').value = row?.warning_threshold_pct || 90;
  document.getElementById('budget-active').value = row?.is_active ? '1' : '0';
  document.getElementById('budget-modal-title').textContent = row ? 'Edit Budget' : 'Add Budget';
  openModal('budget-modal-overlay');
}

async function submitBudgetForm(event) {
  event.preventDefault();
  const id = document.getElementById('budget-id').value;
  const payload = {
    category_id: Number(document.getElementById('budget-category').value || 0),
    period_start: document.getElementById('budget-period-start').value,
    monthly_limit: document.getElementById('budget-monthly-limit').value,
    warning_threshold_pct: document.getElementById('budget-threshold').value,
    is_active: document.getElementById('budget-active').value === '1',
  };
  try {
    if (id) await financeApiPost(`/api/finance/budgets/${id}/update/`, payload);
    else await financeApiPost('/api/finance/budgets/create/', payload);
    closeModal('budget-modal-overlay');
    showToast(`Budget ${id ? 'updated' : 'created'}`);
    await loadFinanceBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save budget');
  }
}

function openGoalModal(row = null) {
  document.getElementById('goal-id').value = row?.id || '';
  document.getElementById('goal-name').value = row?.name || '';
  document.getElementById('goal-target-amount').value = row?.target_amount || '';
  document.getElementById('goal-starting-amount').value = row?.starting_amount || row?.current_savings || '';
  document.getElementById('goal-deadline').value = row?.deadline || '';
  document.getElementById('goal-status').value = row?.status || 'active';
  document.getElementById('goal-modal-title').textContent = row ? 'Edit Savings Goal' : 'Add Savings Goal';
  openModal('goal-modal-overlay');
}

async function submitGoalForm(event) {
  event.preventDefault();
  const id = document.getElementById('goal-id').value;
  const payload = {
    name: document.getElementById('goal-name').value,
    target_amount: document.getElementById('goal-target-amount').value,
    starting_amount: document.getElementById('goal-starting-amount').value,
    deadline: document.getElementById('goal-deadline').value || null,
    status: document.getElementById('goal-status').value,
  };
  try {
    if (id) await financeApiPost(`/api/finance/savings-goals/${id}/update/`, payload);
    else await financeApiPost('/api/finance/savings-goals/create/', payload);
    closeModal('goal-modal-overlay');
    showToast(`Goal ${id ? 'updated' : 'created'}`);
    await loadFinanceBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save goal');
  }
}

function openApplicationModal(row = null) {
  document.getElementById('application-id').value = row?.id || '';
  document.getElementById('application-item-type').value = row?.item_type || 'other';
  document.getElementById('application-estimated').value = row?.estimated_cost || '';
  document.getElementById('application-actual').value = row?.actual_cost ?? '';
  document.getElementById('application-status').value = row?.status || 'planned';
  document.getElementById('application-deadline').value = row?.deadline || '';
  document.getElementById('application-notes').value = row?.notes || '';
  document.getElementById('application-modal-title').textContent = row ? 'Edit Application Cost' : 'Add Application Cost';
  openModal('application-modal-overlay');
}

async function submitApplicationForm(event) {
  event.preventDefault();
  const id = document.getElementById('application-id').value;
  const payload = {
    item_type: document.getElementById('application-item-type').value,
    estimated_cost: document.getElementById('application-estimated').value,
    actual_cost: document.getElementById('application-actual').value || null,
    status: document.getElementById('application-status').value,
    deadline: document.getElementById('application-deadline').value || null,
    notes: document.getElementById('application-notes').value,
  };
  try {
    if (id) await financeApiPost(`/api/finance/application-costs/${id}/update/`, payload);
    else await financeApiPost('/api/finance/application-costs/create/', payload);
    closeModal('application-modal-overlay');
    showToast(`Application item ${id ? 'updated' : 'created'}`);
    await loadFinanceBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save application item');
  }
}

function openProjectBudgetModal(row = null) {
  document.getElementById('project-budget-id').value = row?.id || '';
  document.getElementById('project-budget-name').value = row?.project_name || '';
  document.getElementById('project-budget-amount').value = row?.budget_amount || '';
  document.getElementById('project-budget-spent-adjustment').value = row?.manual_spent_adjustment || 0;
  document.getElementById('project-budget-roi-target').value = row?.roi_target_pct ?? '';
  document.getElementById('project-budget-roi-actual').value = row?.roi_actual_pct ?? '';
  document.getElementById('project-budget-status').value = row?.status || 'active';
  document.getElementById('project-budget-modal-title').textContent = row ? 'Edit Project Budget' : 'Add Project Budget';
  openModal('project-budget-modal-overlay');
}

async function submitProjectBudgetForm(event) {
  event.preventDefault();
  const id = document.getElementById('project-budget-id').value;
  const payload = {
    project_name: document.getElementById('project-budget-name').value,
    budget_amount: document.getElementById('project-budget-amount').value,
    manual_spent_adjustment: document.getElementById('project-budget-spent-adjustment').value,
    roi_target_pct: document.getElementById('project-budget-roi-target').value || null,
    roi_actual_pct: document.getElementById('project-budget-roi-actual').value || null,
    status: document.getElementById('project-budget-status').value,
  };
  try {
    if (id) await financeApiPost(`/api/finance/project-budgets/${id}/update/`, payload);
    else await financeApiPost('/api/finance/project-budgets/create/', payload);
    closeModal('project-budget-modal-overlay');
    showToast(`Project budget ${id ? 'updated' : 'created'}`);
    await loadFinanceBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save project budget');
  }
}

function openRecurringModal(row = null) {
  document.getElementById('recurring-id').value = row?.id || '';
  document.getElementById('recurring-name').value = row?.name || '';
  document.getElementById('recurring-category').value = row?.category_id || '';
  document.getElementById('recurring-account').value = row?.account || 'bank';
  document.getElementById('recurring-amount').value = row?.amount || '';
  document.getElementById('recurring-cadence').value = row?.cadence || 'monthly';
  document.getElementById('recurring-next-due').value = row?.next_due_date || '';
  document.getElementById('recurring-end-date').value = row?.end_date || '';
  document.getElementById('recurring-active').value = row?.is_active ? '1' : '0';
  document.getElementById('recurring-modal-title').textContent = row ? 'Edit Recurring Template' : 'Add Recurring Template';
  openModal('recurring-modal-overlay');
}

async function submitRecurringForm(event) {
  event.preventDefault();
  const id = document.getElementById('recurring-id').value;
  const payload = {
    name: document.getElementById('recurring-name').value,
    category_id: Number(document.getElementById('recurring-category').value || 0),
    account: document.getElementById('recurring-account').value,
    amount: document.getElementById('recurring-amount').value,
    cadence: document.getElementById('recurring-cadence').value,
    next_due_date: document.getElementById('recurring-next-due').value,
    end_date: document.getElementById('recurring-end-date').value || null,
    is_active: document.getElementById('recurring-active').value === '1',
  };
  try {
    if (id) await financeApiPost(`/api/finance/recurring/${id}/update/`, payload);
    else await financeApiPost('/api/finance/recurring/create/', payload);
    closeModal('recurring-modal-overlay');
    showToast(`Recurring template ${id ? 'updated' : 'created'}`);
    await loadFinanceBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save recurring template');
  }
}

function openCategoryModal(row = null) {
  document.getElementById('category-id').value = row?.id || '';
  document.getElementById('category-name').value = row?.name || '';
  document.getElementById('category-slug').value = row?.slug || '';
  document.getElementById('category-kind').value = row?.kind || 'expense';
  document.getElementById('category-color').value = row?.color || '#8B5A2B';
  document.getElementById('category-icon').value = row?.icon || 'fa-wallet';
  document.getElementById('category-sort-order').value = row?.sort_order ?? 0;
  document.getElementById('category-active').value = row?.is_active === false ? '0' : '1';
  document.getElementById('category-modal-title').textContent = row ? 'Edit Category' : 'Add Category';
  openModal('category-modal-overlay');
}

async function submitCategoryForm(event) {
  event.preventDefault();
  const id = document.getElementById('category-id').value;
  const payload = {
    name: document.getElementById('category-name').value,
    slug: document.getElementById('category-slug').value,
    kind: document.getElementById('category-kind').value,
    color: document.getElementById('category-color').value,
    icon: document.getElementById('category-icon').value,
    sort_order: document.getElementById('category-sort-order').value,
    is_active: document.getElementById('category-active').value === '1',
  };
  try {
    if (id) await financeApiPost(`/api/finance/categories/${id}/update/`, payload);
    else await financeApiPost('/api/finance/categories/create/', payload);
    closeModal('category-modal-overlay');
    showToast(`Category ${id ? 'updated' : 'created'}`);
    await loadFinanceBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save category');
  }
}

async function refreshForecast(days = 60) {
  if (!isFinancePage()) return;
  try {
    const data = await financeApiGet('/api/finance/forecast/', { days });
    renderRecurringForecast(data.rows || []);
  } catch (err) {
    showToast(err.message || 'Unable to refresh forecast');
  }
}

function attachFinanceActionDelegates() {
  const page = document.getElementById('page-finance');
  if (!page) return;
  page.addEventListener('click', async (event) => {
    const btn = event.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const id = Number(btn.dataset.id || 0);
    try {
      if (action === 'edit-transaction') {
        const row = financeState.ledger.find((item) => item.id === id);
        setTransactionFormValues(row);
        openModal('transaction-modal-overlay');
      } else if (action === 'delete-transaction') {
        await financeApiPost(`/api/finance/transactions/${id}/delete/`, {});
        showToast('Transaction deleted');
        await loadFinanceBootstrap();
      } else if (action === 'edit-budget') {
        const row = financeState.budgets.find((item) => item.id === id);
        openBudgetModal(row);
      } else if (action === 'delete-budget') {
        await financeApiPost(`/api/finance/budgets/${id}/delete/`, {});
        showToast('Budget deleted');
        await loadFinanceBootstrap();
      } else if (action === 'edit-goal') {
        const row = financeState.goals.find((item) => item.id === id);
        openGoalModal(row);
      } else if (action === 'delete-goal') {
        await financeApiPost(`/api/finance/savings-goals/${id}/delete/`, {});
        showToast('Goal deleted');
        await loadFinanceBootstrap();
      } else if (action === 'edit-application') {
        const row = financeState.applicationCosts.find((item) => item.id === id);
        openApplicationModal(row);
      } else if (action === 'delete-application') {
        await financeApiPost(`/api/finance/application-costs/${id}/delete/`, {});
        showToast('Application item deleted');
        await loadFinanceBootstrap();
      } else if (action === 'edit-project-budget') {
        const row = financeState.projectBudgets.find((item) => item.id === id);
        openProjectBudgetModal(row);
      } else if (action === 'delete-project-budget') {
        await financeApiPost(`/api/finance/project-budgets/${id}/delete/`, {});
        showToast('Project budget deleted');
        await loadFinanceBootstrap();
      } else if (action === 'edit-category') {
        const row = financeState.categories.find((item) => item.id === id);
        openCategoryModal(row || null);
      } else if (action === 'delete-category') {
        if (!window.confirm('Delete this category? This is blocked if it is already referenced.')) return;
        await financeApiPost(`/api/finance/categories/${id}/delete/`, {});
        showToast('Category deleted');
        await loadFinanceBootstrap();
      } else if (action === 'read-alert') {
        await financeApiPost(`/api/finance/alerts/${id}/mark-read/`, {});
        await loadFinanceBootstrap();
      }
    } catch (err) {
      showToast(err.message || 'Action failed');
    }
  });
}

function setupFinancePage() {
  if (!isFinancePage()) return;
  applyTheme(getCurrentTheme());
  if (financeState.isSetup) {
    if ((window.location.hash || '').toLowerCase() === '#finance-analytics') {
      switchTab('fin', 'analytics');
    }
    loadFinanceBootstrap();
    return;
  }
  financeState.isSetup = true;

  const bind = (id, eventName, handler) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener(eventName, handler);
  };

  bind('theme-toggle-btn', 'click', toggleTheme);
  bind('quick-add-transaction-btn', 'click', () => {
    setTransactionFormValues(null);
    openModal('transaction-modal-overlay');
  });
  bind('ledger-apply-filters-btn', 'click', () => {
    readLedgerFiltersFromUI();
    financeState.filters.page = 1;
    loadFinanceLedger();
  });
  bind('ledger-export-csv-btn', 'click', () => {
    readLedgerFiltersFromUI();
    const params = new URLSearchParams(financeState.filters);
    window.location.href = `/api/finance/transactions/export.csv?${params.toString()}`;
  });
  bind('add-budget-btn', 'click', () => openBudgetModal(null));
  bind('add-goal-btn', 'click', () => openGoalModal(null));
  bind('add-application-cost-btn', 'click', () => openApplicationModal(null));
  bind('add-project-budget-btn', 'click', () => openProjectBudgetModal(null));
  bind('quick-add-recurring-btn', 'click', () => openRecurringModal(null));
  bind('quick-add-category-btn', 'click', () => openCategoryModal(null));
  bind('manage-categories-btn', 'click', () => openCategoryModal(null));
  bind('refresh-forecast-btn', 'click', () => refreshForecast(60));
  bind('mark-all-alerts-read-btn', 'click', async () => {
    try {
      await financeApiPost('/api/finance/alerts/mark-all-read/', {});
      await loadFinanceBootstrap();
    } catch (err) {
      showToast(err.message || 'Failed to mark alerts');
    }
  });

  bind('transaction-form', 'submit', submitTransactionForm);
  bind('budget-form', 'submit', submitBudgetForm);
  bind('goal-form', 'submit', submitGoalForm);
  bind('application-form', 'submit', submitApplicationForm);
  bind('project-budget-form', 'submit', submitProjectBudgetForm);
  bind('recurring-form', 'submit', submitRecurringForm);
  bind('category-form', 'submit', submitCategoryForm);

  document.querySelectorAll('[data-close-modal]').forEach((el) => {
    el.addEventListener('click', () => closeModal(el.dataset.closeModal));
  });
  document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) overlay.classList.add('hidden');
    });
  });

  document.addEventListener('keydown', (event) => {
    if (!isFinancePage()) return;
    if (event.key === 'Escape') {
      closeAllModals();
      return;
    }
    const isTyping = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
    if (isTyping) return;
    if (event.key.toLowerCase() === 'n') {
      setTransactionFormValues(null);
      openModal('transaction-modal-overlay');
    } else if (event.key === '/') {
      event.preventDefault();
      document.getElementById('ledger-search')?.focus();
    } else if (event.key.toLowerCase() === 'e') {
      document.getElementById('ledger-export-csv-btn')?.click();
    }
  });

  attachFinanceActionDelegates();
  if ((window.location.hash || '').toLowerCase() === '#finance-analytics') {
    switchTab('fin', 'analytics');
  }
  loadFinanceBootstrap();
}

function isProjectsPage() {
  return getActivePage() === 'projects';
}

function projectsApiGet(path, query = null) {
  if (query) {
    const params = new URLSearchParams(query);
    return apiRequest(`${path}?${params.toString()}`);
  }
  return apiRequest(path);
}

function projectsApiPost(path, payload) {
  return apiRequest(path, 'POST', payload || {});
}

function upsertProjectChart(chartId, config) {
  const canvas = document.getElementById(chartId);
  if (!canvas || typeof Chart === 'undefined') return;
  if (projectsState.chartInstances[chartId]) {
    projectsState.chartInstances[chartId].destroy();
  }
  const ctx = canvas.getContext('2d');
  projectsState.chartInstances[chartId] = new Chart(ctx, config);
}

function renderProjectsCharts(rows = []) {
  if (!isProjectsPage()) return;
  const statusLabels = ['Idea', 'Pending', 'In Progress', 'Completed'];
  const statusKeys = ['idea', 'pending', 'in_progress', 'completed'];
  const statusCounts = statusKeys.map((key) => rows.filter((row) => row.status === key).length);

  upsertProjectChart('projects-status-chart', {
    type: 'pie',
    data: {
      labels: statusLabels,
      datasets: [
        {
          data: statusCounts,
          backgroundColor: ['#E2B56D', '#8B5A2B', '#6B3A1F', '#2f9c57'],
        },
      ],
    },
    options: {
      maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom' } },
    },
  });

  const topProjects = rows.slice(0, 6);
  upsertProjectChart('projects-activity-chart', {
    type: 'bar',
    data: {
      labels: topProjects.map((row) => row.title),
      datasets: [
        {
          label: 'Progress %',
          data: topProjects.map((row) => Number(row.progress || 0)),
          backgroundColor: '#E2B56D',
          borderRadius: 8,
        },
      ],
    },
    options: {
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: {
          beginAtZero: true,
          max: 100,
        },
      },
    },
  });
}

function renderProjectMilestones(rows = []) {
  const milestones = document.getElementById('project-milestones-list');
  const timeline = document.getElementById('project-timeline-list');
  if (!milestones || !timeline) return;

  if (!rows.length) {
    milestones.innerHTML = '<div class="table-empty">No milestones available.</div>';
    timeline.innerHTML = '<div class="table-empty">No timeline data available.</div>';
    return;
  }

  milestones.innerHTML = rows
    .map((row) => {
      const status = String(row.status || 'idea').replace('_', ' ');
      return `
        <div class="u-inline-80">
          <div class="u-inline-81">${escapeHtml(row.title || 'Untitled')}</div>
          <div class="u-inline-82"><div class="progress-fill" style="width:${Math.min(100, Math.max(0, Number(row.progress || 0)))}%"></div></div>
          <div class="u-inline-36">${escapeHtml(status)}</div>
        </div>
      `;
    })
    .join('');

  timeline.innerHTML = rows
    .map((row) => {
      const start = row.start_date || 'N/A';
      const end = row.end_date || 'N/A';
      const progress = Math.min(100, Math.max(0, Number(row.progress || 0)));
      return `
        <div class="u-inline-25">
          <div class="u-inline-18">
            <span class="u-inline-19">${escapeHtml(row.title || 'Untitled')}</span>
            <span class="u-inline-31">${escapeHtml(start)} → ${escapeHtml(end)}</span>
          </div>
          <div class="progress-track"><div class="progress-fill" style="width:${progress}%"></div></div>
          <div class="progress-label"><span>${progress}% complete</span><span>${escapeHtml(String(row.status || 'idea').replace('_', ' '))}</span></div>
        </div>
      `;
    })
    .join('');
}

function renderProjects(rows = []) {
  projectsState.rows = rows.slice();
  const grid = document.getElementById('projects-grid');
  if (!grid) return;

  if (!rows.length) {
    grid.innerHTML = '<div class="dash-card"><div class="table-empty">No projects have been created yet.</div></div>';
    renderProjectMilestones([]);
    renderProjectsCharts([]);
    return;
  }

  grid.innerHTML = rows
    .map((row) => {
      const progress = Math.min(100, Math.max(0, Number(row.progress || 0)));
      const statusText = String(row.status || 'idea').replace('_', ' ');
      return `
        <div class="item-card">
          <div class="card-status status-${statusText.replace(' ', '')}">${escapeHtml(statusText)}</div>
          <div class="item-title">${escapeHtml(row.title || 'Untitled')}</div>
          <div class="item-meta">${escapeHtml(row.description || 'No description yet.')}</div>
          <div class="finance-row"><span class="finance-label">Start</span><span>${escapeHtml(row.start_date || 'Not set')}</span></div>
          <div class="finance-row"><span class="finance-label">End</span><span>${escapeHtml(row.end_date || 'Not set')}</span></div>
          <div class="progress-track"><div class="progress-fill" style="width:${progress}%"></div></div>
          <div class="progress-label"><span>${progress}% complete</span><span>${escapeHtml(statusText)}</span></div>
          <div class="action-cell">
            <button class="btn-outline btn-mini" type="button" data-action="edit-project" data-id="${row.id}">Edit</button>
            <button class="btn-outline btn-mini danger" type="button" data-action="delete-project" data-id="${row.id}">Delete</button>
          </div>
        </div>
      `;
    })
    .join('');

  renderProjectMilestones(rows);
  renderProjectsCharts(rows);
}

function openProjectModal(row = null) {
  const setValue = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  setValue('project-id', row?.id || '');
  setValue('project-title', row?.title || '');
  setValue('project-description', row?.description || '');
  setValue('project-status', row?.status || 'idea');
  setValue('project-progress', Number(row?.progress || 0));
  setValue('project-start-date', row?.start_date || '');
  setValue('project-end-date', row?.end_date || '');

  const title = document.getElementById('project-modal-title');
  if (title) title.textContent = row ? 'Edit Project' : 'Add Project';
  openModal('project-modal-overlay');
}

async function submitProjectForm(event) {
  event.preventDefault();
  const projectId = document.getElementById('project-id')?.value || '';
  const payload = {
    title: (document.getElementById('project-title')?.value || '').trim(),
    description: (document.getElementById('project-description')?.value || '').trim(),
    status: document.getElementById('project-status')?.value || 'idea',
    progress: document.getElementById('project-progress')?.value || 0,
    start_date: document.getElementById('project-start-date')?.value || null,
    end_date: document.getElementById('project-end-date')?.value || null,
  };

  try {
    if (projectId) {
      await projectsApiPost(`/api/projects/${projectId}/update/`, payload);
      showToast('Project updated');
    } else {
      await projectsApiPost('/api/projects/create/', payload);
      showToast('Project created');
    }
    closeModal('project-modal-overlay');
    await loadProjects();
  } catch (err) {
    showToast(err.message || 'Unable to save project');
  }
}

async function loadProjects() {
  if (!isProjectsPage() || !isAuthenticated()) return;
  try {
    const data = await projectsApiGet('/api/projects/');
    renderProjects(data.rows || []);
  } catch (err) {
    showToast(err.message || 'Unable to load projects');
  }
}

function attachProjectActionDelegates() {
  const page = document.getElementById('page-projects');
  if (!page) return;
  page.addEventListener('click', async (event) => {
    const btn = event.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const id = Number(btn.dataset.id || 0);
    try {
      if (action === 'edit-project') {
        const row = projectsState.rows.find((item) => item.id === id);
        openProjectModal(row || null);
      } else if (action === 'delete-project') {
        if (!window.confirm('Delete this project?')) return;
        await projectsApiPost(`/api/projects/${id}/delete/`, {});
        showToast('Project deleted');
        await loadProjects();
      }
    } catch (err) {
      showToast(err.message || 'Project action failed');
    }
  });
}

function setupProjectsPage() {
  if (!isProjectsPage()) return;
  if (projectsState.isSetup) {
    loadProjects();
    return;
  }
  projectsState.isSetup = true;

  const addBtn = document.getElementById('add-project-btn');
  if (addBtn) {
    addBtn.addEventListener('click', () => openProjectModal(null));
  }

  const form = document.getElementById('project-form');
  if (form) {
    form.addEventListener('submit', submitProjectForm);
  }

  document.querySelectorAll('[data-close-modal]').forEach((el) => {
    el.addEventListener('click', () => closeModal(el.dataset.closeModal));
  });
  document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) overlay.classList.add('hidden');
    });
  });

  attachProjectActionDelegates();
  loadProjects();
}

function isPersonalPage() {
  return getActivePage() === 'personal';
}

function personalApiGet(path, query = null) {
  if (query) {
    const params = new URLSearchParams(query);
    return apiRequest(`${path}?${params.toString()}`);
  }
  return apiRequest(path);
}

function personalApiPost(path, payload) {
  return apiRequest(path, 'POST', payload || {});
}

function ensurePersonalArray(raw) {
  if (Array.isArray(raw)) return raw.map((item) => String(item).trim()).filter(Boolean);
  return [];
}

function getPersonalDraftIndicator() {
  const card = document.querySelector('.personal-progress-card');
  if (!card) return null;
  let indicator = document.getElementById('personal-draft-indicator');
  if (!indicator) {
    indicator = document.createElement('div');
    indicator.id = 'personal-draft-indicator';
    indicator.className = 'personal-draft-indicator';
    card.appendChild(indicator);
  }
  return indicator;
}

function setPersonalDraftIndicator(message, isError = false) {
  const indicator = getPersonalDraftIndicator();
  if (!indicator) return;
  indicator.textContent = message || '';
  indicator.classList.toggle('error', isError);
}

function renderPersonalStepStatus() {
  const steps = document.querySelectorAll('#personal-steps .wizard-step');
  for (let i = 1; i <= 6; i += 1) {
    const stepData = personalState.stepStatus.find((item) => item.step === i) || {};
    const icon = stepData.icon || (i === personalState.currentStep ? '•' : '○');
    const status = stepData.status || 'not_started';
    const stepEl = steps[i - 1];
    const iconEl = document.getElementById(`personal-step-icon-${i}`);
    if (iconEl) iconEl.textContent = icon;
    if (stepEl) {
      stepEl.classList.toggle('active', i === personalState.currentStep);
      stepEl.classList.toggle('completed', status === 'completed' && i !== personalState.currentStep);
      stepEl.classList.toggle('in-progress', status === 'in_progress' && i !== personalState.currentStep);
    }
  }
}

function renderPersonalCompletion() {
  const score = Number(personalState.completionScore || 0);
  const scoreEl = document.getElementById('personal-completion-score');
  const fillEl = document.getElementById('personal-completion-fill');
  const labelEl = document.getElementById('personal-completion-label');
  const subEl = document.getElementById('personal-completion-sub');
  const suggestionsEl = document.getElementById('personal-completion-suggestions');
  const completedSteps = (personalState.stepStatus || []).filter((item) => item.status === 'completed').length;

  if (scoreEl) scoreEl.textContent = `${score}%`;
  if (fillEl) fillEl.style.width = `${Math.min(100, Math.max(0, score))}%`;
  if (labelEl) labelEl.textContent = score >= 100 ? 'Vault profile complete' : `Profile completion: ${score}%`;
  if (subEl) subEl.textContent = `${completedSteps} / 6 steps`;

  if (!suggestionsEl) return;
  const suggestions = ensurePersonalArray(personalState.suggestions).slice(0, 6);
  if (!suggestions.length) {
    suggestionsEl.innerHTML = '<div class="compact-list-item"><span class="compact-copy">All core sections are completed.</span></div>';
    return;
  }
  suggestionsEl.innerHTML = suggestions
    .map((item) => `<div class="compact-list-item"><i class="fas fa-lightbulb"></i><span class="compact-copy">${escapeHtml(item)}</span></div>`)
    .join('');
}

function renderPersonalTagList(containerId, listKey) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const values = ensurePersonalArray(personalState.tags[listKey]);
  if (!values.length) {
    container.innerHTML = '<div class="u-inline-31">No entries yet</div>';
    return;
  }
  container.innerHTML = values
    .map(
      (item) => `
        <span class="personal-tag-chip">
          <span>${escapeHtml(item)}</span>
          <button type="button" aria-label="Remove tag" data-action="remove-personal-tag" data-list="${escapeHtml(listKey)}" data-value="${escapeHtml(item)}">×</button>
        </span>
      `
    )
    .join('');
}

function addPersonalTag(listKey, value) {
  const text = String(value || '').trim();
  if (!text) return;
  const existing = ensurePersonalArray(personalState.tags[listKey]);
  if (existing.includes(text)) return;
  existing.push(text);
  personalState.tags[listKey] = existing;
  if (listKey === 'languages') renderPersonalTagList('vault-language-tags', 'languages');
  if (listKey === 'additionalEmails') renderPersonalTagList('vault-additional-emails', 'additionalEmails');
  if (listKey === 'otherPhones') renderPersonalTagList('vault-other-phones', 'otherPhones');

  const autosaveStep = listKey === 'languages' ? 1 : 2;
  schedulePersonalAutosave(autosaveStep);
}

function removePersonalTag(listKey, value) {
  const text = String(value || '').trim();
  if (!text) return;
  personalState.tags[listKey] = ensurePersonalArray(personalState.tags[listKey]).filter((item) => item !== text);
  if (listKey === 'languages') renderPersonalTagList('vault-language-tags', 'languages');
  if (listKey === 'additionalEmails') renderPersonalTagList('vault-additional-emails', 'additionalEmails');
  if (listKey === 'otherPhones') renderPersonalTagList('vault-other-phones', 'otherPhones');

  const autosaveStep = listKey === 'languages' ? 1 : 2;
  schedulePersonalAutosave(autosaveStep);
}

let personalPhotoObjectUrl = '';

function setPersonalPhotoPreview(source) {
  const card = document.getElementById('personal-photo-preview-card');
  if (!card) return;

  if (personalPhotoObjectUrl) {
    URL.revokeObjectURL(personalPhotoObjectUrl);
    personalPhotoObjectUrl = '';
  }

  if (!source) {
    card.innerHTML = '<div class="u-inline-31">No photo uploaded yet</div>';
    return;
  }

  let imageUrl = '';
  if (typeof source === 'string') {
    imageUrl = source;
  } else {
    personalPhotoObjectUrl = URL.createObjectURL(source);
    imageUrl = personalPhotoObjectUrl;
  }

  const fullName = [personalState.identity.first_name, personalState.identity.last_name].filter(Boolean).join(' ').trim() || 'Profile';
  card.innerHTML = `
    <img src="${escapeHtml(imageUrl)}" alt="Profile preview" class="personal-photo-image">
    <div class="personal-photo-meta">
      <div class="personal-photo-name">${escapeHtml(fullName)}</div>
      <div class="personal-photo-sub">${escapeHtml(personalState.identity.nationality || 'Nationality not set')}</div>
      <div class="personal-photo-sub u-inline-31">Auto-cropped preview for identity card.</div>
    </div>
  `;
}

async function buildSquareProfilePhoto(file) {
  if (!file || !String(file.type || '').startsWith('image/')) return file;
  return new Promise((resolve) => {
    const srcUrl = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const side = Math.min(img.width, img.height);
      const sx = Math.floor((img.width - side) / 2);
      const sy = Math.floor((img.height - side) / 2);
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 640;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        URL.revokeObjectURL(srcUrl);
        resolve(file);
        return;
      }
      ctx.drawImage(img, sx, sy, side, side, 0, 0, 640, 640);
      canvas.toBlob((blob) => {
        URL.revokeObjectURL(srcUrl);
        if (!blob) {
          resolve(file);
          return;
        }
        const safeName = (file.name || 'profile').replace(/\.[a-zA-Z0-9]+$/, '');
        resolve(new File([blob], `${safeName}-cropped.jpg`, { type: 'image/jpeg' }));
      }, 'image/jpeg', 0.92);
    };
    img.onerror = () => {
      URL.revokeObjectURL(srcUrl);
      resolve(file);
    };
    img.src = srcUrl;
  });
}

async function handlePersonalProfilePhotoSelection(file) {
  if (!file) return;
  const extension = (file.name.split('.').pop() || '').toLowerCase();
  if (!['jpg', 'jpeg', 'png'].includes(extension)) {
    showToast('Profile photo must be JPG or PNG');
    return;
  }
  personalState.pendingProfilePhoto = await buildSquareProfilePhoto(file);
  setPersonalPhotoPreview(personalState.pendingProfilePhoto);
  setPersonalDraftIndicator('Profile photo ready. Saving draft...');
  schedulePersonalAutosave(1);
}

function renderPersonalIdentitySection() {
  const identity = personalState.identity || {};
  const set = (id, value) => {
    const field = document.getElementById(id);
    if (field) field.value = value ?? '';
  };
  set('vault-first-name', identity.first_name || '');
  set('vault-last-name', identity.last_name || '');
  set('vault-dob', identity.dob || '');
  set('vault-gender', identity.gender || '');
  set('vault-nationality', identity.nationality || '');

  personalState.tags.languages = ensurePersonalArray(identity.languages);
  renderPersonalTagList('vault-language-tags', 'languages');
  setPersonalPhotoPreview(personalState.pendingProfilePhoto || identity.profile_photo_url || '');
}

function renderPersonalContactSection() {
  const contact = personalState.contact || {};
  const set = (id, value) => {
    const field = document.getElementById(id);
    if (field) field.value = value ?? '';
  };
  set('vault-primary-email', contact.primary_email || '');
  set('vault-secondary-email', contact.secondary_email || '');
  set('vault-primary-phone', contact.primary_phone || '');
  set('vault-secondary-phone', contact.secondary_phone || '');
  set('vault-home-address', contact.home_address || '');
  set('vault-city', contact.city || '');
  set('vault-country', contact.country || '');
  set('vault-postal-code', contact.postal_code || '');

  personalState.tags.additionalEmails = ensurePersonalArray(contact.additional_emails);
  personalState.tags.otherPhones = ensurePersonalArray(contact.other_phone_numbers);
  renderPersonalTagList('vault-additional-emails', 'additionalEmails');
  renderPersonalTagList('vault-other-phones', 'otherPhones');
}

function renderPersonalIdentityDocuments() {
  const docs = personalState.identityDocuments || {};
  const set = (id, value) => {
    const field = document.getElementById(id);
    if (field) field.value = value ?? '';
  };
  set('vault-national-id', docs.national_id || '');
  set('vault-passport-number', docs.passport_number || '');
  set('vault-passport-expiry', docs.passport_expiry || '');
  set('vault-drivers-license', docs.drivers_license || '');
  set('vault-student-id', docs.student_id || '');
}

function renderPersonalIdentityFiles() {
  const body = document.getElementById('vault-identity-files-table');
  if (!body) return;
  const files = personalState.uploadedFiles || [];
  if (!files.length) {
    body.innerHTML = '<tr><td colspan="4" class="table-empty">No identity files uploaded yet</td></tr>';
    return;
  }

  body.innerHTML = files
    .map(
      (row) => `
        <tr>
          <td>${escapeHtml(row.file_type_label || row.file_type || '')}</td>
          <td>
            ${row.file_url ? `<a href="${escapeHtml(row.file_url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(row.file_name || 'File')}</a>` : escapeHtml(row.file_name || 'File')}
            <div class="u-inline-31">${formatBytes(Number(row.file_size || 0))}</div>
          </td>
          <td>${escapeHtml(formatDateDisplay(row.updated_at))}</td>
          <td class="action-cell">
            <button type="button" class="btn-outline btn-mini" data-action="download-identity-file" data-id="${row.id}">Download</button>
            <button type="button" class="btn-outline danger btn-mini" data-action="delete-identity-file" data-id="${row.id}">Delete</button>
          </td>
        </tr>
      `
    )
    .join('');
}

function recomputeLocalExpiryAlerts() {
  const alerts = [];
  const expiry = personalState.identityDocuments?.passport_expiry;
  if (expiry) {
    const target = new Date(expiry);
    if (!Number.isNaN(target.getTime())) {
      const today = new Date();
      const diff = Math.ceil((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      if (diff >= 0 && diff <= 180) {
        alerts.push({
          message: `Passport expires in ${diff} day${diff === 1 ? '' : 's'}.`,
          severity: diff <= 60 ? 'warning' : 'info',
        });
      }
    }
  }
  personalState.expiryAlerts = alerts;
}

function renderPersonalExpiryAlerts() {
  const list = document.getElementById('vault-expiry-alerts');
  if (!list) return;
  const alerts = personalState.expiryAlerts || [];
  if (!alerts.length) {
    list.innerHTML = '<div class="compact-list-item"><span class="compact-copy">No expiry reminders right now.</span></div>';
    return;
  }
  list.innerHTML = alerts
    .map((item) => `
      <div class="compact-list-item ${item.severity === 'warning' ? 'personal-alert-warning' : ''}">
        <i class="fas fa-clock"></i>
        <span class="compact-copy">${escapeHtml(item.message || '')}</span>
      </div>
    `)
    .join('');
}

function getPlatformIcon(platform) {
  const map = {
    google: 'fab fa-google',
    github: 'fab fa-github',
    linkedin: 'fab fa-linkedin',
    twitter_x: 'fab fa-x-twitter',
    instagram: 'fab fa-instagram',
    facebook: 'fab fa-facebook',
    tiktok: 'fab fa-tiktok',
    discord: 'fab fa-discord',
    reddit: 'fab fa-reddit',
    custom: 'fas fa-globe',
  };
  return map[platform] || 'fas fa-globe';
}

function getFilteredDigitalAccounts() {
  const q = String(personalState.filters.accountSearch || '').toLowerCase();
  const platform = personalState.filters.accountPlatform || '';
  return (personalState.digitalAccounts || []).filter((row) => {
    if (platform && row.platform !== platform) return false;
    if (!q) return true;
    const haystack = [row.platform_label, row.custom_platform, row.username, row.email_used, row.profile_link, row.notes]
      .map((item) => String(item || '').toLowerCase())
      .join(' ');
    return haystack.includes(q);
  });
}

function renderDigitalAccountsTable() {
  const body = document.getElementById('vault-digital-accounts-table');
  if (!body) return;
  const rows = getFilteredDigitalAccounts();
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="6" class="table-empty">No account records found</td></tr>';
    return;
  }
  body.innerHTML = rows
    .map((row) => {
      const platformLabel = row.platform === 'custom' && row.custom_platform
        ? row.custom_platform
        : row.platform_label || row.platform || 'Platform';
      return `
        <tr>
          <td><span class="vault-platform"><i class="${getPlatformIcon(row.platform)}"></i> ${escapeHtml(platformLabel)}</span></td>
          <td>${escapeHtml(row.username || '—')}</td>
          <td>${escapeHtml(row.email_used || '—')}</td>
          <td>${row.profile_link ? `<a href="${escapeHtml(row.profile_link)}" target="_blank" rel="noopener noreferrer">Open Link</a>` : '—'}</td>
          <td>${escapeHtml(row.notes || '—')}</td>
          <td class="action-cell">
            <button type="button" class="btn-outline btn-mini" data-action="edit-digital-account" data-id="${row.id}">Edit</button>
            <button type="button" class="btn-outline danger btn-mini" data-action="delete-digital-account" data-id="${row.id}">Delete</button>
          </td>
        </tr>
      `;
    })
    .join('');
}

function renderSocialProfilesSection() {
  const profile = personalState.socialProfiles || {};
  const set = (id, value) => {
    const field = document.getElementById(id);
    if (field) field.value = value ?? '';
  };
  set('vault-linkedin', profile.linkedin || '');
  set('vault-twitter', profile.twitter_x || '');
  set('vault-instagram', profile.instagram || '');
  set('vault-github', profile.github || '');
  set('vault-portfolio', profile.portfolio_website || '');
  set('vault-blog', profile.personal_blog || '');
  set('vault-youtube', profile.youtube_channel || '');
}

function renderSocialPreview() {
  const list = document.getElementById('vault-social-preview');
  if (!list) return;
  const links = [
    { label: 'LinkedIn', value: personalState.socialProfiles.linkedin, icon: 'fab fa-linkedin' },
    { label: 'Twitter / X', value: personalState.socialProfiles.twitter_x, icon: 'fab fa-x-twitter' },
    { label: 'Instagram', value: personalState.socialProfiles.instagram, icon: 'fab fa-instagram' },
    { label: 'GitHub', value: personalState.socialProfiles.github, icon: 'fab fa-github' },
    { label: 'Portfolio', value: personalState.socialProfiles.portfolio_website, icon: 'fas fa-briefcase' },
    { label: 'Blog', value: personalState.socialProfiles.personal_blog, icon: 'fas fa-blog' },
    { label: 'YouTube', value: personalState.socialProfiles.youtube_channel, icon: 'fab fa-youtube' },
  ].filter((row) => row.value);

  if (!links.length) {
    list.innerHTML = '<div class="compact-list-item"><span class="compact-copy">No public profile links added yet.</span></div>';
    return;
  }
  list.innerHTML = links
    .map(
      (row) => `
        <a class="compact-list-item" href="${escapeHtml(row.value)}" target="_blank" rel="noopener noreferrer">
          <i class="${row.icon}"></i>
          <span class="compact-copy">${escapeHtml(row.label)}</span>
        </a>
      `
    )
    .join('');
}

function renderPasswordReferencesTable() {
  const body = document.getElementById('vault-password-references-table');
  if (!body) return;
  const rows = personalState.passwordReferences || [];
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" class="table-empty">No password reference entries yet</td></tr>';
    return;
  }
  body.innerHTML = rows
    .map(
      (row) => `
        <tr>
          <td>${escapeHtml(row.platform || '')}</td>
          <td>${escapeHtml(row.username || '—')}</td>
          <td>${escapeHtml(row.email_used || '—')}</td>
          <td>${escapeHtml(row.password_hint || '—')}</td>
          <td>${row.two_factor_enabled ? 'Yes' : 'No'}</td>
          <td>${escapeHtml(row.password_manager_label || row.password_manager || '—')}</td>
          <td class="action-cell">
            <button type="button" class="btn-outline btn-mini" data-action="edit-password-reference" data-id="${row.id}">Edit</button>
            <button type="button" class="btn-outline danger btn-mini" data-action="delete-password-reference" data-id="${row.id}">Delete</button>
          </td>
        </tr>
      `
    )
    .join('');
}

function renderPersonalVaultPage() {
  renderPersonalCompletion();
  renderPersonalStepStatus();
  renderPersonalIdentitySection();
  renderPersonalContactSection();
  renderPersonalIdentityDocuments();
  renderPersonalIdentityFiles();
  renderPersonalExpiryAlerts();
  renderDigitalAccountsTable();
  renderSocialProfilesSection();
  renderSocialPreview();
  renderPasswordReferencesTable();
}

function recomputeLocalPersonalCompletion() {
  const identity = personalState.identity || {};
  const contact = personalState.contact || {};
  const docs = personalState.identityDocuments || {};
  const fileCount = (personalState.uploadedFiles || []).length;
  const social = personalState.socialProfiles || {};

  const step1 = Boolean(
    identity.first_name || identity.last_name || identity.dob || identity.nationality
    || (ensurePersonalArray(personalState.tags.languages).length > 0)
    || identity.profile_photo_url || personalState.pendingProfilePhoto
  );
  const step2 = Boolean((contact.primary_email && contact.primary_phone && contact.city && contact.country));
  const step3 = Boolean((docs.national_id || docs.passport_number || docs.passport_expiry || docs.drivers_license || docs.student_id) && fileCount > 0);
  const step4 = (personalState.digitalAccounts || []).length > 0;
  const step5 = Boolean(social.linkedin || social.twitter_x || social.instagram || social.github || social.portfolio_website || social.personal_blog || social.youtube_channel);
  const step6 = (personalState.passwordReferences || []).length > 0;

  const checks = [step1, step2, step3, step4, step5, step6];
  const completedCount = checks.filter(Boolean).length;
  personalState.completionScore = Math.round((completedCount / 6) * 100);
  personalState.stepStatus = checks.map((isDone, index) => ({
    step: index + 1,
    status: isDone ? 'completed' : 'not_started',
    icon: isDone ? '✓' : '○',
  }));
  const nextStep = personalState.stepStatus.find((item) => item.status !== 'completed');
  if (nextStep) {
    const row = personalState.stepStatus[nextStep.step - 1];
    row.status = 'in_progress';
    row.icon = '•';
  }
  const suggestions = [];
  if (!step1) suggestions.push('Add your basic identity details and profile photo.');
  if (!step2) suggestions.push('Add a primary contact email and phone number.');
  if (!step3) suggestions.push('Upload identity documents and add passport details.');
  if (!step4) suggestions.push('Add your key digital accounts.');
  if (!step5) suggestions.push('Add public social profile links.');
  if (!step6) suggestions.push('Add password reference entries with 2FA status.');
  personalState.suggestions = suggestions;
}

function getPersonalRecommendedStep() {
  const inProgress = (personalState.stepStatus || []).find((item) => item.status === 'in_progress');
  if (inProgress) return inProgress.step;
  const incomplete = (personalState.stepStatus || []).find((item) => item.status !== 'completed');
  if (incomplete) return incomplete.step;
  return personalState.currentStep || 1;
}

async function loadPersonalVaultBootstrap({ preserveStep = false, silent = false } = {}) {
  if (!isPersonalPage() || !isAuthenticated()) return;
  const previousStep = personalState.currentStep || 1;
  try {
    const payload = await personalApiGet('/api/personal-vault/bootstrap/');
    personalState.identity = payload.identity || {};
    personalState.contact = payload.contact || {};
    personalState.identityDocuments = payload.identity_documents || {};
    personalState.uploadedFiles = payload.uploaded_files || [];
    personalState.digitalAccounts = payload.digital_accounts || [];
    personalState.socialProfiles = payload.social_profiles || {};
    personalState.passwordReferences = payload.password_references || [];
    personalState.completionScore = Number(payload.completion_score || 0);
    personalState.stepStatus = payload.step_status || [];
    personalState.suggestions = payload.suggestions || [];
    personalState.expiryAlerts = payload.expiry_alerts || [];

    personalState.tags.languages = ensurePersonalArray(personalState.identity.languages);
    personalState.tags.additionalEmails = ensurePersonalArray(personalState.contact.additional_emails);
    personalState.tags.otherPhones = ensurePersonalArray(personalState.contact.other_phone_numbers);

    renderPersonalVaultPage();
    const stepToShow = preserveStep ? previousStep : getPersonalRecommendedStep();
    goPersonalStep(stepToShow);
  } catch (err) {
    if (!silent) showToast(err.message || 'Failed to load Personal Identity Vault');
  }
}

function getPersonalStep1Payload() {
  return {
    first_name: (document.getElementById('vault-first-name')?.value || '').trim(),
    last_name: (document.getElementById('vault-last-name')?.value || '').trim(),
    dob: document.getElementById('vault-dob')?.value || '',
    gender: document.getElementById('vault-gender')?.value || '',
    nationality: (document.getElementById('vault-nationality')?.value || '').trim(),
    languages: ensurePersonalArray(personalState.tags.languages),
  };
}

function getPersonalStep2Payload() {
  return {
    primary_email: (document.getElementById('vault-primary-email')?.value || '').trim(),
    secondary_email: (document.getElementById('vault-secondary-email')?.value || '').trim(),
    additional_emails: ensurePersonalArray(personalState.tags.additionalEmails),
    primary_phone: (document.getElementById('vault-primary-phone')?.value || '').trim(),
    secondary_phone: (document.getElementById('vault-secondary-phone')?.value || '').trim(),
    other_phone_numbers: ensurePersonalArray(personalState.tags.otherPhones),
    home_address: (document.getElementById('vault-home-address')?.value || '').trim(),
    city: (document.getElementById('vault-city')?.value || '').trim(),
    country: (document.getElementById('vault-country')?.value || '').trim(),
    postal_code: (document.getElementById('vault-postal-code')?.value || '').trim(),
  };
}

function getPersonalStep3Payload() {
  return {
    national_id: (document.getElementById('vault-national-id')?.value || '').trim(),
    passport_number: (document.getElementById('vault-passport-number')?.value || '').trim(),
    passport_expiry: document.getElementById('vault-passport-expiry')?.value || '',
    drivers_license: (document.getElementById('vault-drivers-license')?.value || '').trim(),
    student_id: (document.getElementById('vault-student-id')?.value || '').trim(),
  };
}

function getPersonalStep5Payload() {
  return {
    linkedin: (document.getElementById('vault-linkedin')?.value || '').trim(),
    twitter_x: (document.getElementById('vault-twitter')?.value || '').trim(),
    instagram: (document.getElementById('vault-instagram')?.value || '').trim(),
    github: (document.getElementById('vault-github')?.value || '').trim(),
    portfolio_website: (document.getElementById('vault-portfolio')?.value || '').trim(),
    personal_blog: (document.getElementById('vault-blog')?.value || '').trim(),
    youtube_channel: (document.getElementById('vault-youtube')?.value || '').trim(),
  };
}

async function savePersonalStep1({ goNext = false, silent = false, refresh = true } = {}) {
  const payload = getPersonalStep1Payload();
  const formData = new FormData();
  Object.entries(payload).forEach(([key, value]) => {
    if (Array.isArray(value)) formData.append(key, value.join(', '));
    else formData.append(key, value ?? '');
  });
  if (personalState.pendingProfilePhoto) {
    formData.append('profile_photo', personalState.pendingProfilePhoto);
  }
  const response = await apiRequestForm('/api/personal-vault/step1/save/', formData);
  if (response?.identity) {
    personalState.identity = response.identity;
  }
  personalState.pendingProfilePhoto = null;
  if (refresh) {
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
  } else {
    recomputeLocalPersonalCompletion();
    renderPersonalCompletion();
    renderPersonalStepStatus();
    renderPersonalIdentitySection();
  }
  if (!silent) showToast('Basic identity information saved');
  if (goNext) goPersonalStep(2);
}

async function savePersonalStep2({ goNext = false, silent = false, refresh = true } = {}) {
  const response = await personalApiPost('/api/personal-vault/step2/save/', getPersonalStep2Payload());
  if (response?.contact) {
    personalState.contact = response.contact;
  }
  if (refresh) {
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
  } else {
    recomputeLocalPersonalCompletion();
    renderPersonalCompletion();
    renderPersonalStepStatus();
    renderPersonalContactSection();
  }
  if (!silent) showToast('Contact information saved');
  if (goNext) goPersonalStep(3);
}

async function savePersonalStep3({ goNext = false, silent = false, refresh = true } = {}) {
  const response = await personalApiPost('/api/personal-vault/step3/save/', getPersonalStep3Payload());
  if (response?.identity_documents) {
    personalState.identityDocuments = response.identity_documents;
  }
  if (refresh) {
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
  } else {
    recomputeLocalExpiryAlerts();
    recomputeLocalPersonalCompletion();
    renderPersonalCompletion();
    renderPersonalStepStatus();
    renderPersonalIdentityDocuments();
    renderPersonalExpiryAlerts();
  }
  if (!silent) showToast('Identity document details saved');
  if (goNext) goPersonalStep(4);
}

async function savePersonalStep5({ goNext = false, silent = false, refresh = true } = {}) {
  const response = await personalApiPost('/api/personal-vault/social-profiles/save/', getPersonalStep5Payload());
  if (response?.social_profiles) {
    personalState.socialProfiles = response.social_profiles;
  }
  if (refresh) {
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
  } else {
    recomputeLocalPersonalCompletion();
    renderPersonalCompletion();
    renderPersonalStepStatus();
    renderSocialProfilesSection();
    renderSocialPreview();
  }
  if (!silent) showToast('Public profile links saved');
  if (goNext) goPersonalStep(6);
}

async function saveCurrentPersonalStep({ goNext = false, silent = false } = {}) {
  const step = personalState.currentStep || 1;
  if (step === 1) await savePersonalStep1({ goNext, silent });
  else if (step === 2) await savePersonalStep2({ goNext, silent });
  else if (step === 3) await savePersonalStep3({ goNext, silent });
  else if (step === 5) await savePersonalStep5({ goNext, silent });
  else if (step === 6) {
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
    if (!silent) showToast('Personal Identity Vault synced');
  } else if (goNext) {
    goPersonalStep(Math.min(6, step + 1));
  }
}

function schedulePersonalAutosave(step) {
  if (!isPersonalPage()) return;
  const key = `step${step}`;
  clearTimeout(personalState.autosaveTimers[key]);
  setPersonalDraftIndicator('Saving draft...');
  personalState.autosaveTimers[key] = setTimeout(async () => {
    try {
      if (step === 1) await savePersonalStep1({ silent: true, refresh: false });
      else if (step === 2) await savePersonalStep2({ silent: true, refresh: false });
      else if (step === 3) await savePersonalStep3({ silent: true, refresh: false });
      else if (step === 5) await savePersonalStep5({ silent: true, refresh: false });
      setPersonalDraftIndicator(`Draft saved at ${new Date().toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit' })}`);
    } catch (err) {
      setPersonalDraftIndicator(err.message || 'Draft save failed', true);
    }
  }, 900);
}

function openDigitalAccountModal(row = null) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('vault-digital-account-id', row?.id || '');
  set('vault-account-platform', row?.platform || 'google');
  set('vault-account-custom-platform', row?.custom_platform || '');
  set('vault-account-username', row?.username || '');
  set('vault-account-email', row?.email_used || '');
  set('vault-account-profile-link', row?.profile_link || '');
  set('vault-account-notes', row?.notes || '');
  const title = document.getElementById('vault-digital-account-modal-title');
  if (title) title.textContent = row ? 'Edit Digital Account' : 'Add Digital Account';
  openModal('vault-digital-account-modal-overlay');
}

async function submitDigitalAccountForm(event) {
  event.preventDefault();
  const id = document.getElementById('vault-digital-account-id')?.value;
  const payload = {
    platform: document.getElementById('vault-account-platform')?.value || 'google',
    custom_platform: (document.getElementById('vault-account-custom-platform')?.value || '').trim(),
    username: (document.getElementById('vault-account-username')?.value || '').trim(),
    email_used: (document.getElementById('vault-account-email')?.value || '').trim(),
    profile_link: (document.getElementById('vault-account-profile-link')?.value || '').trim(),
    notes: (document.getElementById('vault-account-notes')?.value || '').trim(),
  };
  try {
    if (id) await personalApiPost(`/api/personal-vault/digital-accounts/${id}/update/`, payload);
    else await personalApiPost('/api/personal-vault/digital-accounts/create/', payload);
    closeModal('vault-digital-account-modal-overlay');
    showToast(`Digital account ${id ? 'updated' : 'created'}`);
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
  } catch (err) {
    showToast(err.message || 'Unable to save digital account');
  }
}

function openPasswordReferenceModal(row = null) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('vault-password-reference-id', row?.id || '');
  set('vault-ref-platform', row?.platform || '');
  set('vault-ref-username', row?.username || '');
  set('vault-ref-email', row?.email_used || '');
  set('vault-ref-password-hint', row?.password_hint || '');
  set('vault-ref-two-factor', row?.two_factor_enabled ? '1' : '0');
  set('vault-ref-password-manager', row?.password_manager || 'bitwarden');
  set('vault-ref-backup-location', row?.backup_codes_location || '');
  set('vault-ref-notes', row?.notes || '');
  const title = document.getElementById('vault-password-reference-modal-title');
  if (title) title.textContent = row ? 'Edit Password Reference' : 'Add Password Reference';
  openModal('vault-password-reference-modal-overlay');
}

async function submitPasswordReferenceForm(event) {
  event.preventDefault();
  const id = document.getElementById('vault-password-reference-id')?.value;
  const payload = {
    platform: (document.getElementById('vault-ref-platform')?.value || '').trim(),
    username: (document.getElementById('vault-ref-username')?.value || '').trim(),
    email_used: (document.getElementById('vault-ref-email')?.value || '').trim(),
    password_hint: (document.getElementById('vault-ref-password-hint')?.value || '').trim(),
    two_factor_enabled: document.getElementById('vault-ref-two-factor')?.value === '1',
    backup_codes_location: (document.getElementById('vault-ref-backup-location')?.value || '').trim(),
    password_manager: document.getElementById('vault-ref-password-manager')?.value || 'bitwarden',
    notes: (document.getElementById('vault-ref-notes')?.value || '').trim(),
  };
  try {
    if (id) await personalApiPost(`/api/personal-vault/password-references/${id}/update/`, payload);
    else await personalApiPost('/api/personal-vault/password-references/create/', payload);
    closeModal('vault-password-reference-modal-overlay');
    showToast(`Password reference ${id ? 'updated' : 'created'}`);
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
  } catch (err) {
    showToast(err.message || 'Unable to save password reference');
  }
}

async function uploadIdentityVaultFile() {
  const selectedInputFile = document.getElementById('vault-identity-file')?.files?.[0];
  const uploadFile = selectedInputFile || personalState.pendingIdentityFile;
  if (!uploadFile) {
    showToast('Select or drop a file first');
    return;
  }
  const payload = new FormData();
  payload.append('file_type', document.getElementById('vault-identity-file-type')?.value || 'other');
  payload.append('file', uploadFile);
  try {
    await apiRequestForm('/api/personal-vault/identity-files/upload/', payload);
    personalState.pendingIdentityFile = null;
    const field = document.getElementById('vault-identity-file');
    if (field) field.value = '';
    showToast('Identity file uploaded');
    await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
  } catch (err) {
    showToast(err.message || 'Identity file upload failed');
  }
}

function bindPersonalTagInput(inputId, buttonId, listKey) {
  const input = document.getElementById(inputId);
  const button = document.getElementById(buttonId);
  if (!input || !button) return;
  button.addEventListener('click', () => {
    addPersonalTag(listKey, input.value);
    input.value = '';
    input.focus();
  });
  input.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    addPersonalTag(listKey, input.value);
    input.value = '';
  });
}

function setupPersonalDropzones() {
  const photoZone = document.getElementById('personal-photo-drop-zone');
  const docsZone = document.getElementById('personal-identity-drop-zone');
  const docsInput = document.getElementById('vault-identity-file');

  const attachDropHandlers = (zone, onDrop) => {
    if (!zone) return;
    const prevent = (event) => {
      event.preventDefault();
      event.stopPropagation();
    };
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach((evt) => zone.addEventListener(evt, prevent));
    ['dragenter', 'dragover'].forEach((evt) => zone.addEventListener(evt, () => zone.classList.add('dragover')));
    ['dragleave', 'drop'].forEach((evt) => zone.addEventListener(evt, () => zone.classList.remove('dragover')));
    zone.addEventListener('drop', (event) => {
      const file = event.dataTransfer?.files?.[0];
      if (file) onDrop(file);
    });
  };

  attachDropHandlers(photoZone, (file) => {
    handlePersonalProfilePhotoSelection(file);
  });
  attachDropHandlers(docsZone, (file) => {
    personalState.pendingIdentityFile = file;
    showToast(`Identity file attached: ${file.name}`);
  });

  if (docsZone && docsInput) {
    docsZone.addEventListener('click', () => docsInput.click());
  }
}

function attachPersonalActionDelegates() {
  const page = document.getElementById('page-personal');
  if (!page) return;
  page.addEventListener('click', async (event) => {
    const trigger = event.target.closest('[data-action]');
    if (!trigger) return;
    const action = trigger.dataset.action;
    const id = Number(trigger.dataset.id || 0);
    const listKey = trigger.dataset.list || '';
    const value = trigger.dataset.value || '';

    try {
      if (action === 'remove-personal-tag') {
        removePersonalTag(listKey, value);
      } else if (action === 'download-identity-file') {
        const row = (personalState.uploadedFiles || []).find((item) => item.id === id);
        if (row?.file_url) window.open(row.file_url, '_blank', 'noopener,noreferrer');
      } else if (action === 'delete-identity-file') {
        if (!window.confirm('Delete this identity file?')) return;
        await personalApiPost(`/api/personal-vault/identity-files/${id}/delete/`, {});
        showToast('Identity file deleted');
        await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
      } else if (action === 'edit-digital-account') {
        const row = (personalState.digitalAccounts || []).find((item) => item.id === id);
        openDigitalAccountModal(row || null);
      } else if (action === 'delete-digital-account') {
        if (!window.confirm('Delete this account record?')) return;
        await personalApiPost(`/api/personal-vault/digital-accounts/${id}/delete/`, {});
        showToast('Digital account deleted');
        await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
      } else if (action === 'edit-password-reference') {
        const row = (personalState.passwordReferences || []).find((item) => item.id === id);
        openPasswordReferenceModal(row || null);
      } else if (action === 'delete-password-reference') {
        if (!window.confirm('Delete this password reference?')) return;
        await personalApiPost(`/api/personal-vault/password-references/${id}/delete/`, {});
        showToast('Password reference deleted');
        await loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
      }
    } catch (err) {
      showToast(err.message || 'Personal vault action failed');
    }
  });
}

function setupPersonalAutosaveBindings() {
  const bind = (id, step, events = ['input', 'change']) => {
    const field = document.getElementById(id);
    if (!field) return;
    events.forEach((eventName) => {
      field.addEventListener(eventName, () => schedulePersonalAutosave(step));
    });
  };

  ['vault-first-name', 'vault-last-name', 'vault-dob', 'vault-gender', 'vault-nationality'].forEach((id) => bind(id, 1));
  [
    'vault-primary-email',
    'vault-secondary-email',
    'vault-primary-phone',
    'vault-secondary-phone',
    'vault-home-address',
    'vault-city',
    'vault-country',
    'vault-postal-code',
  ].forEach((id) => bind(id, 2));
  ['vault-national-id', 'vault-passport-number', 'vault-passport-expiry', 'vault-drivers-license', 'vault-student-id'].forEach((id) => bind(id, 3));
  ['vault-linkedin', 'vault-twitter', 'vault-instagram', 'vault-github', 'vault-portfolio', 'vault-blog', 'vault-youtube'].forEach((id) => bind(id, 5));
}

function setupPersonalPage() {
  if (!isPersonalPage()) return;
  if (personalState.isSetup) {
    loadPersonalVaultBootstrap({ preserveStep: true, silent: true });
    return;
  }
  personalState.isSetup = true;

  const bind = (id, eventName, handler) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener(eventName, handler);
  };

  bind('personal-refresh-btn', 'click', () => loadPersonalVaultBootstrap({ preserveStep: true }));
  bind('save-step1-btn', 'click', async () => {
    try {
      await savePersonalStep1({ goNext: true });
    } catch (err) {
      showToast(err.message || 'Unable to save step 1');
    }
  });
  bind('save-step2-btn', 'click', async () => {
    try {
      await savePersonalStep2({ goNext: true });
    } catch (err) {
      showToast(err.message || 'Unable to save step 2');
    }
  });
  bind('save-step3-btn', 'click', async () => {
    try {
      await savePersonalStep3({ goNext: true });
    } catch (err) {
      showToast(err.message || 'Unable to save step 3');
    }
  });
  bind('save-step5-btn', 'click', async () => {
    try {
      await savePersonalStep5({ goNext: true });
    } catch (err) {
      showToast(err.message || 'Unable to save step 5');
    }
  });
  bind('save-vault-btn', 'click', async () => {
    try {
      await saveCurrentPersonalStep({ silent: false });
    } catch (err) {
      showToast(err.message || 'Unable to sync vault');
    }
  });

  bind('add-digital-account-btn', 'click', () => openDigitalAccountModal(null));
  bind('add-password-reference-btn', 'click', () => openPasswordReferenceModal(null));
  bind('apply-account-filters-btn', 'click', () => {
    personalState.filters.accountSearch = (document.getElementById('vault-account-search')?.value || '').trim();
    personalState.filters.accountPlatform = (document.getElementById('vault-account-platform-filter')?.value || '').trim();
    renderDigitalAccountsTable();
  });

  bind('upload-identity-file-btn', 'click', uploadIdentityVaultFile);
  bind('vault-identity-file', 'change', (event) => {
    const file = event.target?.files?.[0];
    if (!file) return;
    personalState.pendingIdentityFile = file;
  });
  bind('vault-profile-photo', 'change', async (event) => {
    const file = event.target?.files?.[0];
    if (file) await handlePersonalProfilePhotoSelection(file);
  });

  bind('vault-digital-account-form', 'submit', submitDigitalAccountForm);
  bind('vault-password-reference-form', 'submit', submitPasswordReferenceForm);

  bindPersonalTagInput('vault-language-input', 'add-language-tag-btn', 'languages');
  bindPersonalTagInput('vault-additional-email-input', 'add-email-btn', 'additionalEmails');
  bindPersonalTagInput('vault-other-phone-input', 'add-phone-btn', 'otherPhones');

  document.querySelectorAll('[data-close-modal]').forEach((el) => {
    el.addEventListener('click', () => closeModal(el.dataset.closeModal));
  });
  document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) overlay.classList.add('hidden');
    });
  });

  document.addEventListener('keydown', (event) => {
    if (!isPersonalPage()) return;
    if (event.key === 'Escape') {
      closeAllModals();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
      event.preventDefault();
      saveCurrentPersonalStep({ silent: false }).catch((err) => showToast(err.message || 'Unable to save'));
    }
  });

  const accountSearch = document.getElementById('vault-account-search');
  if (accountSearch) {
    accountSearch.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      document.getElementById('apply-account-filters-btn')?.click();
    });
  }

  ['vault-linkedin', 'vault-twitter', 'vault-instagram', 'vault-github', 'vault-portfolio', 'vault-blog', 'vault-youtube'].forEach((id) => {
    const field = document.getElementById(id);
    if (!field) return;
    field.addEventListener('input', () => {
      personalState.socialProfiles = {
        ...personalState.socialProfiles,
        ...getPersonalStep5Payload(),
      };
      renderSocialPreview();
    });
  });

  setupPersonalDropzones();
  setupPersonalAutosaveBindings();
  attachPersonalActionDelegates();
  loadPersonalVaultBootstrap();
}

function isEducationPage() {
  return getActivePage() === 'education';
}

function educationApiGet(path, query = null) {
  if (query) {
    const params = new URLSearchParams(query);
    return apiRequest(`${path}?${params.toString()}`);
  }
  return apiRequest(path);
}

function educationApiPost(path, payload) {
  return apiRequest(path, 'POST', payload || {});
}

function formatDateDisplay(value) {
  if (!value) return '—';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleDateString('en-KE', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getStatusChipClass(status) {
  if (status === 'completed' || status === 'accepted') return 'status-completed';
  if (status === 'in_progress' || status === 'preparing_documents' || status === 'interview_stage') return 'status-inprogress';
  return 'status-idea';
}

function getScholarshipDaysLeft(deadline) {
  if (!deadline) return null;
  const d = new Date(deadline);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  const diffMs = d.getTime() - now.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

async function loadDashboardEducationAlerts() {
  const banner = document.getElementById('dashboard-education-alert-banner');
  const list = document.getElementById('dashboard-education-alert-list');
  if (!banner || !list || !isAuthenticated()) return;
  try {
    const payload = await educationApiGet('/api/education/deadline-alerts/');
    const rows = payload.rows || [];
    if (!rows.length) {
      banner.innerHTML = '<i class=\"fas fa-circle-check\"></i> No urgent education deadlines.';
      list.innerHTML = '<div class=\"table-empty\">Everything is on track.</div>';
      return;
    }
    banner.innerHTML = `<i class=\"fas fa-exclamation-triangle\"></i> ${escapeHtml(rows[0].message)}`;
    list.innerHTML = rows.slice(0, 3).map((row) => `
      <a class=\"compact-list-item\" href=\"/education/\">\n        <span class=\"compact-date\">${row.days_left}d</span>\n        <span class=\"compact-copy\">${escapeHtml(row.message)}</span>\n      </a>
    `).join('');
  } catch (err) {
    banner.innerHTML = '<i class=\"fas fa-triangle-exclamation\"></i> Unable to load education alerts right now.';
  }
}

function renderEducationAlerts(alerts = []) {
  educationState.deadlineAlerts = alerts.slice();
  const banner = document.getElementById('education-alert-banner');
  const list = document.getElementById('education-deadline-alerts');
  if (!banner || !list) return;

  if (!alerts.length) {
    banner.innerHTML = '<i class=\"fas fa-circle-check\"></i> No urgent scholarship deadlines right now.';
    list.innerHTML = '';
    return;
  }

  banner.innerHTML = `<i class=\"fas fa-clock\"></i> ${escapeHtml(alerts[0].message)}`;
  list.innerHTML = alerts.slice(0, 8).map((item) => `
    <div class=\"education-alert-item\">
      <span>${escapeHtml(item.message)}</span>
      <span class=\"days\">${item.days_left}d</span>
    </div>
  `).join('');
}

function renderAcademicLevels(levels = []) {
  educationState.levels = levels.slice();
  const grid = document.getElementById('academic-level-grid');
  if (!grid) return;
  if (!levels.length) {
    grid.innerHTML = '<div class=\"table-empty\">No academic levels added yet.</div>';
    return;
  }

  grid.innerHTML = levels.map((level) => {
    const statusClass = getStatusChipClass(level.status);
    const years = [level.start_year, level.end_year].filter(Boolean).join(' - ') || 'Timeline not set';
    const examCount = (level.exam_certifications || []).length;
    return `
      <div class=\"education-level-card\">
        <div class=\"education-card-head\">
          <div>
            <div class=\"education-title\">${escapeHtml(level.level_label)}</div>
            <div class=\"education-subtitle\">${escapeHtml(level.school_name || level.university_name || 'Not specified')}</div>
          </div>
          <span class=\"card-status ${statusClass}\">${escapeHtml((level.status || 'planned').replace('_', ' '))}</span>
        </div>
        <div class=\"education-details\">
          <div class=\"education-detail\"><strong>Location:</strong> ${escapeHtml(level.location || level.country || '—')}</div>
          <div class=\"education-detail\"><strong>Years:</strong> ${escapeHtml(years)}</div>
          <div class=\"education-detail\"><strong>Adm/Student #:</strong> ${escapeHtml(level.admission_number || level.student_number || '—')}</div>
          <div class=\"education-detail\"><strong>GPA/Grade:</strong> ${escapeHtml(level.gpa || level.grades || '—')}</div>
        </div>
        <div class=\"education-expand\">
          <div class=\"education-detail\"><strong>Subjects:</strong> ${escapeHtml(level.subjects_taken || '—')}</div>
          <div class=\"education-detail\"><strong>Research:</strong> ${escapeHtml(level.research_topic || '—')}</div>
          <div class=\"education-detail\"><strong>Internships:</strong> ${escapeHtml(level.internships || '—')}</div>
          <div class=\"education-detail\"><strong>Clubs:</strong> ${escapeHtml(level.clubs_activities || '—')}</div>
          <div class=\"education-detail\"><strong>Awards:</strong> ${escapeHtml(level.awards || '—')}</div>
          <div class=\"education-detail\"><strong>Exam Toggle:</strong> ${level.certification_exam_completed ? 'Yes' : 'No'} (${examCount} exam record${examCount === 1 ? '' : 's'})</div>
          <div class=\"education-detail\"><strong>Certificate:</strong> ${level.certificate_url ? `<a href=\"${escapeHtml(level.certificate_url)}\" target=\"_blank\" rel=\"noopener noreferrer\">Open</a>` : '—'}</div>
          <div class=\"education-detail\"><strong>Transcript:</strong> ${level.transcript_url ? `<a href=\"${escapeHtml(level.transcript_url)}\" target=\"_blank\" rel=\"noopener noreferrer\">Open</a>` : '—'}</div>
        </div>
        <div class=\"action-cell\">
          <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"edit-level\" data-id=\"${level.id}\">Edit</button>
          <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"add-level-exam\" data-id=\"${level.id}\">Add Exam</button>
          <button class=\"btn-outline btn-mini danger\" type=\"button\" data-action=\"delete-level\" data-id=\"${level.id}\">Delete</button>
        </div>
      </div>
    `;
  }).join('');
}

function renderExamTable(levels = []) {
  educationState.exams = [];
  levels.forEach((level) => {
    (level.exam_certifications || []).forEach((exam) => {
      educationState.exams.push({
        ...exam,
        level_label: level.level_label,
      });
    });
  });

  const body = document.getElementById('exam-table-body');
  if (!body) return;
  if (!educationState.exams.length) {
    body.innerHTML = '<tr><td colspan=\"7\" class=\"table-empty\">No exam records yet.</td></tr>';
    return;
  }

  body.innerHTML = educationState.exams.map((row) => `
    <tr>
      <td>${escapeHtml(row.level_label || '—')}</td>
      <td>${escapeHtml(row.exam_name || '')}</td>
      <td>${escapeHtml(row.exam_year || '—')}</td>
      <td>${escapeHtml(row.candidate_number || '—')}</td>
      <td>${escapeHtml(row.grade_score || '—')}</td>
      <td>${row.certificate_url ? `<a href=\"${escapeHtml(row.certificate_url)}\" target=\"_blank\" rel=\"noopener noreferrer\">Open</a>` : '—'}</td>
      <td class=\"action-cell\">\n        <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"edit-exam\" data-id=\"${row.id}\">Edit</button>\n        <button class=\"btn-outline btn-mini danger\" type=\"button\" data-action=\"delete-exam\" data-id=\"${row.id}\">Delete</button>\n      </td>
    </tr>
  `).join('');
}

function renderDocumentVault(rows = []) {
  educationState.documents = rows.slice();
  const body = document.getElementById('document-table-body');
  if (!body) return;
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan=\"6\" class=\"table-empty\">No documents uploaded yet.</td></tr>';
    return;
  }

  body.innerHTML = rows.map((row) => `
    <tr>
      <td>${escapeHtml(row.title || '')}</td>
      <td>${escapeHtml(row.document_type_label || row.document_type || '')}</td>
      <td>${escapeHtml(row.version || 'v1')}</td>
      <td>${escapeHtml(formatDateDisplay(row.expiration_date))}</td>
      <td>${escapeHtml(formatDateDisplay(row.updated_at))}</td>
      <td class=\"action-cell\">
        <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"edit-document\" data-id=\"${row.id}\">Edit</button>
        <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"download-document\" data-id=\"${row.id}\">Download</button>
        <button class=\"btn-outline btn-mini danger\" type=\"button\" data-action=\"delete-document\" data-id=\"${row.id}\">Delete</button>
      </td>
    </tr>
  `).join('');
}

function filterScholarships(rows = []) {
  const q = (educationState.filters.q || '').toLowerCase();
  const status = educationState.filters.status || '';
  return rows.filter((row) => {
    const appStatus = row.application?.status || '';
    const searchable = `${row.name || ''} ${row.country || ''} ${row.university || ''} ${row.field_of_study || ''}`.toLowerCase();
    if (q && !searchable.includes(q)) return false;
    if (status && status !== appStatus) return false;
    return true;
  });
}

function renderScholarships(rows = []) {
  educationState.scholarships = rows.slice();
  const grid = document.getElementById('scholarship-grid');
  if (!grid) return;
  const filtered = filterScholarships(rows);

  if (!filtered.length) {
    grid.innerHTML = '<div class=\"table-empty\">No scholarships match your current filters.</div>';
    return;
  }

  grid.innerHTML = filtered.map((row) => {
    const daysLeft = getScholarshipDaysLeft(row.application_deadline);
    const app = row.application || {};
    const statusClass = app.result_badge || 'pending';
    return `
      <div class=\"education-scholarship-card\">
        <div class=\"education-card-head\">
          <div>
            <div class=\"education-title\">${escapeHtml(row.name || '')}</div>
            <div class=\"education-subtitle\">${escapeHtml(row.country || 'Country not set')} · ${escapeHtml(row.field_of_study || 'Field not set')}</div>
          </div>
          <span class=\"scholarship-result ${statusClass}\">${statusClass === 'accepted' ? '🟢 Accepted' : statusClass === 'rejected' ? '🔴 Rejected' : '🟡 Pending'}</span>
        </div>
        <div class=\"education-details\">
          <div class=\"education-detail\"><strong>University:</strong> ${escapeHtml(row.university || '—')}</div>
          <div class=\"education-detail\"><strong>Degree:</strong> ${escapeHtml(row.degree_level || '—')}</div>
          <div class=\"education-detail\"><strong>Deadline:</strong> ${escapeHtml(formatDateDisplay(row.application_deadline))}</div>
          <div class=\"education-detail\"><strong>Countdown:</strong> ${daysLeft === null ? '—' : `${daysLeft} day${daysLeft === 1 ? '' : 's'}`}</div>
          <div class=\"education-detail\"><strong>Status:</strong> ${escapeHtml(app.status_label || 'Researching')}</div>
          <div class=\"education-detail\"><strong>Application ID:</strong> ${escapeHtml(app.application_id || '—')}</div>
          <div class=\"education-detail\"><strong>Submitted:</strong> ${app.is_submitted ? 'Yes' : 'No'}</div>
          <div class=\"education-detail\"><strong>Submission Date:</strong> ${escapeHtml(formatDateDisplay(app.submission_date))}</div>
        </div>
        <div class=\"education-progress-track\"><div class=\"education-progress-fill\" style=\"width:${row.progress_pct || 0}%\"></div></div>
        <div class=\"progress-label\"><span>${row.requirements_completed}/${row.requirements_total} requirements</span><span>${row.progress_pct || 0}%</span></div>
        <div class=\"education-checklist\">
          ${(row.requirements || []).map((req) => `
            <div class=\"education-check-item\">
              <div class=\"left\">
                <button class=\"check-box ${req.is_completed ? 'checked' : ''}\" type=\"button\" data-action=\"toggle-requirement\" data-id=\"${req.id}\">${req.is_completed ? CHECK_ICON_SMALL : ''}</button>
                <span>${escapeHtml(req.requirement_name)}</span>
              </div>
              <div class=\"action-cell\">
                ${req.linked_document_title ? `<span class=\"tag\">${escapeHtml(req.linked_document_title)}</span>` : ''}
                <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"edit-requirement\" data-id=\"${req.id}\" data-scholarship-id=\"${row.id}\">Edit</button>
                <button class=\"btn-outline btn-mini danger\" type=\"button\" data-action=\"delete-requirement\" data-id=\"${req.id}\">Delete</button>
              </div>
            </div>
          `).join('')}
        </div>
        <div class=\"action-cell\">
          <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"edit-scholarship\" data-id=\"${row.id}\">Edit Scholarship</button>
          <button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"add-requirement\" data-scholarship-id=\"${row.id}\">Add Requirement</button>
          ${app.id ? `<button class=\"btn-outline btn-mini\" type=\"button\" data-action=\"edit-application\" data-id=\"${app.id}\">Application Data</button>` : ''}
          <button class=\"btn-outline btn-mini danger\" type=\"button\" data-action=\"delete-scholarship\" data-id=\"${row.id}\">Delete</button>
        </div>
      </div>
    `;
  }).join('');
}

function updateEducationSelects() {
  const levelSelect = document.getElementById('education-exam-level');
  if (levelSelect) {
    const current = levelSelect.value;
    levelSelect.innerHTML = '<option value=\"\">Select level</option>' + educationState.levels.map((row) => `<option value=\"${row.id}\">${escapeHtml(row.level_label)} · ${escapeHtml(row.school_name || row.university_name || 'Untitled')}</option>`).join('');
    levelSelect.value = current || '';
  }

  const linkedDoc = document.getElementById('education-linked-document');
  if (linkedDoc) {
    const current = linkedDoc.value;
    linkedDoc.innerHTML = '<option value=\"\">None</option>' + educationState.documents.map((doc) => `<option value=\"${doc.id}\">${escapeHtml(doc.title)} (${escapeHtml(doc.version || 'v1')})</option>`).join('');
    linkedDoc.value = current || '';
  }
}

async function loadEducationBootstrap() {
  if (!isEducationPage() || !isAuthenticated()) return;
  try {
    const payload = await educationApiGet('/api/education/bootstrap/');
    renderEducationAlerts(payload.deadline_alerts || []);
    renderAcademicLevels(payload.academic_levels || []);
    renderExamTable(payload.academic_levels || []);
    renderDocumentVault(payload.documents || []);
    renderScholarships(payload.scholarships || []);
    updateEducationSelects();
  } catch (err) {
    showToast(err.message || 'Failed to load education workspace');
  }
}

function openEducationLevelModal(row = null) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('education-level-id', row?.id || '');
  set('education-level-type', row?.level_type || 'primary');
  set('education-level-status', row?.status || 'planned');
  set('education-school-name', row?.school_name || '');
  set('education-admission-number', row?.admission_number || '');
  set('education-location', row?.location || '');
  set('education-start-year', row?.start_year || '');
  set('education-end-year', row?.end_year || '');
  set('education-expected-grad-year', row?.expected_graduation_year || '');
  set('education-subjects', row?.subjects_taken || '');
  set('education-grades', row?.grades || '');
  set('education-certification-toggle', row?.certification_exam_completed ? '1' : '0');
  set('education-university-name', row?.university_name || '');
  set('education-country', row?.country || '');
  set('education-degree', row?.degree || '');
  set('education-major-program', row?.major_program || '');
  set('education-gpa', row?.gpa || '');
  set('education-research-topic', row?.research_topic || '');
  set('education-internships', row?.internships || '');
  set('education-clubs', row?.clubs_activities || '');
  set('education-awards', row?.awards || '');
  set('education-level-notes', row?.notes || '');
  const title = document.getElementById('education-level-modal-title');
  if (title) title.textContent = row ? 'Edit Academic Level' : 'Add Academic Level';
  openModal('education-level-modal-overlay');
}

async function submitEducationLevelForm(event) {
  event.preventDefault();
  const id = document.getElementById('education-level-id').value;
  const formData = new FormData();
  const append = (key, val) => formData.append(key, val ?? '');
  append('level_type', document.getElementById('education-level-type')?.value);
  append('status', document.getElementById('education-level-status')?.value);
  append('school_name', document.getElementById('education-school-name')?.value);
  append('admission_number', document.getElementById('education-admission-number')?.value);
  append('location', document.getElementById('education-location')?.value);
  append('start_year', document.getElementById('education-start-year')?.value);
  append('end_year', document.getElementById('education-end-year')?.value);
  append('expected_graduation_year', document.getElementById('education-expected-grad-year')?.value);
  append('subjects_taken', document.getElementById('education-subjects')?.value);
  append('grades', document.getElementById('education-grades')?.value);
  append('certification_exam_completed', document.getElementById('education-certification-toggle')?.value === '1' ? '1' : '0');
  append('university_name', document.getElementById('education-university-name')?.value);
  append('country', document.getElementById('education-country')?.value);
  append('degree', document.getElementById('education-degree')?.value);
  append('major_program', document.getElementById('education-major-program')?.value);
  append('gpa', document.getElementById('education-gpa')?.value);
  append('research_topic', document.getElementById('education-research-topic')?.value);
  append('internships', document.getElementById('education-internships')?.value);
  append('clubs_activities', document.getElementById('education-clubs')?.value);
  append('awards', document.getElementById('education-awards')?.value);
  append('notes', document.getElementById('education-level-notes')?.value);
  const certificate = document.getElementById('education-certificate-file')?.files?.[0];
  const transcript = document.getElementById('education-transcript-file')?.files?.[0];
  if (certificate) formData.append('certificate_file', certificate);
  if (transcript) formData.append('transcript_file', transcript);

  try {
    if (id) await apiRequestForm(`/api/education/levels/${id}/update/`, formData);
    else await apiRequestForm('/api/education/levels/create/', formData);
    closeModal('education-level-modal-overlay');
    showToast(`Academic level ${id ? 'updated' : 'created'}`);
    await loadEducationBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save academic level');
  }
}

function openEducationExamModal(row = null, levelId = null) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('education-exam-id', row?.id || '');
  set('education-exam-level', row?.academic_level_id || levelId || '');
  set('education-exam-name', row?.exam_name || '');
  set('education-exam-year', row?.exam_year || '');
  set('education-candidate-number', row?.candidate_number || '');
  set('education-grade-score', row?.grade_score || '');
  set('education-exam-notes', row?.notes || '');
  const title = document.getElementById('education-exam-modal-title');
  if (title) title.textContent = row ? 'Edit Certification Exam' : 'Add Certification Exam';
  openModal('education-exam-modal-overlay');
}

async function submitEducationExamForm(event) {
  event.preventDefault();
  const id = document.getElementById('education-exam-id').value;
  const formData = new FormData();
  formData.append('academic_level_id', document.getElementById('education-exam-level')?.value || '');
  formData.append('exam_name', document.getElementById('education-exam-name')?.value || '');
  formData.append('exam_year', document.getElementById('education-exam-year')?.value || '');
  formData.append('candidate_number', document.getElementById('education-candidate-number')?.value || '');
  formData.append('grade_score', document.getElementById('education-grade-score')?.value || '');
  formData.append('notes', document.getElementById('education-exam-notes')?.value || '');
  const cert = document.getElementById('education-exam-certificate-file')?.files?.[0];
  if (cert) formData.append('certificate_file', cert);

  try {
    if (id) await apiRequestForm(`/api/education/exams/${id}/update/`, formData);
    else await apiRequestForm('/api/education/exams/create/', formData);
    closeModal('education-exam-modal-overlay');
    showToast(`Exam ${id ? 'updated' : 'created'}`);
    await loadEducationBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save exam');
  }
}

function openEducationScholarshipModal(row = null) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('education-scholarship-id', row?.id || '');
  set('education-scholarship-name', row?.name || '');
  set('education-scholarship-country', row?.country || '');
  set('education-scholarship-university', row?.university || '');
  set('education-scholarship-field', row?.field_of_study || '');
  set('education-scholarship-degree', row?.degree_level || '');
  set('education-scholarship-website', row?.official_website || '');
  set('education-scholarship-deadline', row?.application_deadline || '');
  set('education-tuition-coverage', row?.tuition_coverage || '');
  set('education-monthly-stipend', row?.monthly_stipend || '');
  set('education-travel-coverage', row?.travel_coverage ? '1' : '0');
  set('education-accommodation', row?.accommodation ? '1' : '0');
  set('education-other-benefits', row?.other_benefits || '');
  const title = document.getElementById('education-scholarship-modal-title');
  if (title) title.textContent = row ? 'Edit Scholarship' : 'Add Scholarship';
  openModal('education-scholarship-modal-overlay');
}

async function submitEducationScholarshipForm(event) {
  event.preventDefault();
  const id = document.getElementById('education-scholarship-id').value;
  const payload = {
    name: document.getElementById('education-scholarship-name')?.value,
    country: document.getElementById('education-scholarship-country')?.value,
    university: document.getElementById('education-scholarship-university')?.value,
    field_of_study: document.getElementById('education-scholarship-field')?.value,
    degree_level: document.getElementById('education-scholarship-degree')?.value,
    official_website: document.getElementById('education-scholarship-website')?.value,
    application_deadline: document.getElementById('education-scholarship-deadline')?.value || null,
    tuition_coverage: document.getElementById('education-tuition-coverage')?.value,
    monthly_stipend: document.getElementById('education-monthly-stipend')?.value || null,
    travel_coverage: document.getElementById('education-travel-coverage')?.value === '1',
    accommodation: document.getElementById('education-accommodation')?.value === '1',
    other_benefits: document.getElementById('education-other-benefits')?.value,
  };
  try {
    if (id) await educationApiPost(`/api/education/scholarships/${id}/update/`, payload);
    else await educationApiPost('/api/education/scholarships/create/', payload);
    closeModal('education-scholarship-modal-overlay');
    showToast(`Scholarship ${id ? 'updated' : 'created'}`);
    await loadEducationBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save scholarship');
  }
}

function openEducationApplicationModal(row = null) {
  if (!row) return;
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('education-application-id', row.id || '');
  set('education-application-status', row.status || 'researching');
  set('education-is-submitted', row.is_submitted ? '1' : '0');
  set('education-submission-date', row.submission_date || '');
  set('education-application-id-field', row.application_id || '');
  set('education-portal-link', row.portal_link || '');
  set('education-application-notes', row.notes || '');
  openModal('education-application-modal-overlay');
}

async function submitEducationApplicationForm(event) {
  event.preventDefault();
  const id = document.getElementById('education-application-id').value;
  if (!id) {
    showToast('Application record is missing.');
    return;
  }
  const payload = {
    status: document.getElementById('education-application-status')?.value,
    is_submitted: document.getElementById('education-is-submitted')?.value === '1',
    submission_date: document.getElementById('education-submission-date')?.value || null,
    application_id: document.getElementById('education-application-id-field')?.value,
    portal_link: document.getElementById('education-portal-link')?.value,
    notes: document.getElementById('education-application-notes')?.value,
  };
  try {
    await educationApiPost(`/api/education/applications/${id}/update/`, payload);
    closeModal('education-application-modal-overlay');
    showToast('Application updated');
    await loadEducationBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to update application');
  }
}

function openEducationRequirementModal(scholarshipId, row = null) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('education-requirement-id', row?.id || '');
  set('education-requirement-scholarship-id', scholarshipId || row?.scholarship_id || '');
  set('education-requirement-name', row?.requirement_name || '');
  set('education-requirement-sort', row?.sort_order ?? 0);
  set('education-requirement-required', row?.is_required ? '1' : '0');
  set('education-requirement-completed', row?.is_completed ? '1' : '0');
  set('education-linked-document', row?.linked_document_id || '');
  const title = document.getElementById('education-requirement-modal-title');
  if (title) title.textContent = row ? 'Edit Requirement' : 'Add Requirement';
  openModal('education-requirement-modal-overlay');
}

async function submitEducationRequirementForm(event) {
  event.preventDefault();
  const id = document.getElementById('education-requirement-id').value;
  const payload = {
    scholarship_id: Number(document.getElementById('education-requirement-scholarship-id')?.value || 0),
    requirement_name: document.getElementById('education-requirement-name')?.value,
    sort_order: Number(document.getElementById('education-requirement-sort')?.value || 0),
    is_required: document.getElementById('education-requirement-required')?.value === '1',
    is_completed: document.getElementById('education-requirement-completed')?.value === '1',
    linked_document_id: document.getElementById('education-linked-document')?.value || null,
  };
  try {
    if (id) await educationApiPost(`/api/education/requirements/${id}/update/`, payload);
    else await educationApiPost('/api/education/requirements/create/', payload);
    closeModal('education-requirement-modal-overlay');
    showToast(`Requirement ${id ? 'updated' : 'created'}`);
    await loadEducationBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save requirement');
  }
}

function openEducationDocumentModal(row = null) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value ?? '';
  };
  set('education-document-id', row?.id || '');
  set('education-document-title', row?.title || '');
  set('education-document-type', row?.document_type || 'other');
  set('education-document-version', row?.version || 'v1');
  set('education-document-expiration', row?.expiration_date || '');
  set('education-document-notes', row?.notes || '');
  const title = document.getElementById('education-document-modal-title');
  if (title) title.textContent = row ? 'Edit Document' : 'Add Document';
  openModal('education-document-modal-overlay');
}

async function submitEducationDocumentForm(event) {
  event.preventDefault();
  const id = document.getElementById('education-document-id').value;
  const fileInput = document.getElementById('education-document-file');
  const selectedFile = fileInput?.files?.[0] || educationState.pendingDocumentFile || null;
  const formData = new FormData();
  formData.append('title', document.getElementById('education-document-title')?.value || '');
  formData.append('document_type', document.getElementById('education-document-type')?.value || 'other');
  formData.append('version', document.getElementById('education-document-version')?.value || 'v1');
  formData.append('expiration_date', document.getElementById('education-document-expiration')?.value || '');
  formData.append('notes', document.getElementById('education-document-notes')?.value || '');
  if (selectedFile) formData.append('file', selectedFile);

  try {
    if (id) await apiRequestForm(`/api/education/documents/${id}/update/`, formData);
    else await apiRequestForm('/api/education/documents/create/', formData);
    educationState.pendingDocumentFile = null;
    closeModal('education-document-modal-overlay');
    showToast(`Document ${id ? 'updated' : 'uploaded'}`);
    await loadEducationBootstrap();
  } catch (err) {
    showToast(err.message || 'Unable to save document');
  }
}

function getScholarshipById(id) {
  return educationState.scholarships.find((item) => item.id === id);
}

function getRequirementById(id) {
  for (const scholarship of educationState.scholarships) {
    const req = (scholarship.requirements || []).find((item) => item.id === id);
    if (req) return { requirement: req, scholarship };
  }
  return null;
}

function setupEducationDropzone() {
  const zone = document.getElementById('education-document-drop-zone');
  if (!zone) return;
  const prevent = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach((evt) => zone.addEventListener(evt, prevent));
  ['dragenter', 'dragover'].forEach((evt) => zone.addEventListener(evt, () => zone.classList.add('dragover')));
  ['dragleave', 'drop'].forEach((evt) => zone.addEventListener(evt, () => zone.classList.remove('dragover')));

  zone.addEventListener('drop', (event) => {
    const file = event.dataTransfer?.files?.[0];
    if (!file) return;
    educationState.pendingDocumentFile = file;
    openEducationDocumentModal(null);
    showToast(`Attached ${file.name} to document form`);
  });
}

function setupEducationPage() {
  if (!isEducationPage()) return;
  if (educationState.isSetup) {
    loadEducationBootstrap();
    return;
  }
  educationState.isSetup = true;

  const bind = (id, eventName, handler) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener(eventName, handler);
  };

  bind('quick-add-level-btn', 'click', () => openEducationLevelModal(null));
  bind('quick-add-scholarship-btn', 'click', () => openEducationScholarshipModal(null));
  bind('quick-add-document-btn', 'click', () => openEducationDocumentModal(null));
  bind('add-level-btn', 'click', () => openEducationLevelModal(null));
  bind('add-exam-btn', 'click', () => openEducationExamModal(null));
  bind('add-scholarship-btn', 'click', () => openEducationScholarshipModal(null));
  bind('add-document-btn', 'click', () => openEducationDocumentModal(null));
  bind('apply-scholarship-filters-btn', 'click', () => {
    educationState.filters.q = (document.getElementById('scholarship-search')?.value || '').trim();
    educationState.filters.status = (document.getElementById('scholarship-status-filter')?.value || '').trim();
    renderScholarships(educationState.scholarships);
  });

  bind('education-level-form', 'submit', submitEducationLevelForm);
  bind('education-exam-form', 'submit', submitEducationExamForm);
  bind('education-scholarship-form', 'submit', submitEducationScholarshipForm);
  bind('education-application-form', 'submit', submitEducationApplicationForm);
  bind('education-requirement-form', 'submit', submitEducationRequirementForm);
  bind('education-document-form', 'submit', submitEducationDocumentForm);

  const page = document.getElementById('page-education');
  if (page) {
    page.addEventListener('click', async (event) => {
      const btn = event.target.closest('[data-action]');
      if (!btn) return;
      const action = btn.dataset.action;
      const id = Number(btn.dataset.id || 0);
      const scholarshipId = Number(btn.dataset.scholarshipId || 0);
      try {
        if (action === 'edit-level') {
          const row = educationState.levels.find((item) => item.id === id);
          openEducationLevelModal(row || null);
        } else if (action === 'delete-level') {
          if (!window.confirm('Delete this academic level?')) return;
          await educationApiPost(`/api/education/levels/${id}/delete/`, {});
          await loadEducationBootstrap();
        } else if (action === 'add-level-exam') {
          openEducationExamModal(null, id);
        } else if (action === 'edit-exam') {
          const row = educationState.exams.find((item) => item.id === id);
          openEducationExamModal(row || null);
        } else if (action === 'delete-exam') {
          if (!window.confirm('Delete this exam record?')) return;
          await educationApiPost(`/api/education/exams/${id}/delete/`, {});
          await loadEducationBootstrap();
        } else if (action === 'edit-scholarship') {
          const row = getScholarshipById(id);
          openEducationScholarshipModal(row || null);
        } else if (action === 'delete-scholarship') {
          if (!window.confirm('Delete this scholarship and linked tracker data?')) return;
          await educationApiPost(`/api/education/scholarships/${id}/delete/`, {});
          await loadEducationBootstrap();
        } else if (action === 'edit-application') {
          let target = null;
          for (const row of educationState.scholarships) {
            if (row.application?.id === id) {
              target = row.application;
              break;
            }
          }
          openEducationApplicationModal(target);
        } else if (action === 'add-requirement') {
          openEducationRequirementModal(scholarshipId, null);
        } else if (action === 'edit-requirement') {
          const found = getRequirementById(id);
          openEducationRequirementModal(Number(btn.dataset.scholarshipId || found?.scholarship?.id || 0), found?.requirement || null);
        } else if (action === 'delete-requirement') {
          if (!window.confirm('Delete this requirement?')) return;
          await educationApiPost(`/api/education/requirements/${id}/delete/`, {});
          await loadEducationBootstrap();
        } else if (action === 'toggle-requirement') {
          await educationApiPost(`/api/education/requirements/${id}/toggle/`, {});
          await loadEducationBootstrap();
        } else if (action === 'edit-document') {
          const row = educationState.documents.find((item) => item.id === id);
          openEducationDocumentModal(row || null);
        } else if (action === 'download-document') {
          const row = educationState.documents.find((item) => item.id === id);
          if (row?.file_url) window.open(row.file_url, '_blank', 'noopener,noreferrer');
        } else if (action === 'delete-document') {
          if (!window.confirm('Delete this document from vault?')) return;
          await educationApiPost(`/api/education/documents/${id}/delete/`, {});
          await loadEducationBootstrap();
        }
      } catch (err) {
        showToast(err.message || 'Education action failed');
      }
    });
  }

  document.querySelectorAll('[data-close-modal]').forEach((el) => {
    el.addEventListener('click', () => closeModal(el.dataset.closeModal));
  });
  document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) overlay.classList.add('hidden');
    });
  });

  setupEducationDropzone();
  loadEducationBootstrap();
}

function toggleCheck(el) {
  el.classList.toggle('checked');
  el.innerHTML = el.classList.contains('checked') ? CHECK_ICON : '';
}

function selectMood(btn) {
  btn.closest('.mood-selector').querySelectorAll('.mood-btn').forEach((b) => b.classList.remove('selected'));
  btn.classList.add('selected');
}

function newDiaryEntry() {
  const now = new Date();
  document.getElementById('diary-current-date').textContent = now.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
  if (document.getElementById('diary-main-text')) document.getElementById('diary-main-text').value = '';
  if (document.getElementById('diary-achievements')) document.getElementById('diary-achievements').value = '';
  if (document.getElementById('diary-lessons')) document.getElementById('diary-lessons').value = '';
  if (document.getElementById('diary-ideas')) document.getElementById('diary-ideas').value = '';
  showToast('Started a new diary entry');
}

function filterBucket(el) {
  document.querySelectorAll('.bucket-cat').forEach((c) => c.classList.remove('active'));
  el.classList.add('active');
}

function animateProgressBars() {
  document.querySelectorAll('.progress-fill').forEach((b) => {
    const computedWidth = window.getComputedStyle(b).width;
    b.style.width = '0px';
    setTimeout(() => {
      b.style.width = computedWidth;
    }, 150);
  });
}

function toDateKey(dateObj) {
  const y = dateObj.getFullYear();
  const m = String(dateObj.getMonth() + 1).padStart(2, '0');
  const d = String(dateObj.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function renderDashboardCalendar() {
  const monthLabel = document.getElementById('dashboard-calendar-month');
  const grid = document.getElementById('dashboard-calendar-grid');
  if (!monthLabel || !grid) return;

  const focus = dashboardCalendarState.cursor;
  const year = focus.getFullYear();
  const month = focus.getMonth();
  const firstDay = new Date(year, month, 1);
  const startingWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();
  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;

  monthLabel.textContent = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  let html = dayNames.map((name) => `<div class="calendar-day-name">${name}</div>`).join('');

  for (let i = 0; i < startingWeekday; i += 1) {
    const dayNum = daysInPrevMonth - startingWeekday + i + 1;
    html += `<div class="calendar-day other-month">${dayNum}</div>`;
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const dateObj = new Date(year, month, day);
    const dateKey = toDateKey(dateObj);
    const classes = ['calendar-day'];
    if (isCurrentMonth && day === today.getDate()) classes.push('today');
    if (DASHBOARD_EVENT_DATES.has(dateKey)) classes.push('has-event');
    html += `<div class="${classes.join(' ')}">${day}</div>`;
  }

  const totalCells = startingWeekday + daysInMonth;
  const trailingDays = (7 - (totalCells % 7)) % 7;
  for (let i = 1; i <= trailingDays; i += 1) {
    html += `<div class="calendar-day other-month">${i}</div>`;
  }

  grid.innerHTML = html;
}

function shiftDashboardMonth(offset) {
  dashboardCalendarState.cursor = new Date(
    dashboardCalendarState.cursor.getFullYear(),
    dashboardCalendarState.cursor.getMonth() + offset,
    1
  );
  renderDashboardCalendar();
}

function prevDashboardMonth() {
  shiftDashboardMonth(-1);
}

function nextDashboardMonth() {
  shiftDashboardMonth(1);
}

function getThemeColor(variableName, fallback) {
  const value = getComputedStyle(document.documentElement).getPropertyValue(variableName).trim();
  return value || fallback;
}

function initChart(canvasId, configBuilder) {
  const canvas = document.getElementById(canvasId);
  if (!canvas || typeof Chart === 'undefined') return;
  if (canvas.dataset.chartReady === '1') return;
  if (canvas.offsetParent === null) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const config = configBuilder();
  new Chart(ctx, config);
  canvas.dataset.chartReady = '1';
}

function initCharts() {
  const coffee = getThemeColor('--coffee', '#3B1E12');
  const gold = getThemeColor('--gold', '#E2B56D');
  const bronze = getThemeColor('--bronze', '#8B5A2B');
  const cocoa = getThemeColor('--cocoa', '#6B3A1F');

  initChart('projects-activity-chart', () => ({
    type: 'bar',
    data: {
      labels: [],
      datasets: [{
        label: 'Completed Tasks',
        data: [],
        backgroundColor: [gold, gold, bronze, bronze, coffee, cocoa],
        borderRadius: 8,
      }],
    },
    options: {
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 2 } },
      },
    },
  }));

  initChart('projects-status-chart', () => ({
    type: 'pie',
    data: {
      labels: [],
      datasets: [{
        data: [],
        backgroundColor: [gold, bronze, coffee],
      }],
    },
    options: {
      maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom' } },
    },
  }));

}

function showToast(message) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add('show'));

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 260);
  }, 2200);
}

function setupOtpUX() {
  const otpInputs = Array.from(document.querySelectorAll('.otp-digit'));
  if (!otpInputs.length) return;

  otpInputs.forEach((input, idx) => {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !input.value && idx > 0) {
        otpInputs[idx - 1].focus();
      }
      if (e.key === 'ArrowLeft' && idx > 0) otpInputs[idx - 1].focus();
      if (e.key === 'ArrowRight' && idx < otpInputs.length - 1) otpInputs[idx + 1].focus();
      if (e.key === 'Enter') handleLogin();
    });

    input.addEventListener('paste', (e) => {
      const pasted = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
      if (!pasted) return;
      e.preventDefault();
      pasted.split('').forEach((char, pIdx) => {
        if (otpInputs[pIdx]) otpInputs[pIdx].value = char;
      });
      if (pasted.length === 6) setTimeout(handleLogin, 150);
    });
  });
}

function mountUIHelpers() {
  if (!document.getElementById('toast-container')) {
    const container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
}

function init() {
  updateClock();
  setInterval(updateClock, 1000);
  setupOtpUX();
  mountUIHelpers();
  setupUploadZones();
  applyTheme(getCurrentTheme());
  renderDashboardCalendar();
  animateProgressBars();

  if (isAuthenticated()) {
    openApp();
    if (!isPersonalPage()) {
      setupPageFormPersistence();
    }
    loadUnlockedPageData();
  } else {
    closeApp();
  }
}

document.addEventListener('DOMContentLoaded', init);

window.switchAuth = switchAuth;
window.handleSignup = handleSignup;
window.otpNext = otpNext;
window.otpVerify = otpVerify;
window.handleLogin = handleLogin;
window.signOut = signOut;
window.showPage = showPage;
window.goPersonalStep = goPersonalStep;
window.switchTab = switchTab;
window.toggleTask = toggleTask;
window.toggleCheck = toggleCheck;
window.selectMood = selectMood;
window.newDiaryEntry = newDiaryEntry;
window.filterBucket = filterBucket;
window.animateProgressBars = animateProgressBars;
window.showToast = showToast;
window.saveDiaryEntry = saveDiaryEntry;
window.saveProfileSettings = saveProfileSettings;
window.saveNotificationSettings = saveNotificationSettings;
window.prevDashboardMonth = prevDashboardMonth;
window.nextDashboardMonth = nextDashboardMonth;

```

---

## myos_project/myos_app/templates/base.html

- Size: 8624 bytes
- Lines: 133
- Modified: 2026-03-06 21:09:34
- SHA256: 7851c2f64964ff7b951402f1250fd1bccd6085afb48d8722734a16cf810d9c92
- MIME: text/html

```
{% load static %}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{% block title %}MyOS — Personal Operating System{% endblock %}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="{% static 'css/style.css' %}">
</head>
<body data-page="{{ active_page|default:'dashboard' }}">
  <div class="ambient-bg"></div>
  <div class="orb orb-1"></div>
  <div class="orb orb-2"></div>
  <div class="orb orb-3"></div>

  <div id="auth-overlay">
    <div class="auth-box">
      <div class="auth-logo">
        <div class="brand-name">MyOS</div>
        <div class="brand-sub">Personal Operating System</div>
      </div>
      <div class="auth-tabs" id="auth-tabs-bar">
        <button class="auth-tab active" onclick="switchAuth('login')">Sign In</button>
        <button class="auth-tab" onclick="switchAuth('signup')">Sign Up</button>
      </div>
      <div class="auth-form active" id="login-form">
        <div class="field-group"><label for="login-email">Email Address</label><input type="email" placeholder="you@example.com" id="login-email"></div>
        <div class="field-group"><label for="login-password">Password</label><input id="login-password" type="password" placeholder="********"></div>
        <div class="checkbox-row"><input type="checkbox" id="remember-me"><label for="remember-me">Remember me on this device</label></div>
        <div class="checkbox-row u-inline-1">By signing in you accept our use of essential cookies to keep your session secure and personalize your experience.</div>
        <button class="btn-primary" onclick="handleLogin()">Sign In to MyOS</button>
        <div class="sso-divider">or continue with</div>
        <div class="sso-buttons">
          <button class="btn-sso" onclick="handleLogin()"><i class="fab fa-google u-inline-2"></i> Google</button>
          <button class="btn-sso" onclick="handleLogin()"><i class="fab fa-apple"></i> Apple</button>
        </div>
      </div>
      <div class="auth-form" id="signup-form">
        <div class="auth-row">
          <div class="field-group"><label for="signup-first-name">First Name</label><input id="signup-first-name" type="text" placeholder="First name"></div>
          <div class="field-group"><label for="signup-last-name">Last Name</label><input id="signup-last-name" type="text" placeholder="Last name"></div>
        </div>
        <div class="field-group"><label for="signup-email">Email Address</label><input type="email" placeholder="you@example.com" id="signup-email"></div>
        <div class="field-group"><label for="signup-password">Password</label><input id="signup-password" type="password" placeholder="********"></div>
        <div class="field-group"><label for="signup-confirm-password">Confirm Password</label><input id="signup-confirm-password" type="password" placeholder="********"></div>
        <button class="btn-primary" onclick="handleSignup()">Create Account &amp; Send OTP</button>
        <div class="sso-divider">or sign up with</div>
        <div class="sso-buttons">
          <button class="btn-sso" onclick="handleLogin()"><i class="fab fa-google u-inline-2"></i> Google</button>
          <button class="btn-sso" onclick="handleLogin()"><i class="fab fa-apple"></i> Apple</button>
        </div>
      </div>
      <div class="otp-section" id="otp-section">
        <div class="otp-hint">A 6-digit code was sent to <strong id="otp-email-display"></strong></div>
        <div class="otp-inputs">
          <input type="text" maxlength="1" class="otp-digit" aria-label="OTP digit 1" title="OTP digit 1" inputmode="numeric" autocomplete="one-time-code" oninput="otpNext(this)">
          <input type="text" maxlength="1" class="otp-digit" aria-label="OTP digit 2" title="OTP digit 2" inputmode="numeric" oninput="otpNext(this)">
          <input type="text" maxlength="1" class="otp-digit" aria-label="OTP digit 3" title="OTP digit 3" inputmode="numeric" oninput="otpNext(this)">
          <input type="text" maxlength="1" class="otp-digit" aria-label="OTP digit 4" title="OTP digit 4" inputmode="numeric" oninput="otpNext(this)">
          <input type="text" maxlength="1" class="otp-digit" aria-label="OTP digit 5" title="OTP digit 5" inputmode="numeric" oninput="otpNext(this)">
          <input type="text" maxlength="1" class="otp-digit" aria-label="OTP digit 6" title="OTP digit 6" inputmode="numeric" oninput="otpVerify(this)">
        </div>
        <div class="otp-hint u-inline-3">Enter the 6-digit verification code from your email.</div>
        <button class="btn-primary" onclick="handleLogin()">Verify &amp; Enter MyOS</button>
      </div>
    </div>
  </div>

  <input id="global-upload-input" class="upload-input-hidden" type="file" aria-hidden="true" tabindex="-1">

  <div id="app">
    <aside class="sidebar">
      <div class="sidebar-brand">
        <div class="brand-logo">M</div>
        <div>
          <div class="brand-name">MyOS</div>
          <div class="brand-sub">Personal Operating System</div>
        </div>
      </div>
      <div class="sidebar-clock">
        <div id="clock-display">00:00:00</div>
        <div id="clock-date">Loading...</div>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section-label">Navigation</div>
        <a class="nav-item {% if active_page == 'dashboard' %}active{% endif %}" href="{% url 'dashboard' %}"><i class="fas fa-th-large"></i> Dashboard</a>
        <a class="nav-item {% if active_page == 'personal' %}active{% endif %}" href="{% url 'personal' %}"><i class="fas fa-user"></i> Personal Info</a>
        <a class="nav-item {% if active_page == 'education' %}active{% endif %}" href="{% url 'education' %}"><i class="fas fa-graduation-cap"></i> Education</a>
        <a class="nav-item {% if active_page == 'finance' %}active{% endif %}" href="{% url 'finance' %}"><i class="fas fa-wallet"></i> Finance</a>
        <a class="nav-item {% if active_page == 'media' %}active{% endif %}" href="{% url 'media' %}"><i class="fas fa-film"></i> Media</a>
        <a class="nav-item {% if active_page == 'bucket' %}active{% endif %}" href="{% url 'bucket' %}"><i class="fas fa-star"></i> Bucket List</a>
        <a class="nav-item {% if active_page == 'projects' %}active{% endif %}" href="{% url 'projects' %}"><i class="fas fa-rocket"></i> Projects</a>
        <a class="nav-item {% if active_page == 'finance' %}active{% endif %}" href="{% url 'finance' %}#finance-analytics"><i class="fas fa-chart-pie"></i> Analytics <span class="nav-badge">New</span></a>
        <a class="nav-item {% if active_page == 'diary' %}active{% endif %}" href="{% url 'diary' %}"><i class="fas fa-book-open"></i> Diary</a>
        <div class="nav-section-label u-inline-4">System</div>
        <a class="nav-item {% if active_page == 'settings' %}active{% endif %}" href="{% url 'settings' %}"><i class="fas fa-cog"></i> Settings</a>
        <a class="nav-item" href="#" onclick="signOut(); return false;"><i class="fas fa-sign-out-alt"></i> Sign Out</a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-card">
          <div class="user-avatar">IK</div>
          <div>
            <div class="user-name" id="sidebar-user-name">User</div>
            <div class="user-email" id="sidebar-user-email">No email set</div>
          </div>
        </div>
      </div>
    </aside>

    <main class="main">
      <div class="topbar">
        <div class="topbar-search">
          <i class="fas fa-search"></i>
          <input type="text" placeholder="Search passport, finance, diary, projects..." aria-label="Global search">
        </div>
        <div class="topbar-actions">
          <button class="topbar-btn u-inline-5" aria-label="Notifications" title="Notifications"><i class="fas fa-bell"></i><span class="notif-dot"></span></button>
          <button class="topbar-btn" aria-label="Quick add" title="Quick add"><i class="fas fa-plus"></i></button>
        </div>
      </div>
      <div class="page-content active" id="page-{{ active_page|default:'dashboard' }}">
        {% block page_content %}{% endblock %}
      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
  <script src="{% static 'js/main.js' %}" defer></script>
</body>
</html>

```

---

## myos_project/myos_app/templates/bucket.html

- Size: 1458 bytes
- Lines: 18
- Modified: 2026-03-06 21:03:05
- SHA256: 51121853eec2f021fb77fe1cfd1909b5e99d5feaeefe85bf339994dd5bcc860c
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Bucket List{% endblock %}

{% block page_content %}
<div class="page-header"><div><div class="page-title">Bucket List</div><div class="page-title-sub">Life goals, dreams and experiences to chase</div></div><button class="btn-add"><i class="fas fa-plus"></i> Add Goal</button></div>
<div class="bucket-categories">
  <div class="bucket-cat active" onclick="filterBucket(this)"><div class="cat-icon">🌍</div><div class="cat-count">0</div><div class="cat-name">All Goals</div></div>
  <div class="bucket-cat" onclick="filterBucket(this)"><div class="cat-icon">✈️</div><div class="cat-count">0</div><div class="cat-name">Travel</div></div>
  <div class="bucket-cat" onclick="filterBucket(this)"><div class="cat-icon">🏆</div><div class="cat-count">0</div><div class="cat-name">Achievements</div></div>
  <div class="bucket-cat" onclick="filterBucket(this)"><div class="cat-icon">🎯</div><div class="cat-count">0</div><div class="cat-name">Experiences</div></div>
  <div class="bucket-cat" onclick="filterBucket(this)"><div class="cat-icon">📚</div><div class="cat-count">0</div><div class="cat-name">Learning</div></div>
  <div class="bucket-cat" onclick="filterBucket(this)"><div class="cat-icon">💎</div><div class="cat-count">0</div><div class="cat-name">Wealth</div></div>
</div>
<div class="dash-card">
  <div class="table-empty">No bucket list goals added yet.</div>
</div>
{% endblock %}

```

---

## myos_project/myos_app/templates/dashboard.html

- Size: 6345 bytes
- Lines: 143
- Modified: 2026-03-06 21:01:25
- SHA256: 5b14959487da583316e86e5eea1a33a23c5c01c59bc6337d566bbae001e9050c
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Dashboard{% endblock %}

{% block page_content %}
<section class="dashboard-hero">
  <div class="dashboard-hero-text">
    <div class="time-greeting" id="greeting-text">Welcome</div>
    <div class="greeting-sub">Your command center is ready. Track progress, review analytics, and jump to any area with one click.</div>
  </div>
  <div class="dashboard-hero-clock">
    <div class="big-time" id="big-clock">00:00:00</div>
    <div class="big-date" id="big-date">Loading...</div>
  </div>
</section>

<div class="alert-banner" id="dashboard-education-alert-banner"><i class="fas fa-clock"></i> Loading education deadline alerts...</div>

<section class="stats-grid-glass">
  <a class="metric-link-card" href="{% url 'finance' %}">
    <div class="metric-copy">
      <div class="metric-label">Savings Position</div>
      <div class="metric-value">KES 0.00</div>
      <div class="metric-trend">No finance data yet</div>
    </div>
    <div class="metric-icon-wrap"><i class="fas fa-wallet"></i></div>
  </a>

  <a class="metric-link-card" href="{% url 'projects' %}">
    <div class="metric-copy">
      <div class="metric-label">Active Projects</div>
      <div class="metric-value">0</div>
      <div class="metric-trend">No projects tracked yet</div>
    </div>
    <div class="metric-icon-wrap"><i class="fas fa-rocket"></i></div>
  </a>

  <a class="metric-link-card" href="{% url 'diary' %}">
    <div class="metric-copy">
      <div class="metric-label">Diary Consistency</div>
      <div class="metric-value">0 days</div>
      <div class="metric-trend">No entries yet</div>
    </div>
    <div class="metric-icon-wrap"><i class="fas fa-book-open"></i></div>
  </a>

  <a class="metric-link-card" href="{% url 'finance' %}#finance-analytics">
    <div class="metric-copy">
      <div class="metric-label">Weekly Output</div>
      <div class="metric-value">0 tasks</div>
      <div class="metric-trend">No task history yet</div>
    </div>
    <div class="metric-icon-wrap"><i class="fas fa-chart-line"></i></div>
  </a>
</section>

<section class="dashboard-columns">
  <div class="dashboard-primary">
    <div class="dash-card">
      <div class="card-header">
        <div class="card-title">Today's Tasks</div>
        <a class="card-link-inline" href="{% url 'projects' %}">Open Projects →</a>
      </div>
      <div id="task-list">
        <div class="table-empty">No tasks created yet.</div>
      </div>
      <div class="progress-track u-inline-7"><div class="progress-fill u-inline-8" id="task-progress-fill"></div></div>
      <div class="progress-label"><span id="task-progress-text">0 / 0 tasks done</span><span id="task-progress-percent">0%</span></div>
    </div>

    <div class="split-grid">
      <div class="dash-card">
        <div class="card-header">
          <div class="card-title">Financial Summary</div>
          <a class="card-link-inline" href="{% url 'finance' %}">Go to Finance →</a>
        </div>
        <div class="finance-row"><span class="finance-label">Monthly Income</span><span class="finance-amount income">KES 0.00</span></div>
        <div class="finance-row"><span class="finance-label">Expenses</span><span class="finance-amount expense">KES 0.00</span></div>
        <div class="finance-row"><span class="finance-label">Savings</span><span class="finance-amount savings">KES 0.00</span></div>
        <div class="finance-row"><span class="finance-label">Application Fees</span><span class="finance-amount expense">KES 0.00</span></div>
        <div class="progress-track u-inline-7"><div class="progress-fill" style="width:0%"></div></div>
        <div class="progress-label"><span>No finance data available</span><span>Target: Set in Finance</span></div>
      </div>

      <div class="dash-card">
        <div class="card-header">
          <div class="card-title">Active Projects</div>
          <a class="card-link-inline" href="{% url 'projects' %}">See all →</a>
        </div>
        <div class="u-inline-16">
          <div class="table-empty">No projects available yet.</div>
        </div>
      </div>
    </div>

    <div class="dash-card">
      <div class="card-header">
        <div class="card-title">Recent Diary Entry</div>
        <a class="card-link-inline" href="{% url 'diary' %}">Open Diary →</a>
      </div>
      <div class="diary-preview"><div class="diary-date">No entries yet</div>Create your first diary entry to see a preview here.</div>
    </div>
  </div>

  <aside class="dashboard-secondary">
    <div class="dash-card calendar-widget-card">
      <div class="calendar-header">
        <div class="card-title" id="dashboard-calendar-month">Month YYYY</div>
        <div class="calendar-nav">
          <button class="calendar-nav-btn" type="button" aria-label="Previous month" onclick="prevDashboardMonth()"><i class="fas fa-chevron-left"></i></button>
          <button class="calendar-nav-btn" type="button" aria-label="Next month" onclick="nextDashboardMonth()"><i class="fas fa-chevron-right"></i></button>
        </div>
      </div>
      <div id="dashboard-calendar-grid" class="calendar-grid"></div>
    </div>

    <div class="dash-card">
      <div class="card-header">
        <div class="card-title">Upcoming Events</div>
        <a class="card-link-inline" href="{% url 'finance' %}#finance-analytics">Analytics →</a>
      </div>
      <div class="compact-list" id="dashboard-education-alert-list">
        <a class="compact-list-item" href="{% url 'education' %}">
          <span class="compact-date">...</span>
          <span class="compact-copy">Loading upcoming education and scholarship events...</span>
        </a>
      </div>
    </div>

    <div class="dash-card">
      <div class="card-header">
        <div class="card-title">Jump To</div>
      </div>
      <div class="u-inline-16">
        <a class="btn-add" href="{% url 'personal' %}"><i class="fas fa-user"></i> Personal Info</a>
        <a class="btn-add" href="{% url 'finance' %}"><i class="fas fa-wallet"></i> Finance</a>
        <a class="btn-add" href="{% url 'media' %}"><i class="fas fa-film"></i> Media Library</a>
        <a class="btn-add" href="{% url 'finance' %}#finance-analytics"><i class="fas fa-chart-pie"></i> Analytics</a>
      </div>
    </div>
  </aside>
</section>
{% endblock %}

```

---

## myos_project/myos_app/templates/diary.html

- Size: 2613 bytes
- Lines: 52
- Modified: 2026-03-06 21:01:41
- SHA256: d67ac3804d7d635d889449bbebe603d410c4114433e6595c7c9f1e39e18a0bfd
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Diary{% endblock %}

{% block page_content %}
<div class="page-header"><div><div class="page-title">Diary</div><div class="page-title-sub">Your private daily journal</div></div><button class="btn-add" onclick="newDiaryEntry()"><i class="fas fa-pen"></i> New Entry</button></div>
<div class="u-inline-92">
  <div>
    <div class="diary-editor">
      <div class="u-inline-93">
        <div class="u-inline-94" id="diary-current-date">Today</div>
        <div class="u-inline-31">Auto-saved</div>
      </div>
      <div class="u-inline-83">
        <div class="u-inline-95">Today's Mood</div>
        <div class="mood-selector">
          <button class="mood-btn selected" onclick="selectMood(this)">😊 Motivated</button>
          <button class="mood-btn" onclick="selectMood(this)">😌 Calm</button>
          <button class="mood-btn" onclick="selectMood(this)">😤 Frustrated</button>
          <button class="mood-btn" onclick="selectMood(this)">🤔 Reflective</button>
          <button class="mood-btn" onclick="selectMood(this)">🎉 Excited</button>
          <button class="mood-btn" onclick="selectMood(this)">😴 Tired</button>
        </div>
      </div>
      <textarea id="diary-main-text" placeholder="Write about your day, thoughts, ideas..."></textarea>
      <div class="u-inline-96">
        <div class="form-field"><label>Achievements Today</label><textarea id="diary-achievements" class="u-inline-97" placeholder="What did you accomplish?"></textarea></div>
        <div class="form-field"><label>Lessons Learned</label><textarea id="diary-lessons" class="u-inline-97" placeholder="What did you learn?"></textarea></div>
      </div>
      <div class="form-field u-inline-40"><label>Ideas &amp; Sparks 💡</label><textarea id="diary-ideas" class="u-inline-98" placeholder="Any ideas that came to you today?"></textarea></div>
      <div class="u-inline-99">
        <button class="btn-primary u-inline-38" onclick="saveDiaryEntry()">Save Entry</button>
        <button class="btn-outline u-inline-100">Discard</button>
      </div>
    </div>
  </div>

  <div>
    <div class="dash-card">
      <div class="card-title u-inline-83">Past Entries</div>
      <div class="u-inline-16" id="diary-past-entries">
        <div class="table-empty">No diary entries yet.</div>
      </div>
    </div>

    <div class="dash-card u-inline-105">
      <div class="card-title u-inline-106">Mood History</div>
      <div class="table-empty">Mood history will appear after multiple entries are saved.</div>
    </div>
  </div>
</div>
{% endblock %}

```

---

## myos_project/myos_app/templates/education.html

- Size: 20467 bytes
- Lines: 292
- Modified: 2026-03-05 22:51:17
- SHA256: 3e0eabed6a36d359af36332479b0a8e104bd1bf5c26ebae1e39d5dbe44fb29ee
- MIME: text/html

```
{% extends 'base.html' %}

{% block title %}MyOS — Education Command Center{% endblock %}

{% block page_content %}
<section class="education-hero" id="education-command-center">
  <div>
    <div class="page-title">Education Command Center</div>
    <div class="page-title-sub">Manage academic history, scholarship applications, reusable documents, and deadline-driven execution.</div>
  </div>
  <div class="education-hero-actions">
    <button class="btn-add" type="button" id="quick-add-level-btn"><i class="fas fa-school"></i> Add Academic Level</button>
    <button class="btn-add" type="button" id="quick-add-scholarship-btn"><i class="fas fa-award"></i> Add Scholarship</button>
    <button class="btn-add" type="button" id="quick-add-document-btn"><i class="fas fa-file-upload"></i> Upload Document</button>
  </div>
</section>

<div class="alert-banner" id="education-alert-banner"><i class="fas fa-clock"></i> Loading deadline alerts...</div>
<div class="compact-list" id="education-deadline-alerts"></div>

<div class="tab-bar education-tab-bar">
  <button class="tab-btn active" onclick="switchTab('edu','levels')">Academic Levels</button>
  <button class="tab-btn" onclick="switchTab('edu','scholarships')">Scholarship Tracker</button>
  <button class="tab-btn" onclick="switchTab('edu','documents')">General Documents</button>
</div>

<div class="tab-panel active" id="edu-levels">
  <div class="dash-card">
    <div class="card-header">
      <div>
        <div class="card-title">Academic Levels</div>
        <div class="card-subtitle">Primary, Secondary, University, and Certifications with expandable detail + uploads.</div>
      </div>
      <button class="btn-outline" type="button" id="add-level-btn"><i class="fas fa-plus"></i> Add Level</button>
    </div>
    <div class="education-level-grid" id="academic-level-grid"></div>
  </div>

  <div class="dash-card">
    <div class="card-header">
      <div>
        <div class="card-title">National / Certification Exams</div>
        <div class="card-subtitle">Track exam records for levels where certification exams are completed.</div>
      </div>
      <button class="btn-outline" type="button" id="add-exam-btn"><i class="fas fa-plus"></i> Add Exam</button>
    </div>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Level</th>
            <th>Exam Name</th>
            <th>Year</th>
            <th>Candidate #</th>
            <th>Grade / Score</th>
            <th>Certificate</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="exam-table-body"></tbody>
      </table>
    </div>
  </div>
</div>

<div class="tab-panel" id="edu-scholarships">
  <div class="dash-card">
    <div class="card-header">
      <div>
        <div class="card-title">Scholarship Tracker</div>
        <div class="card-subtitle">Search, filter, checklist progress, submission data, and status flow.</div>
      </div>
      <button class="btn-outline" type="button" id="add-scholarship-btn"><i class="fas fa-plus"></i> Add Scholarship</button>
    </div>

    <div class="education-toolbar">
      <input id="scholarship-search" type="text" placeholder="Search scholarship, country, field..." aria-label="Search scholarships">
      <select id="scholarship-status-filter" aria-label="Filter scholarship status">
        <option value="">All statuses</option>
        <option value="researching">Researching</option>
        <option value="preparing_documents">Preparing Documents</option>
        <option value="application_submitted">Application Submitted</option>
        <option value="interview_stage">Interview Stage</option>
        <option value="accepted">Accepted</option>
        <option value="rejected">Rejected</option>
        <option value="waitlisted">Waitlisted</option>
      </select>
      <button class="btn-outline" type="button" id="apply-scholarship-filters-btn">Apply</button>
    </div>

    <div class="education-scholarship-grid" id="scholarship-grid"></div>
  </div>
</div>

<div class="tab-panel" id="edu-documents">
  <div class="dash-card">
    <div class="card-header">
      <div>
        <div class="card-title">General Application Documents Vault</div>
        <div class="card-subtitle">Upload once, reuse across scholarship requirements, version and expiry tracked.</div>
      </div>
      <button class="btn-outline" type="button" id="add-document-btn"><i class="fas fa-plus"></i> Add Document</button>
    </div>

    <div class="education-upload-dropzone" id="education-document-drop-zone">
      <i class="fas fa-cloud-upload-alt"></i>
      <div>Drag and drop document here, or click “Add Document”.</div>
      <div class="u-inline-31">Supported: PDF, DOCX, PNG, JPG (max 10MB)</div>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Document</th>
            <th>Type</th>
            <th>Version</th>
            <th>Expiration</th>
            <th>Last Updated</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="document-table-body"></tbody>
      </table>
    </div>
  </div>
</div>

<!-- Academic Level Modal -->
<div class="modal-overlay hidden" id="education-level-modal-overlay">
  <div class="modal-card">
    <div class="modal-header">
      <div class="card-title" id="education-level-modal-title">Add Academic Level</div>
      <button class="modal-close" type="button" data-close-modal="education-level-modal-overlay">×</button>
    </div>
    <form id="education-level-form" class="modal-form-grid">
      <input type="hidden" id="education-level-id">
      <div class="form-field"><label for="education-level-type">Level</label><select id="education-level-type" required><option value="primary">Primary School</option><option value="secondary">Secondary School</option><option value="university">University</option><option value="certification">Certifications / Courses</option></select></div>
      <div class="form-field"><label for="education-level-status">Status</label><select id="education-level-status"><option value="completed">Completed</option><option value="in_progress">In Progress</option><option value="planned">Planned</option></select></div>
      <div class="form-field"><label for="education-school-name">School / Institution Name</label><input id="education-school-name" type="text"></div>
      <div class="form-field"><label for="education-admission-number">Admission / Student Number</label><input id="education-admission-number" type="text"></div>
      <div class="form-field"><label for="education-location">Location</label><input id="education-location" type="text"></div>
      <div class="form-field"><label for="education-start-year">Start Year</label><input id="education-start-year" type="number" min="1900" max="2100"></div>
      <div class="form-field"><label for="education-end-year">End Year</label><input id="education-end-year" type="number" min="1900" max="2100"></div>
      <div class="form-field"><label for="education-expected-grad-year">Expected Graduation</label><input id="education-expected-grad-year" type="number" min="1900" max="2100"></div>
      <div class="form-field"><label for="education-subjects">Subjects Taken</label><textarea id="education-subjects"></textarea></div>
      <div class="form-field"><label for="education-grades">Grades</label><textarea id="education-grades"></textarea></div>
      <div class="form-field"><label for="education-certification-toggle">Certification Exam Completed?</label><select id="education-certification-toggle"><option value="0">No</option><option value="1">Yes</option></select></div>
      <div class="form-field"><label for="education-certificate-file">Certificate Upload</label><input id="education-certificate-file" type="file" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"></div>

      <div class="form-field"><label for="education-university-name">University Name</label><input id="education-university-name" type="text"></div>
      <div class="form-field"><label for="education-country">Country</label><input id="education-country" type="text"></div>
      <div class="form-field"><label for="education-degree">Degree</label><input id="education-degree" type="text"></div>
      <div class="form-field"><label for="education-major-program">Major / Program</label><input id="education-major-program" type="text"></div>
      <div class="form-field"><label for="education-gpa">GPA</label><input id="education-gpa" type="text"></div>
      <div class="form-field"><label for="education-transcript-file">Transcript Upload</label><input id="education-transcript-file" type="file" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"></div>
      <div class="form-field modal-span-2"><label for="education-research-topic">Research Topic</label><textarea id="education-research-topic"></textarea></div>
      <div class="form-field"><label for="education-internships">Internships</label><textarea id="education-internships"></textarea></div>
      <div class="form-field"><label for="education-clubs">Clubs / Activities</label><textarea id="education-clubs"></textarea></div>
      <div class="form-field"><label for="education-awards">Awards</label><textarea id="education-awards"></textarea></div>
      <div class="form-field"><label for="education-level-notes">Notes</label><textarea id="education-level-notes"></textarea></div>

      <div class="modal-actions modal-span-2">
        <button class="btn-outline" type="button" data-close-modal="education-level-modal-overlay">Cancel</button>
        <button class="btn-primary" type="submit">Save Academic Level</button>
      </div>
    </form>
  </div>
</div>

<!-- Exam Modal -->
<div class="modal-overlay hidden" id="education-exam-modal-overlay">
  <div class="modal-card">
    <div class="modal-header">
      <div class="card-title" id="education-exam-modal-title">Add Certification Exam</div>
      <button class="modal-close" type="button" data-close-modal="education-exam-modal-overlay">×</button>
    </div>
    <form id="education-exam-form" class="modal-form-grid">
      <input type="hidden" id="education-exam-id">
      <div class="form-field"><label for="education-exam-level">Academic Level</label><select id="education-exam-level" required></select></div>
      <div class="form-field"><label for="education-exam-name">Exam Name</label><input id="education-exam-name" type="text" required></div>
      <div class="form-field"><label for="education-exam-year">Exam Year</label><input id="education-exam-year" type="number" min="1900" max="2100"></div>
      <div class="form-field"><label for="education-candidate-number">Candidate Number</label><input id="education-candidate-number" type="text"></div>
      <div class="form-field"><label for="education-grade-score">Grade / Score</label><input id="education-grade-score" type="text"></div>
      <div class="form-field"><label for="education-exam-certificate-file">Certificate Upload</label><input id="education-exam-certificate-file" type="file" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"></div>
      <div class="form-field modal-span-2"><label for="education-exam-notes">Notes</label><textarea id="education-exam-notes"></textarea></div>
      <div class="modal-actions modal-span-2">
        <button class="btn-outline" type="button" data-close-modal="education-exam-modal-overlay">Cancel</button>
        <button class="btn-primary" type="submit">Save Exam</button>
      </div>
    </form>
  </div>
</div>

<!-- Scholarship Modal -->
<div class="modal-overlay hidden" id="education-scholarship-modal-overlay">
  <div class="modal-card">
    <div class="modal-header">
      <div class="card-title" id="education-scholarship-modal-title">Add Scholarship</div>
      <button class="modal-close" type="button" data-close-modal="education-scholarship-modal-overlay">×</button>
    </div>
    <form id="education-scholarship-form" class="modal-form-grid">
      <input type="hidden" id="education-scholarship-id">
      <div class="form-field"><label for="education-scholarship-name">Scholarship Name</label><input id="education-scholarship-name" type="text" required></div>
      <div class="form-field"><label for="education-scholarship-country">Country</label><input id="education-scholarship-country" type="text"></div>
      <div class="form-field"><label for="education-scholarship-university">University (optional)</label><input id="education-scholarship-university" type="text"></div>
      <div class="form-field"><label for="education-scholarship-field">Field of Study</label><input id="education-scholarship-field" type="text"></div>
      <div class="form-field"><label for="education-scholarship-degree">Degree Level</label><input id="education-scholarship-degree" type="text"></div>
      <div class="form-field"><label for="education-scholarship-website">Official Website</label><input id="education-scholarship-website" type="url"></div>
      <div class="form-field"><label for="education-scholarship-deadline">Application Deadline</label><input id="education-scholarship-deadline" type="date"></div>
      <div class="form-field"><label for="education-tuition-coverage">Tuition Coverage</label><input id="education-tuition-coverage" type="text" placeholder="Full / Partial"></div>
      <div class="form-field"><label for="education-monthly-stipend">Monthly Stipend</label><input id="education-monthly-stipend" type="number" min="0" step="0.01"></div>
      <div class="form-field"><label for="education-travel-coverage">Travel Coverage</label><select id="education-travel-coverage"><option value="0">No</option><option value="1">Yes</option></select></div>
      <div class="form-field"><label for="education-accommodation">Accommodation</label><select id="education-accommodation"><option value="0">No</option><option value="1">Yes</option></select></div>
      <div class="form-field modal-span-2"><label for="education-other-benefits">Other Benefits</label><textarea id="education-other-benefits"></textarea></div>
      <div class="modal-actions modal-span-2">
        <button class="btn-outline" type="button" data-close-modal="education-scholarship-modal-overlay">Cancel</button>
        <button class="btn-primary" type="submit">Save Scholarship</button>
      </div>
    </form>
  </div>
</div>

<!-- Scholarship Application Modal -->
<div class="modal-overlay hidden" id="education-application-modal-overlay">
  <div class="modal-card">
    <div class="modal-header">
      <div class="card-title">Application Submission Details</div>
      <button class="modal-close" type="button" data-close-modal="education-application-modal-overlay">×</button>
    </div>
    <form id="education-application-form" class="modal-form-grid">
      <input type="hidden" id="education-application-id">
      <div class="form-field"><label for="education-application-status">Application Status</label><select id="education-application-status"><option value="researching">Researching</option><option value="preparing_documents">Preparing Documents</option><option value="application_submitted">Application Submitted</option><option value="interview_stage">Interview Stage</option><option value="accepted">Accepted</option><option value="rejected">Rejected</option><option value="waitlisted">Waitlisted</option></select></div>
      <div class="form-field"><label for="education-is-submitted">Application Submitted?</label><select id="education-is-submitted"><option value="0">No</option><option value="1">Yes</option></select></div>
      <div class="form-field"><label for="education-submission-date">Submission Date</label><input id="education-submission-date" type="date"></div>
      <div class="form-field"><label for="education-application-id-field">Application ID</label><input id="education-application-id-field" type="text"></div>
      <div class="form-field modal-span-2"><label for="education-portal-link">Application Portal Link</label><input id="education-portal-link" type="url"></div>
      <div class="form-field modal-span-2"><label for="education-application-notes">Notes</label><textarea id="education-application-notes"></textarea></div>
      <div class="modal-actions modal-span-2">
        <button class="btn-outline" type="button" data-close-modal="education-application-modal-overlay">Cancel</button>
        <button class="btn-primary" type="submit">Save Application</button>
      </div>
    </form>
  </div>
</div>

<!-- Requirement Modal -->
<div class="modal-overlay hidden" id="education-requirement-modal-overlay">
  <div class="modal-card">
    <div class="modal-header">
      <div class="card-title" id="education-requirement-modal-title">Add Requirement</div>
      <button class="modal-close" type="button" data-close-modal="education-requirement-modal-overlay">×</button>
    </div>
    <form id="education-requirement-form" class="modal-form-grid">
      <input type="hidden" id="education-requirement-id">
      <input type="hidden" id="education-requirement-scholarship-id">
      <div class="form-field"><label for="education-requirement-name">Requirement</label><input id="education-requirement-name" type="text" required></div>
      <div class="form-field"><label for="education-requirement-sort">Sort Order</label><input id="education-requirement-sort" type="number" min="0" value="0"></div>
      <div class="form-field"><label for="education-requirement-required">Required?</label><select id="education-requirement-required"><option value="1">Yes</option><option value="0">No</option></select></div>
      <div class="form-field"><label for="education-requirement-completed">Completed?</label><select id="education-requirement-completed"><option value="0">No</option><option value="1">Yes</option></select></div>
      <div class="form-field modal-span-2"><label for="education-linked-document">Use existing document</label><select id="education-linked-document"><option value="">None</option></select></div>
      <div class="modal-actions modal-span-2">
        <button class="btn-outline" type="button" data-close-modal="education-requirement-modal-overlay">Cancel</button>
        <button class="btn-primary" type="submit">Save Requirement</button>
      </div>
    </form>
  </div>
</div>

<!-- Document Modal -->
<div class="modal-overlay hidden" id="education-document-modal-overlay">
  <div class="modal-card">
    <div class="modal-header">
      <div class="card-title" id="education-document-modal-title">Add Document</div>
      <button class="modal-close" type="button" data-close-modal="education-document-modal-overlay">×</button>
    </div>
    <form id="education-document-form" class="modal-form-grid">
      <input type="hidden" id="education-document-id">
      <div class="form-field"><label for="education-document-title">Document Title</label><input id="education-document-title" type="text" required></div>
      <div class="form-field"><label for="education-document-type">Document Type</label><select id="education-document-type"><option value="personal_statement">Personal Statement</option><option value="cv_resume">CV / Resume</option><option value="financial_statement">Financial Statement</option><option value="academic_transcript">Academic Transcript</option><option value="recommendation_letter">Recommendation Letter</option><option value="passport_copy">Passport Copy</option><option value="certificate">Certificate</option><option value="other">Other</option></select></div>
      <div class="form-field"><label for="education-document-file">Upload / Replace File</label><input id="education-document-file" type="file" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"></div>
      <div class="form-field"><label for="education-document-version">Version</label><input id="education-document-version" type="text" value="v1"></div>
      <div class="form-field"><label for="education-document-expiration">Expiration Date (optional)</label><input id="education-document-expiration" type="date"></div>
      <div class="form-field modal-span-2"><label for="education-document-notes">Notes</label><textarea id="education-document-notes"></textarea></div>
      <div class="modal-actions modal-span-2">
        <button class="btn-outline" type="button" data-close-modal="education-document-modal-overlay">Cancel</button>
        <button class="btn-primary" type="submit">Save Document</button>
      </div>
    </form>
  </div>
</div>
{% endblock %}

```

---

## myos_project/myos_app/templates/finance.html

- Size: 25307 bytes
- Lines: 385
- Modified: 2026-03-05 21:59:21
- SHA256: 65bdf734d6aca763530932f8467381c3fb2e5cdb8f854b5ae465f7cd0afb9736
- MIME: text/html

```
{% extends 'base.html' %}

{% block title %}MyOS — Finance Command Center{% endblock %}

{% block page_content %}
<section class="finance-hero" id="finance-command-center">
  <div>
    <div class="page-title">Finance Command Center</div>
    <div class="page-title-sub">Operate your full personal finance system: ledger, budgets, goals, scholarship planning, and startup capital.</div>
  </div>
  <div class="finance-hero-actions">
    <button class="btn-outline" id="theme-toggle-btn" type="button"><i class="fas fa-moon"></i> Toggle Theme</button>
    <button class="btn-add" id="quick-add-transaction-btn" type="button"><i class="fas fa-plus"></i> Quick Add Transaction</button>
  </div>
</section>

<section class="stats-grid-glass finance-metric-grid" id="finance-metric-cards"></section>

<section class="finance-layout">
  <div class="finance-main-col">
    <div class="finance-tabs-block">
      <div class="tab-bar finance-tab-bar">
        <button class="tab-btn active" onclick="switchTab('fin','ledger')">Ledger</button>
        <button class="tab-btn" onclick="switchTab('fin','budgets')">Budgets</button>
        <button class="tab-btn" onclick="switchTab('fin','savings')">Savings Goals</button>
        <button class="tab-btn" onclick="switchTab('fin','application')">Scholarship Planner</button>
        <button class="tab-btn" onclick="switchTab('fin','projects')">Project Budgets</button>
        <button class="tab-btn" onclick="switchTab('fin','analytics')" id="finance-analytics">Analytics &amp; Insights</button>
      </div>

      <div class="tab-panel active" id="fin-ledger">
        <div class="dash-card">
          <div class="card-header">
            <div>
              <div class="card-title">Transaction Ledger</div>
              <div class="card-subtitle">Search, filter, sort, and export your complete financial history.</div>
            </div>
            <button class="btn-outline" type="button" id="ledger-export-csv-btn"><i class="fas fa-file-csv"></i> Export CSV</button>
          </div>

          <div class="ledger-toolbar" id="ledger-toolbar">
            <input id="ledger-search" type="text" placeholder="Search description or tag..." aria-label="Search transactions">
            <input id="ledger-date-from" type="date" aria-label="Date from">
            <input id="ledger-date-to" type="date" aria-label="Date to">
            <select id="ledger-category-filter" aria-label="Category filter"><option value="">All categories</option></select>
            <select id="ledger-account-filter" aria-label="Account filter">
              <option value="">All accounts</option>
              <option value="cash">Cash</option>
              <option value="bank">Bank</option>
              <option value="mobile_money">Mobile Money</option>
            </select>
            <select id="ledger-type-filter" aria-label="Type filter">
              <option value="">All types</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
              <option value="savings">Savings</option>
              <option value="transfer">Transfer</option>
            </select>
            <input id="ledger-amount-min" type="number" min="0" step="0.01" placeholder="Min amount" aria-label="Minimum amount">
            <input id="ledger-amount-max" type="number" min="0" step="0.01" placeholder="Max amount" aria-label="Maximum amount">
            <select id="ledger-sort" aria-label="Sort transactions">
              <option value="date_desc">Date (Newest)</option>
              <option value="date_asc">Date (Oldest)</option>
              <option value="amount_desc">Amount (High → Low)</option>
              <option value="amount_asc">Amount (Low → High)</option>
              <option value="category_asc">Category (A → Z)</option>
            </select>
            <button class="btn-outline" type="button" id="ledger-apply-filters-btn">Apply</button>
          </div>

          <div class="table-wrap">
            <table class="data-table ledger-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Description</th>
                  <th>Category</th>
                  <th>Account</th>
                  <th>Amount</th>
                  <th>Tags</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="ledger-table-body"></tbody>
            </table>
          </div>
          <div class="ledger-pagination" id="ledger-pagination"></div>
        </div>
      </div>

      <div class="tab-panel" id="fin-budgets">
        <div class="dash-card">
          <div class="card-header">
            <div>
              <div class="card-title">Budget Management</div>
              <div class="card-subtitle">Set monthly category limits and monitor utilization in real time.</div>
            </div>
            <button class="btn-add" type="button" id="add-budget-btn"><i class="fas fa-plus"></i> Add Budget</button>
          </div>
          <div class="budget-grid" id="budget-grid"></div>
        </div>
      </div>

      <div class="tab-panel" id="fin-savings">
        <div class="dash-card">
          <div class="card-header">
            <div>
              <div class="card-title">Savings Goals</div>
              <div class="card-subtitle">Track progress, deadlines, and suggested monthly contributions.</div>
            </div>
            <button class="btn-add" type="button" id="add-goal-btn"><i class="fas fa-plus"></i> Add Goal</button>
          </div>
          <div class="savings-grid" id="savings-goals-grid"></div>
        </div>
      </div>

      <div class="tab-panel" id="fin-application">
        <div class="dash-card">
          <div class="card-header">
            <div>
              <div class="card-title">Scholarship / Application Financial Planner</div>
              <div class="card-subtitle">Passport, exams, visa, documents, and travel costs in one plan.</div>
            </div>
            <button class="btn-add" type="button" id="add-application-cost-btn"><i class="fas fa-plus"></i> Add Cost Item</button>
          </div>

          <div class="application-summary" id="application-summary"></div>

          <div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Estimated</th>
                  <th>Actual</th>
                  <th>Status</th>
                  <th>Deadline</th>
                  <th>Notes</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="application-table-body"></tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="tab-panel" id="fin-projects">
        <div class="dash-card">
          <div class="card-header">
            <div>
              <div class="card-title">Project &amp; Startup Budget Integration</div>
              <div class="card-subtitle">Control project spending, remaining runway, and ROI targets.</div>
            </div>
            <button class="btn-add" type="button" id="add-project-budget-btn"><i class="fas fa-plus"></i> Add Project Budget</button>
          </div>
          <div class="project-budget-grid" id="project-budget-grid"></div>
        </div>
      </div>

      <div class="tab-panel" id="fin-analytics">
        <div class="split-grid">
          <div class="dash-card chart-card">
            <div class="card-header">
              <div>
                <div class="card-title">Monthly Income vs Expenses</div>
                <div class="card-subtitle">Trend over the last 6 months</div>
              </div>
            </div>
            <div class="chart-canvas-wrap"><canvas id="finance-income-expense-chart" aria-label="Monthly income and expenses chart"></canvas></div>
          </div>

          <div class="dash-card chart-card">
            <div class="card-header"><div class="card-title">Expense Category Distribution</div></div>
            <div class="chart-canvas-wrap"><canvas id="finance-category-chart" aria-label="Expense category distribution chart"></canvas></div>
          </div>

          <div class="dash-card chart-card">
            <div class="card-header"><div class="card-title">Savings Growth</div></div>
            <div class="chart-canvas-wrap"><canvas id="finance-savings-growth-chart" aria-label="Savings growth over time"></canvas></div>
          </div>

          <div class="dash-card chart-card">
            <div class="card-header"><div class="card-title">Budget Utilization</div></div>
            <div class="chart-canvas-wrap"><canvas id="finance-budget-utilization-chart" aria-label="Budget utilization chart"></canvas></div>
          </div>

          <div class="dash-card chart-card">
            <div class="card-header"><div class="card-title">Application Cost Breakdown</div></div>
            <div class="chart-canvas-wrap"><canvas id="finance-application-breakdown-chart" aria-label="Application cost breakdown chart"></canvas></div>
          </div>

          <div class="dash-card chart-card">
            <div class="card-header"><div class="card-title">Project ROI Tracking</div></div>
            <div class="chart-canvas-wrap"><canvas id="finance-project-roi-chart" aria-label="Project ROI chart"></canvas></div>
          </div>
        </div>

        <div class="split-grid">
          <div class="dash-card">
            <div class="card-header">
              <div class="card-title">Automation: Recurring Forecast</div>
              <button class="btn-outline" id="refresh-forecast-btn" type="button">Refresh</button>
            </div>
            <div class="compact-list" id="recurring-forecast-list"></div>
          </div>

          <div class="dash-card">
            <div class="card-header">
              <div class="card-title">Budget Alerts</div>
              <button class="btn-outline" id="mark-all-alerts-read-btn" type="button">Mark All Read</button>
            </div>
            <div class="insight-list" id="budget-alerts-list"></div>
          </div>

          <div class="dash-card analytics-main-chart">
            <div class="card-header"><div class="card-title">Financial Insights</div></div>
            <div class="insight-list" id="finance-insights-list"></div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <aside class="finance-side-col">
    <div class="dash-card">
      <div class="card-header">
        <div class="card-title">Quick Actions</div>
      </div>
      <div class="u-inline-16">
        <button class="btn-add" type="button" id="quick-add-recurring-btn"><i class="fas fa-rotate"></i> Add Recurring</button>
        <button class="btn-add" type="button" id="quick-add-category-btn"><i class="fas fa-tags"></i> Add Category</button>
        <a class="btn-add" href="{% url 'education' %}"><i class="fas fa-graduation-cap"></i> Scholarship Tracker</a>
        <a class="btn-add" href="{% url 'projects' %}"><i class="fas fa-rocket"></i> Project Workspace</a>
      </div>
    </div>

    <div class="dash-card">
      <div class="card-header">
        <div class="card-title">Categories</div>
        <button class="btn-outline btn-mini" type="button" id="manage-categories-btn"><i class="fas fa-plus"></i> Add</button>
      </div>
      <div class="compact-list finance-categories-list" id="finance-categories-list"></div>
    </div>

    <div class="dash-card">
      <div class="card-header">
        <div class="card-title">Financial Health Snapshot</div>
      </div>
      <div id="finance-health-snapshot" class="u-inline-16"></div>
    </div>
  </aside>
</section>

<!-- Transaction Modal -->
<div class="modal-overlay hidden" id="transaction-modal-overlay">
  <div class="modal-card">
    <div class="modal-header">
      <div class="card-title" id="transaction-modal-title">Add Transaction</div>
      <button class="modal-close" type="button" data-close-modal="transaction-modal-overlay">×</button>
    </div>
    <form id="transaction-form" class="modal-form-grid">
      <input type="hidden" id="transaction-id">
      <div class="form-field"><label for="transaction-date">Date</label><input id="transaction-date" type="date" required></div>
      <div class="form-field"><label for="transaction-description">Description</label><input id="transaction-description" type="text" required></div>
      <div class="form-field"><label for="transaction-category">Category</label><select id="transaction-category" required></select></div>
      <div class="form-field"><label for="transaction-account">Account</label><select id="transaction-account"><option value="cash">Cash</option><option value="bank">Bank</option><option value="mobile_money">Mobile Money</option></select></div>
      <div class="form-field"><label for="transaction-type">Type</label><select id="transaction-type"><option value="income">Income</option><option value="expense">Expense</option><option value="savings">Savings</option><option value="transfer">Transfer</option></select></div>
      <div class="form-field"><label for="transaction-amount">Amount</label><input id="transaction-amount" type="number" min="0" step="0.01" required></div>
      <div class="form-field"><label for="transaction-tags">Tags (comma separated)</label><input id="transaction-tags" type="text"></div>
      <div class="form-field"><label for="transaction-savings-goal">Savings Goal (optional)</label><select id="transaction-savings-goal"><option value="">None</option></select></div>
      <div class="form-field"><label for="transaction-application-cost">Application Cost (optional)</label><select id="transaction-application-cost"><option value="">None</option></select></div>
      <div class="form-field"><label for="transaction-project-budget">Project Budget (optional)</label><select id="transaction-project-budget"><option value="">None</option></select></div>
      <div class="form-field modal-span-2"><label for="transaction-notes">Notes</label><textarea id="transaction-notes"></textarea></div>
      <div class="modal-actions modal-span-2">
        <button class="btn-outline" type="button" data-close-modal="transaction-modal-overlay">Cancel</button>
        <button class="btn-primary" type="submit">Save Transaction</button>
      </div>
    </form>
  </div>
</div>

<!-- Budget Modal -->
<div class="modal-overlay hidden" id="budget-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="budget-modal-title">Add Budget</div><button class="modal-close" type="button" data-close-modal="budget-modal-overlay">×</button></div>
    <form id="budget-form" class="modal-form-grid">
      <input type="hidden" id="budget-id">
      <div class="form-field"><label for="budget-category">Category</label><select id="budget-category" required></select></div>
      <div class="form-field"><label for="budget-period-start">Month</label><input id="budget-period-start" type="date" required></div>
      <div class="form-field"><label for="budget-monthly-limit">Monthly Limit</label><input id="budget-monthly-limit" type="number" min="0" step="0.01" required></div>
      <div class="form-field"><label for="budget-threshold">Warning Threshold %</label><input id="budget-threshold" type="number" min="1" max="100" step="1" value="90" required></div>
      <div class="form-field"><label for="budget-active">Active</label><select id="budget-active"><option value="1">Yes</option><option value="0">No</option></select></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="budget-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Budget</button></div>
    </form>
  </div>
</div>

<!-- Savings Goal Modal -->
<div class="modal-overlay hidden" id="goal-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="goal-modal-title">Add Savings Goal</div><button class="modal-close" type="button" data-close-modal="goal-modal-overlay">×</button></div>
    <form id="goal-form" class="modal-form-grid">
      <input type="hidden" id="goal-id">
      <div class="form-field"><label for="goal-name">Goal Name</label><input id="goal-name" type="text" required></div>
      <div class="form-field"><label for="goal-target-amount">Target Amount</label><input id="goal-target-amount" type="number" min="0" step="0.01" required></div>
      <div class="form-field"><label for="goal-starting-amount">Current Savings</label><input id="goal-starting-amount" type="number" min="0" step="0.01" value="0"></div>
      <div class="form-field"><label for="goal-deadline">Deadline</label><input id="goal-deadline" type="date"></div>
      <div class="form-field"><label for="goal-status">Status</label><select id="goal-status"><option value="active">Active</option><option value="completed">Completed</option><option value="paused">Paused</option></select></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="goal-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Goal</button></div>
    </form>
  </div>
</div>

<!-- Application Cost Modal -->
<div class="modal-overlay hidden" id="application-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="application-modal-title">Add Application Cost</div><button class="modal-close" type="button" data-close-modal="application-modal-overlay">×</button></div>
    <form id="application-form" class="modal-form-grid">
      <input type="hidden" id="application-id">
      <div class="form-field"><label for="application-item-type">Item Type</label><select id="application-item-type"><option value="passport">Passport</option><option value="sat">SAT</option><option value="ielts">IELTS</option><option value="toefl">TOEFL</option><option value="goethe">Goethe</option><option value="visa">Visa</option><option value="certified_documents">Certified documents</option><option value="application_fees">Application fees</option><option value="travel">Travel</option><option value="other">Other</option></select></div>
      <div class="form-field"><label for="application-estimated">Estimated Cost</label><input id="application-estimated" type="number" min="0" step="0.01" required></div>
      <div class="form-field"><label for="application-actual">Actual Cost</label><input id="application-actual" type="number" min="0" step="0.01"></div>
      <div class="form-field"><label for="application-status">Status</label><select id="application-status"><option value="planned">Planned</option><option value="in_progress">In Progress</option><option value="paid">Paid</option><option value="waived">Waived</option><option value="cancelled">Cancelled</option></select></div>
      <div class="form-field"><label for="application-deadline">Deadline</label><input id="application-deadline" type="date"></div>
      <div class="form-field modal-span-2"><label for="application-notes">Notes</label><textarea id="application-notes"></textarea></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="application-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Item</button></div>
    </form>
  </div>
</div>

<!-- Project Budget Modal -->
<div class="modal-overlay hidden" id="project-budget-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="project-budget-modal-title">Add Project Budget</div><button class="modal-close" type="button" data-close-modal="project-budget-modal-overlay">×</button></div>
    <form id="project-budget-form" class="modal-form-grid">
      <input type="hidden" id="project-budget-id">
      <div class="form-field"><label for="project-budget-name">Project Name</label><input id="project-budget-name" type="text" required></div>
      <div class="form-field"><label for="project-budget-amount">Budget</label><input id="project-budget-amount" type="number" min="0" step="0.01" required></div>
      <div class="form-field"><label for="project-budget-spent-adjustment">Manual Spent Adjustment</label><input id="project-budget-spent-adjustment" type="number" min="0" step="0.01" value="0"></div>
      <div class="form-field"><label for="project-budget-roi-target">ROI Target %</label><input id="project-budget-roi-target" type="number" step="0.01"></div>
      <div class="form-field"><label for="project-budget-roi-actual">ROI Actual %</label><input id="project-budget-roi-actual" type="number" step="0.01"></div>
      <div class="form-field"><label for="project-budget-status">Status</label><select id="project-budget-status"><option value="active">Active</option><option value="completed">Completed</option><option value="on_hold">On Hold</option></select></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="project-budget-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Project Budget</button></div>
    </form>
  </div>
</div>

<!-- Recurring Template Modal -->
<div class="modal-overlay hidden" id="recurring-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="recurring-modal-title">Add Recurring Template</div><button class="modal-close" type="button" data-close-modal="recurring-modal-overlay">×</button></div>
    <form id="recurring-form" class="modal-form-grid">
      <input type="hidden" id="recurring-id">
      <div class="form-field"><label for="recurring-name">Name</label><input id="recurring-name" type="text" required></div>
      <div class="form-field"><label for="recurring-category">Category</label><select id="recurring-category" required></select></div>
      <div class="form-field"><label for="recurring-account">Account</label><select id="recurring-account"><option value="cash">Cash</option><option value="bank">Bank</option><option value="mobile_money">Mobile Money</option></select></div>
      <div class="form-field"><label for="recurring-amount">Amount</label><input id="recurring-amount" type="number" min="0" step="0.01" required></div>
      <div class="form-field"><label for="recurring-cadence">Cadence</label><select id="recurring-cadence"><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="yearly">Yearly</option></select></div>
      <div class="form-field"><label for="recurring-next-due">Next Due Date</label><input id="recurring-next-due" type="date" required></div>
      <div class="form-field"><label for="recurring-end-date">End Date</label><input id="recurring-end-date" type="date"></div>
      <div class="form-field"><label for="recurring-active">Active</label><select id="recurring-active"><option value="1">Yes</option><option value="0">No</option></select></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="recurring-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Recurring</button></div>
    </form>
  </div>
</div>

<!-- Category Modal -->
<div class="modal-overlay hidden" id="category-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="category-modal-title">Add Category</div><button class="modal-close" type="button" data-close-modal="category-modal-overlay">×</button></div>
    <form id="category-form" class="modal-form-grid">
      <input type="hidden" id="category-id">
      <div class="form-field"><label for="category-name">Name</label><input id="category-name" type="text" required></div>
      <div class="form-field"><label for="category-slug">Slug (optional)</label><input id="category-slug" type="text" placeholder="auto-generated"></div>
      <div class="form-field"><label for="category-kind">Kind</label><select id="category-kind"><option value="income">Income</option><option value="expense">Expense</option><option value="savings">Savings</option><option value="application">Application</option><option value="business">Business</option><option value="investment">Investment</option><option value="transfer">Transfer</option><option value="other">Other</option></select></div>
      <div class="form-field"><label for="category-color">Color</label><input id="category-color" type="color" value="#8B5A2B"></div>
      <div class="form-field"><label for="category-icon">Icon class</label><input id="category-icon" type="text" value="fa-wallet" placeholder="fa-wallet"></div>
      <div class="form-field"><label for="category-sort-order">Sort Order</label><input id="category-sort-order" type="number" min="0" step="1" value="0"></div>
      <div class="form-field"><label for="category-active">Active</label><select id="category-active"><option value="1">Yes</option><option value="0">No</option></select></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="category-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Category</button></div>
    </form>
  </div>
</div>
{% endblock %}

```

---

## myos_project/myos_app/templates/index.html

- Size: 31 bytes
- Lines: 1
- Modified: 2026-03-05 19:27:50
- SHA256: 2ad67ac6c8671c720f769d76a8becdad5ecf9d3742a76b8b562a4d4db2afd540
- MIME: text/plain

```
{% extends 'dashboard.html' %}

```

---

## myos_project/myos_app/templates/media.html

- Size: 2410 bytes
- Lines: 28
- Modified: 2026-03-06 21:02:41
- SHA256: 4868725835cf875849900b972061db0eaa128da5e436cb420a1681b2669dc21b
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Media{% endblock %}

{% block page_content %}
<div class="page-header"><div><div class="page-title">Media</div><div class="page-title-sub">Movies, series, anime and animation tracker</div></div><button class="btn-add"><i class="fas fa-plus"></i> Add Media</button></div>
<div class="media-overview">
  <div class="media-stat"><div class="media-stat-label">Movies Watched</div><div class="media-stat-value">0</div><div class="media-bar-track"><div class="media-bar-fill" style="width:0%"></div></div><div class="u-inline-67">No entries yet</div></div>
  <div class="media-stat"><div class="media-stat-label">Series Progress</div><div class="media-stat-value">0</div><div class="media-bar-track"><div class="media-bar-fill" style="width:0%"></div></div><div class="u-inline-67">No entries yet</div></div>
  <div class="media-stat"><div class="media-stat-label">Anime Episodes</div><div class="media-stat-value">0</div><div class="media-bar-track"><div class="media-bar-fill" style="width:0%"></div></div><div class="u-inline-67">No entries yet</div></div>
  <div class="media-stat"><div class="media-stat-label">Total Watch Time</div><div class="media-stat-value">0h</div><div class="media-bar-track"><div class="media-bar-fill" style="width:0%"></div></div><div class="u-inline-67">No entries yet</div></div>
</div>

<div class="tab-bar">
  <button class="tab-btn active" onclick="switchTab('med','movies')">🎬 Movies</button>
  <button class="tab-btn" onclick="switchTab('med','series')">📺 Series</button>
  <button class="tab-btn" onclick="switchTab('med','anime')">🍥 Anime</button>
  <button class="tab-btn" onclick="switchTab('med','animation')">🧸 Animation</button>
</div>

<div class="tab-panel active" id="med-movies"><div class="cards-grid"><div class="dash-card"><div class="table-empty">No movies tracked yet.</div></div></div></div>

<div class="tab-panel" id="med-series"><div class="cards-grid"><div class="dash-card"><div class="table-empty">No series tracked yet.</div></div></div></div>

<div class="tab-panel" id="med-anime"><div class="cards-grid"><div class="dash-card"><div class="table-empty">No anime tracked yet.</div></div></div></div>

<div class="tab-panel" id="med-animation"><div class="cards-grid"><div class="dash-card"><div class="table-empty">No animation titles tracked yet.</div></div></div></div>
{% endblock %}

```

---

## myos_project/myos_app/templates/personal.html

- Size: 17198 bytes
- Lines: 198
- Modified: 2026-03-05 23:26:20
- SHA256: ed7d716c9a6391101136970536326e1c1e95e3edbbe5178d2d814dbfdfca24e4
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Personal Identity Vault{% endblock %}

{% block page_content %}
<section class="personal-vault-hero" id="personal-vault">
  <div>
    <div class="page-title">Personal Identity Vault</div>
    <div class="page-title-sub">Securely manage identity details, accounts, official documents, and security references.</div>
  </div>
  <div class="personal-vault-hero-actions">
    <button class="btn-outline" type="button" id="personal-refresh-btn"><i class="fas fa-rotate"></i> Refresh</button>
  </div>
</section>

<div class="dash-card personal-progress-card">
  <div class="card-header">
    <div class="card-title">Profile Completion</div>
    <div id="personal-completion-score" class="personal-score">0%</div>
  </div>
  <div class="progress-track"><div class="progress-fill" id="personal-completion-fill" style="width:0%"></div></div>
  <div class="progress-label"><span id="personal-completion-label">Starting setup...</span><span id="personal-completion-sub">0 / 6 steps</span></div>
  <div class="compact-list" id="personal-completion-suggestions"></div>
</div>

<div class="wizard-steps personal-wizard-steps" id="personal-steps">
  <div class="wizard-step active" onclick="goPersonalStep(1)"><span class="step-num" id="personal-step-icon-1">○</span>Basic Identity</div>
  <div class="wizard-step" onclick="goPersonalStep(2)"><span class="step-num" id="personal-step-icon-2">○</span>Contact Info</div>
  <div class="wizard-step" onclick="goPersonalStep(3)"><span class="step-num" id="personal-step-icon-3">○</span>Identity Docs</div>
  <div class="wizard-step" onclick="goPersonalStep(4)"><span class="step-num" id="personal-step-icon-4">○</span>Digital Accounts</div>
  <div class="wizard-step" onclick="goPersonalStep(5)"><span class="step-num" id="personal-step-icon-5">○</span>Public Profiles</div>
  <div class="wizard-step" onclick="goPersonalStep(6)"><span class="step-num" id="personal-step-icon-6">○</span>Security Refs</div>
</div>

<div class="dash-card">
  <div class="wizard-panel active" id="personal-panel-1">
    <div class="card-title u-inline-37">Step 1 — Basic Identity Information</div>
    <div class="form-grid">
      <div class="form-field"><label for="vault-first-name">First Name</label><input id="vault-first-name" type="text"></div>
      <div class="form-field"><label for="vault-last-name">Last Name</label><input id="vault-last-name" type="text"></div>
      <div class="form-field"><label for="vault-dob">Date of Birth</label><input id="vault-dob" type="date"></div>
      <div class="form-field"><label for="vault-gender">Gender</label><select id="vault-gender"><option value="">Select</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option><option value="prefer_not_to_say">Prefer not to say</option></select></div>
      <div class="form-field"><label for="vault-nationality">Nationality</label><input id="vault-nationality" type="text"></div>
      <div class="form-field"><label for="vault-language-input">Languages (tag input)</label><div class="personal-tag-input"><input id="vault-language-input" type="text" placeholder="English"><button class="btn-outline btn-mini" type="button" id="add-language-tag-btn">Add</button></div></div>
      <div class="form-field modal-span-2"><label>Language Tags</label><div class="personal-tags" id="vault-language-tags"></div></div>
    </div>

    <div class="section-divider"><span>Profile Photo</span></div>
    <div class="personal-photo-layout">
      <div class="education-upload-dropzone" id="personal-photo-drop-zone">
        <i class="fas fa-user-circle"></i>
        <div>Drag and drop profile photo here</div>
        <div class="u-inline-31">or choose file below (JPG/PNG only)</div>
        <input id="vault-profile-photo" type="file" accept=".jpg,.jpeg,.png">
      </div>
      <div class="personal-photo-preview" id="personal-photo-preview-card">
        <div class="u-inline-31">No photo uploaded yet</div>
      </div>
    </div>

    <div class="wizard-nav"><div></div><button class="btn-primary u-inline-38" type="button" id="save-step1-btn">Save & Next →</button></div>
  </div>

  <div class="wizard-panel" id="personal-panel-2">
    <div class="card-title u-inline-37">Step 2 — Contact Information</div>
    <div class="form-grid">
      <div class="form-field"><label for="vault-primary-email">Primary Email</label><input id="vault-primary-email" type="email"></div>
      <div class="form-field"><label for="vault-secondary-email">Secondary Email</label><input id="vault-secondary-email" type="email"></div>
      <div class="form-field"><label>Additional Emails</label><div class="personal-tag-input"><input id="vault-additional-email-input" type="email" placeholder="extra@email.com"><button class="btn-outline btn-mini" type="button" id="add-email-btn">Add</button></div></div>
      <div class="form-field"><label for="vault-primary-phone">Primary Phone</label><input id="vault-primary-phone" type="tel" placeholder="+254700000000"></div>
      <div class="form-field"><label for="vault-secondary-phone">Secondary Phone</label><input id="vault-secondary-phone" type="tel"></div>
      <div class="form-field"><label>Other Phone Numbers</label><div class="personal-tag-input"><input id="vault-other-phone-input" type="tel" placeholder="+254..." ><button class="btn-outline btn-mini" type="button" id="add-phone-btn">Add</button></div></div>
      <div class="form-field modal-span-2"><label>Additional Emails</label><div class="personal-tags" id="vault-additional-emails"></div></div>
      <div class="form-field modal-span-2"><label>Other Phone Numbers</label><div class="personal-tags" id="vault-other-phones"></div></div>
      <div class="form-field"><label for="vault-home-address">Home Address</label><input id="vault-home-address" type="text"></div>
      <div class="form-field"><label for="vault-city">City</label><input id="vault-city" type="text"></div>
      <div class="form-field"><label for="vault-country">Country</label><input id="vault-country" type="text"></div>
      <div class="form-field"><label for="vault-postal-code">Postal Code</label><input id="vault-postal-code" type="text"></div>
    </div>
    <div class="wizard-nav"><button class="btn-outline" type="button" onclick="goPersonalStep(1)">← Back</button><button class="btn-primary u-inline-38" type="button" id="save-step2-btn">Save & Next →</button></div>
  </div>

  <div class="wizard-panel" id="personal-panel-3">
    <div class="card-title u-inline-37">Step 3 — Identity Documents</div>
    <div class="form-grid">
      <div class="form-field"><label for="vault-national-id">National ID Number</label><input id="vault-national-id" type="text"></div>
      <div class="form-field"><label for="vault-passport-number">Passport Number</label><input id="vault-passport-number" type="text"></div>
      <div class="form-field"><label for="vault-passport-expiry">Passport Expiry Date</label><input id="vault-passport-expiry" type="date"></div>
      <div class="form-field"><label for="vault-drivers-license">Driver's License Number</label><input id="vault-drivers-license" type="text"></div>
      <div class="form-field"><label for="vault-student-id">Student ID</label><input id="vault-student-id" type="text"></div>
    </div>

    <div class="section-divider"><span>Secure Identity File Upload</span></div>
    <div class="education-upload-dropzone" id="personal-identity-drop-zone">
      <i class="fas fa-file-shield"></i>
      <div>Drag and drop PDF/JPG/PNG files here</div>
      <div class="u-inline-31">Files are validated and stored securely</div>
    </div>
    <div class="form-grid">
      <div class="form-field"><label for="vault-identity-file-type">Document Type</label><select id="vault-identity-file-type"><option value="national_id_scan">National ID Scan</option><option value="passport_scan">Passport Scan</option><option value="certificate">Certificate</option><option value="academic_document">Academic Document</option><option value="other">Other</option></select></div>
      <div class="form-field"><label for="vault-identity-file">Select File</label><input id="vault-identity-file" type="file" accept=".pdf,.jpg,.jpeg,.png"></div>
      <div class="form-field"><label>&nbsp;</label><button class="btn-add" type="button" id="upload-identity-file-btn"><i class="fas fa-upload"></i> Upload File</button></div>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Type</th><th>File</th><th>Updated</th><th>Actions</th></tr></thead>
        <tbody id="vault-identity-files-table"></tbody>
      </table>
    </div>
    <div class="compact-list" id="vault-expiry-alerts"></div>

    <div class="wizard-nav"><button class="btn-outline" type="button" onclick="goPersonalStep(2)">← Back</button><button class="btn-primary u-inline-38" type="button" id="save-step3-btn">Save & Next →</button></div>
  </div>

  <div class="wizard-panel" id="personal-panel-4">
    <div class="card-title u-inline-37">Step 4 — Digital Accounts Registry</div>
    <div class="education-toolbar">
      <input id="vault-account-search" type="text" placeholder="Search platform, username, email...">
      <select id="vault-account-platform-filter"><option value="">All Platforms</option><option value="google">Google</option><option value="github">GitHub</option><option value="linkedin">LinkedIn</option><option value="twitter_x">Twitter / X</option><option value="instagram">Instagram</option><option value="facebook">Facebook</option><option value="tiktok">TikTok</option><option value="discord">Discord</option><option value="reddit">Reddit</option><option value="custom">Custom</option></select>
      <button class="btn-outline" type="button" id="apply-account-filters-btn">Apply</button>
    </div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Platform</th><th>Username</th><th>Email Used</th><th>Profile Link</th><th>Notes</th><th>Actions</th></tr></thead>
        <tbody id="vault-digital-accounts-table"></tbody>
      </table>
    </div>
    <div class="u-inline-40"><button class="btn-add u-inline-41" type="button" id="add-digital-account-btn"><i class="fas fa-plus"></i> Add Account</button></div>
    <div class="wizard-nav"><button class="btn-outline" type="button" onclick="goPersonalStep(3)">← Back</button><button class="btn-primary u-inline-38" type="button" onclick="goPersonalStep(5)">Next →</button></div>
  </div>

  <div class="wizard-panel" id="personal-panel-5">
    <div class="card-title u-inline-37">Step 5 — Public Social Profiles</div>
    <div class="form-grid">
      <div class="form-field"><label for="vault-linkedin">LinkedIn</label><input id="vault-linkedin" type="url" placeholder="https://linkedin.com/in/..." ></div>
      <div class="form-field"><label for="vault-twitter">Twitter / X</label><input id="vault-twitter" type="url" placeholder="https://x.com/..." ></div>
      <div class="form-field"><label for="vault-instagram">Instagram</label><input id="vault-instagram" type="url"></div>
      <div class="form-field"><label for="vault-github">GitHub</label><input id="vault-github" type="url"></div>
      <div class="form-field"><label for="vault-portfolio">Portfolio Website</label><input id="vault-portfolio" type="url"></div>
      <div class="form-field"><label for="vault-blog">Personal Blog</label><input id="vault-blog" type="url"></div>
      <div class="form-field"><label for="vault-youtube">YouTube Channel</label><input id="vault-youtube" type="url"></div>
    </div>
    <div class="section-divider"><span>Preview Links</span></div>
    <div class="compact-list" id="vault-social-preview"></div>
    <div class="wizard-nav"><button class="btn-outline" type="button" onclick="goPersonalStep(4)">← Back</button><button class="btn-primary u-inline-38" type="button" id="save-step5-btn">Save & Next →</button></div>
  </div>

  <div class="wizard-panel" id="personal-panel-6">
    <div class="card-title u-inline-37">Step 6 — Security & Password References</div>
    <div class="alert-banner"><i class="fas fa-lock"></i> For security, actual passwords are never stored. Only reference data and operational hints are allowed.</div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Platform</th><th>Username</th><th>Email Used</th><th>Password Hint</th><th>2FA</th><th>Password Manager</th><th>Actions</th></tr></thead>
        <tbody id="vault-password-references-table"></tbody>
      </table>
    </div>
    <div class="u-inline-40"><button class="btn-add u-inline-41" type="button" id="add-password-reference-btn"><i class="fas fa-plus"></i> Add Password Reference</button></div>
    <div class="wizard-nav"><button class="btn-outline" type="button" onclick="goPersonalStep(5)">← Back</button><button class="btn-primary u-inline-38" type="button" id="save-vault-btn">Save Vault ✓</button></div>
  </div>
</div>

<!-- Digital Account Modal -->
<div class="modal-overlay hidden" id="vault-digital-account-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="vault-digital-account-modal-title">Add Digital Account</div><button class="modal-close" type="button" data-close-modal="vault-digital-account-modal-overlay">×</button></div>
    <form id="vault-digital-account-form" class="modal-form-grid">
      <input type="hidden" id="vault-digital-account-id">
      <div class="form-field"><label for="vault-account-platform">Platform</label><select id="vault-account-platform"><option value="google">Google</option><option value="github">GitHub</option><option value="linkedin">LinkedIn</option><option value="twitter_x">Twitter / X</option><option value="instagram">Instagram</option><option value="facebook">Facebook</option><option value="tiktok">TikTok</option><option value="discord">Discord</option><option value="reddit">Reddit</option><option value="custom">Custom</option></select></div>
      <div class="form-field"><label for="vault-account-custom-platform">Custom Platform Name</label><input id="vault-account-custom-platform" type="text"></div>
      <div class="form-field"><label for="vault-account-username">Username</label><input id="vault-account-username" type="text"></div>
      <div class="form-field"><label for="vault-account-email">Email Used</label><input id="vault-account-email" type="email"></div>
      <div class="form-field modal-span-2"><label for="vault-account-profile-link">Profile Link</label><input id="vault-account-profile-link" type="url"></div>
      <div class="form-field modal-span-2"><label for="vault-account-notes">Notes</label><textarea id="vault-account-notes"></textarea></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="vault-digital-account-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Account</button></div>
    </form>
  </div>
</div>

<!-- Password Reference Modal -->
<div class="modal-overlay hidden" id="vault-password-reference-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="vault-password-reference-modal-title">Add Password Reference</div><button class="modal-close" type="button" data-close-modal="vault-password-reference-modal-overlay">×</button></div>
    <form id="vault-password-reference-form" class="modal-form-grid">
      <input type="hidden" id="vault-password-reference-id">
      <div class="form-field"><label for="vault-ref-platform">Platform</label><input id="vault-ref-platform" type="text"></div>
      <div class="form-field"><label for="vault-ref-username">Username</label><input id="vault-ref-username" type="text"></div>
      <div class="form-field"><label for="vault-ref-email">Email Used</label><input id="vault-ref-email" type="email"></div>
      <div class="form-field"><label for="vault-ref-password-hint">Password Hint</label><input id="vault-ref-password-hint" type="text"></div>
      <div class="form-field"><label for="vault-ref-two-factor">Two-Factor Enabled</label><select id="vault-ref-two-factor"><option value="0">No</option><option value="1">Yes</option></select></div>
      <div class="form-field"><label for="vault-ref-password-manager">Password Manager Used</label><select id="vault-ref-password-manager"><option value="bitwarden">Bitwarden</option><option value="1password">1Password</option><option value="proton_pass">Proton Pass</option><option value="other">Other</option></select></div>
      <div class="form-field modal-span-2"><label for="vault-ref-backup-location">Backup Codes Location</label><input id="vault-ref-backup-location" type="text"></div>
      <div class="form-field modal-span-2"><label for="vault-ref-notes">Notes</label><textarea id="vault-ref-notes"></textarea></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="vault-password-reference-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Reference</button></div>
    </form>
  </div>
</div>
{% endblock %}

```

---

## myos_project/myos_app/templates/projects.html

- Size: 3828 bytes
- Lines: 62
- Modified: 2026-03-06 21:32:04
- SHA256: 4ae66844a576ef3944b70fa5f9e3a90a83362e60df5df399d030a4ae6aa6b8b9
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Projects{% endblock %}

{% block page_content %}
<div class="page-header"><div><div class="page-title">Projects</div><div class="page-title-sub">Business ideas, coding projects and creative endeavours</div></div><button class="btn-add" type="button" id="add-project-btn"><i class="fas fa-plus"></i> New Project</button></div>
<div class="tab-bar">
  <button class="tab-btn active" onclick="switchTab('prj','overview')">All Projects</button>
  <button class="tab-btn" onclick="switchTab('prj','tasks')">Tasks &amp; Milestones</button>
  <button class="tab-btn" onclick="switchTab('prj','analytics')">Analytics</button>
</div>

<div class="tab-panel active" id="prj-overview">
  <div class="cards-grid" id="projects-grid">
    <div class="dash-card"><div class="table-empty">No projects have been created yet.</div></div>
  </div>
</div>

<div class="tab-panel" id="prj-tasks">
  <div class="dash-card">
    <div class="card-title u-inline-37">Project Tasks &amp; Milestones</div>
    <div class="u-inline-25">
      <div class="u-inline-78" id="project-milestones-list">
        <div class="table-empty">No milestones available.</div>
      </div>
    </div>
    <div class="section-divider"><span>Timeline (Gantt)</span></div>
    <div class="u-inline-25" id="project-timeline-list">
      <div class="table-empty">No timeline data available.</div>
    </div>
  </div>
</div>

<div class="tab-panel" id="prj-analytics">
  <div class="split-grid">
    <div class="dash-card chart-card">
      <div class="card-header"><div class="card-title">Project Activity (Bar)</div><div class="mood-badge">Last 6 months</div></div>
      <div class="chart-canvas-wrap"><canvas id="projects-activity-chart" aria-label="Project monthly activity bar chart"></canvas></div>
    </div>
    <div class="dash-card chart-card">
      <div class="card-header"><div class="card-title">Project Status (Pie)</div><a class="u-inline-24" href="{% url 'finance' %}#finance-analytics">Open analytics →</a></div>
      <div class="chart-canvas-wrap"><canvas id="projects-status-chart" aria-label="Project status pie chart"></canvas></div>
    </div>
  </div>
</div>

<div class="modal-overlay hidden" id="project-modal-overlay">
  <div class="modal-card">
    <div class="modal-header"><div class="card-title" id="project-modal-title">Add Project</div><button class="modal-close" type="button" data-close-modal="project-modal-overlay">×</button></div>
    <form id="project-form" class="modal-form-grid">
      <input type="hidden" id="project-id">
      <div class="form-field modal-span-2"><label for="project-title">Project Title</label><input id="project-title" type="text" required></div>
      <div class="form-field modal-span-2"><label for="project-description">Description</label><textarea id="project-description"></textarea></div>
      <div class="form-field"><label for="project-status">Status</label><select id="project-status"><option value="idea">Idea</option><option value="pending">Pending</option><option value="in_progress">In Progress</option><option value="completed">Completed</option></select></div>
      <div class="form-field"><label for="project-progress">Progress (%)</label><input id="project-progress" type="number" min="0" max="100" step="1" value="0"></div>
      <div class="form-field"><label for="project-start-date">Start Date</label><input id="project-start-date" type="date"></div>
      <div class="form-field"><label for="project-end-date">End Date</label><input id="project-end-date" type="date"></div>
      <div class="modal-actions modal-span-2"><button class="btn-outline" type="button" data-close-modal="project-modal-overlay">Cancel</button><button class="btn-primary" type="submit">Save Project</button></div>
    </form>
  </div>
</div>
{% endblock %}

```

---

## myos_project/myos_app/templates/settings.html

- Size: 2659 bytes
- Lines: 12
- Modified: 2026-03-06 21:04:34
- SHA256: a636c8548f8af226b81022bce01fc9c864615b995244993928c75941d2988175
- MIME: text/plain

```
{% extends 'base.html' %}

{% block title %}MyOS — Settings{% endblock %}

{% block page_content %}
<div class="page-header"><div><div class="page-title">Settings</div><div class="page-title-sub">Preferences, account and system configuration</div></div></div>
<div class="dash-grid">
  <div class="dash-card"><div class="card-title u-inline-83">Account</div><div class="form-grid u-inline-107"><div class="form-field"><label for="settings-display-name">Display Name</label><input id="settings-display-name" type="text" aria-label="Display Name"></div><div class="form-field"><label for="settings-email">Email</label><input id="settings-email" type="email" aria-label="Email"></div><div class="form-field"><label for="settings-timezone">Timezone</label><input id="settings-timezone" type="text" aria-label="Timezone" placeholder="UTC"></div></div><div class="u-inline-40"><button class="btn-primary u-inline-108" onclick="saveProfileSettings()">Save Changes</button></div></div>
  <div class="dash-card"><div class="card-title u-inline-83">Notifications</div><div class="u-inline-9"><div class="checkbox-row"><input id="notif-scholarship" type="checkbox" checked aria-label="Scholarship deadline reminders" onchange="saveNotificationSettings()"><span>Scholarship deadline reminders</span></div><div class="checkbox-row"><input id="notif-tasks" type="checkbox" checked aria-label="Task due date alerts" onchange="saveNotificationSettings()"><span>Task due date alerts</span></div><div class="checkbox-row"><input id="notif-diary" type="checkbox" aria-label="Diary daily prompt" onchange="saveNotificationSettings()"><span>Diary daily prompt</span></div><div class="checkbox-row"><input id="notif-finance" type="checkbox" checked aria-label="Finance budget alerts" onchange="saveNotificationSettings()"><span>Finance budget alerts</span></div></div></div>
  <div class="dash-card"><div class="card-title u-inline-83">Security</div><div class="form-grid u-inline-107"><div class="form-field"><label>Current Password</label><input type="password" placeholder="********" aria-label="Current Password"></div><div class="form-field"><label>New Password</label><input type="password" placeholder="********" aria-label="New Password"></div><div class="form-field"><label>Confirm Password</label><input type="password" placeholder="********" aria-label="Confirm Password"></div></div><div class="checkbox-row u-inline-7"><input type="checkbox" aria-label="Two-factor authentication enabled"><span>Two-factor authentication enabled</span></div><div class="u-inline-40"><button class="btn-primary u-inline-108">Update Password</button></div></div>
</div>
{% endblock %}

```

---

## myos_project/myos_app/tests.py

- Size: 11594 bytes
- Lines: 297
- Modified: 2026-03-06 21:34:51
- SHA256: 2cf71d66c859329abaebbba9f75c3762dfbe151ba9e19f97b832513735445424
- MIME: text/x-script.python

```
import json
from datetime import date
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import IntegrityError
from django.test import Client, TestCase
from django.urls import reverse

from .models import Budget, Category, DigitalAccounts, IdentityDocuments, Project, Transaction


class FinanceModelTests(TestCase):
    def setUp(self):
        self.category = Category.objects.create(
            name="Living",
            slug="living-test",
            kind=Category.KIND_EXPENSE,
            color="#8B5A2B",
            icon="fa-house",
        )

    def test_transaction_amount_must_be_positive(self):
        tx = Transaction(
            tx_date=date.today(),
            description="Invalid amount",
            category=self.category,
            account=Transaction.ACCOUNT_BANK,
            tx_type=Transaction.TYPE_EXPENSE,
            amount=Decimal("-5.00"),
        )
        with self.assertRaises(ValidationError):
            tx.full_clean()

    def test_budget_unique_per_category_and_month(self):
        month_start = date.today().replace(day=1)
        Budget.objects.create(category=self.category, period_start=month_start, monthly_limit=Decimal("1000.00"))
        with self.assertRaises(IntegrityError):
            Budget.objects.create(category=self.category, period_start=month_start, monthly_limit=Decimal("2000.00"))


class FinanceApiTests(TestCase):
    def setUp(self):
        self.client = Client()

    def test_finance_bootstrap_is_accessible(self):
        response = self.client.get(reverse("finance_bootstrap"))
        self.assertEqual(response.status_code, 200)

    def test_finance_bootstrap_returns_expected_sections(self):
        response = self.client.get(reverse("finance_bootstrap"))
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertTrue(payload.get("ok"))
        self.assertGreaterEqual(len(payload.get("metrics", [])), 9)
        self.assertIn("ledger", payload)
        self.assertIn("charts", payload)
        self.assertIn("alerts", payload)
        self.assertIn("insights", payload)

    def test_csv_export_uses_filters(self):
        category = Category.objects.create(
            name="CSV Category",
            slug="csv-category",
            kind=Category.KIND_EXPENSE,
            color="#8B5A2B",
            icon="fa-tag",
        )

        Transaction.objects.create(
            tx_date=date.today(),
            description="CSV Match Item",
            category=category,
            account=Transaction.ACCOUNT_BANK,
            tx_type=Transaction.TYPE_EXPENSE,
            amount=Decimal("123.00"),
        )
        Transaction.objects.create(
            tx_date=date.today(),
            description="CSV Other Item",
            category=category,
            account=Transaction.ACCOUNT_BANK,
            tx_type=Transaction.TYPE_EXPENSE,
            amount=Decimal("77.00"),
        )

        response = self.client.get(reverse("finance_transactions_export_csv"), {"q": "Match"})
        self.assertEqual(response.status_code, 200)
        content = response.content.decode("utf-8")
        self.assertIn("CSV Match Item", content)
        self.assertNotIn("CSV Other Item", content)


class EducationApiTests(TestCase):
    def setUp(self):
        self.client = Client()

    def test_education_bootstrap_is_accessible(self):
        response = self.client.get(reverse("education_bootstrap"))
        self.assertEqual(response.status_code, 200)

    def test_education_bootstrap_returns_sections(self):
        response = self.client.get(reverse("education_bootstrap"))
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertTrue(payload.get("ok"))
        self.assertIn("academic_levels", payload)
        self.assertIn("documents", payload)
        self.assertIn("scholarships", payload)
        self.assertIn("deadline_alerts", payload)

    def test_document_create_and_scholarship_create(self):
        self.client.get(reverse("education_bootstrap"))

        sample = SimpleUploadedFile("statement.pdf", b"fake-pdf-content", content_type="application/pdf")
        response = self.client.post(
            reverse("education_documents_create"),
            data={
                "title": "Personal Statement",
                "document_type": "personal_statement",
                "version": "v1",
                "notes": "Draft",
                "file": sample,
            },
        )
        self.assertEqual(response.status_code, 201)
        self.assertTrue(response.json().get("ok"))

        response2 = self.client.post(
            reverse("education_scholarships_create"),
            data=json.dumps(
                {
                    "name": "Test Scholarship",
                    "country": "Germany",
                    "field_of_study": "Engineering",
                    "degree_level": "Masters",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response2.status_code, 201)
        self.assertTrue(response2.json().get("ok"))


class PersonalVaultApiTests(TestCase):
    def setUp(self):
        self.client = Client()

    def test_personal_vault_bootstrap_is_accessible(self):
        response = self.client.get(reverse("personal_vault_bootstrap"))
        self.assertEqual(response.status_code, 200)

    def test_step3_encryption_and_bootstrap_roundtrip(self):
        payload = {
            "national_id": "12345678",
            "passport_number": "A1234567",
            "passport_expiry": "2030-12-31",
            "drivers_license": "DL-7777",
            "student_id": "ST-1001",
        }
        response = self.client.post(
            reverse("personal_vault_step3_save"),
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        docs = IdentityDocuments.objects.first()
        self.assertIsNotNone(docs)
        self.assertNotEqual(docs.national_id_encrypted, payload["national_id"])
        self.assertNotEqual(docs.passport_number_encrypted, payload["passport_number"])
        self.assertTrue(docs.national_id_encrypted)
        self.assertTrue(docs.passport_number_encrypted)

        bootstrap = self.client.get(reverse("personal_vault_bootstrap"))
        self.assertEqual(bootstrap.status_code, 200)
        identity_docs = bootstrap.json().get("identity_documents", {})
        self.assertEqual(identity_docs.get("national_id"), payload["national_id"])
        self.assertEqual(identity_docs.get("passport_number"), payload["passport_number"])

    def test_digital_account_crud(self):
        create_response = self.client.post(
            reverse("personal_vault_digital_accounts_create"),
            data=json.dumps(
                {
                    "platform": "github",
                    "custom_platform": "",
                    "username": "immanuel",
                    "email_used": "immanuel@example.com",
                    "profile_link": "https://github.com/immanuel",
                    "notes": "Main dev profile",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(create_response.status_code, 201)
        account_id = create_response.json()["account"]["id"]
        self.assertEqual(DigitalAccounts.objects.count(), 1)

        update_response = self.client.post(
            reverse("personal_vault_digital_accounts_update", kwargs={"account_id": account_id}),
            data=json.dumps(
                {
                    "platform": "github",
                    "custom_platform": "",
                    "username": "immanuel-updated",
                    "email_used": "immanuel@example.com",
                    "profile_link": "https://github.com/immanuel-updated",
                    "notes": "Updated",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(update_response.status_code, 200)
        self.assertEqual(update_response.json()["account"]["username"], "immanuel-updated")

        list_response = self.client.get(reverse("personal_vault_digital_accounts"))
        self.assertEqual(list_response.status_code, 200)
        self.assertEqual(len(list_response.json().get("rows", [])), 1)

        delete_response = self.client.post(
            reverse("personal_vault_digital_accounts_delete", kwargs={"account_id": account_id}),
            data=json.dumps({}),
            content_type="application/json",
        )
        self.assertEqual(delete_response.status_code, 200)
        self.assertEqual(DigitalAccounts.objects.count(), 0)

    def test_identity_file_upload_rejects_invalid_type(self):
        bad_file = SimpleUploadedFile("secret.exe", b"MZ-binary", content_type="application/octet-stream")
        response = self.client.post(
            reverse("personal_vault_identity_file_upload"),
            data={
                "file_type": "other",
                "file": bad_file,
            },
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("Unsupported file type", response.json().get("error", ""))


class ProjectsApiTests(TestCase):
    def setUp(self):
        self.client = Client()

    def test_page_render_sets_csrf_cookie(self):
        csrf_client = Client(enforce_csrf_checks=True)
        response = csrf_client.get(reverse("education"))
        self.assertEqual(response.status_code, 200)
        self.assertIn("csrftoken", csrf_client.cookies)

    def test_project_crud(self):
        create_response = self.client.post(
            reverse("projects_create"),
            data=json.dumps(
                {
                    "title": "Build MVP",
                    "description": "First production-ready release",
                    "status": "in_progress",
                    "progress": 35,
                    "start_date": "2026-03-01",
                    "end_date": "2026-06-30",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(create_response.status_code, 201)
        self.assertTrue(create_response.json().get("ok"))
        project_id = create_response.json()["project"]["id"]
        self.assertEqual(Project.objects.count(), 1)

        list_response = self.client.get(reverse("projects_list"))
        self.assertEqual(list_response.status_code, 200)
        self.assertEqual(len(list_response.json().get("rows", [])), 1)

        update_response = self.client.post(
            reverse("projects_update", kwargs={"project_id": project_id}),
            data=json.dumps(
                {
                    "title": "Build MVP v2",
                    "status": "completed",
                    "progress": 100,
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(update_response.status_code, 200)
        self.assertEqual(update_response.json()["project"]["status"], "completed")
        self.assertEqual(update_response.json()["project"]["progress"], 100)

        delete_response = self.client.post(
            reverse("projects_delete", kwargs={"project_id": project_id}),
            data=json.dumps({}),
            content_type="application/json",
        )
        self.assertEqual(delete_response.status_code, 200)
        self.assertEqual(Project.objects.count(), 0)

```

---

## myos_project/myos_app/urls.py

- Size: 11219 bytes
- Lines: 124
- Modified: 2026-03-06 21:50:27
- SHA256: f46a7bd7c7869551fc5d9805867724c68bc531a04ecdcb1be4117cde5c681a17
- MIME: text/x-script.python

```
from django.urls import path
from myos_app import views

urlpatterns = [
    path("", views.dashboard_page, name="dashboard"),
    path("home/", views.home, name="home"),
    path("personal/", views.personal_page, name="personal"),
    path("education/", views.education_page, name="education"),
    path("finance/", views.finance_page, name="finance"),
    path("bucket/", views.bucket_page, name="bucket"),
    path("projects/", views.projects_page, name="projects"),
    path("diary/", views.diary_page, name="diary"),
    path("settings/", views.settings_page, name="settings"),

    path("api/projects/", views.projects_list, name="projects_list"),
    path("api/projects/create/", views.projects_create, name="projects_create"),
    path("api/projects/<int:project_id>/update/", views.projects_update, name="projects_update"),
    path("api/projects/<int:project_id>/delete/", views.projects_delete, name="projects_delete"),

    path("api/bootstrap/", views.bootstrap_data, name="bootstrap_data"),
    path("api/tasks/create/", views.create_task, name="create_task"),
    path("api/tasks/<int:task_id>/toggle/", views.toggle_task, name="toggle_task"),
    path("api/diary/save/", views.save_diary_entry, name="save_diary_entry"),
    path("api/profile/save/", views.save_profile, name="save_profile"),
    path("api/notifications/save/", views.save_notifications, name="save_notifications"),
    path("api/forms/<slug:page_slug>/", views.get_page_form_data, name="get_page_form_data"),
    path("api/forms/<slug:page_slug>/save/", views.save_page_form_data, name="save_page_form_data"),
    path("api/uploads/<slug:page_slug>/", views.list_uploaded_files, name="list_uploaded_files"),
    path("api/uploads/<slug:page_slug>/<slug:field_key>/", views.upload_file_for_field, name="upload_file_for_field"),

    path("api/personal-vault/bootstrap/", views.personal_vault_bootstrap, name="personal_vault_bootstrap"),
    path("api/personal-vault/step1/save/", views.personal_vault_step1_save, name="personal_vault_step1_save"),
    path("api/personal-vault/step2/save/", views.personal_vault_step2_save, name="personal_vault_step2_save"),
    path("api/personal-vault/step3/save/", views.personal_vault_step3_save, name="personal_vault_step3_save"),
    path("api/personal-vault/identity-files/", views.personal_vault_identity_files, name="personal_vault_identity_files"),
    path("api/personal-vault/identity-files/upload/", views.personal_vault_identity_file_upload, name="personal_vault_identity_file_upload"),
    path("api/personal-vault/identity-files/<int:file_id>/delete/", views.personal_vault_identity_file_delete, name="personal_vault_identity_file_delete"),
    path("api/personal-vault/digital-accounts/", views.personal_vault_digital_accounts, name="personal_vault_digital_accounts"),
    path("api/personal-vault/digital-accounts/create/", views.personal_vault_digital_accounts_create, name="personal_vault_digital_accounts_create"),
    path("api/personal-vault/digital-accounts/<int:account_id>/update/", views.personal_vault_digital_accounts_update, name="personal_vault_digital_accounts_update"),
    path("api/personal-vault/digital-accounts/<int:account_id>/delete/", views.personal_vault_digital_accounts_delete, name="personal_vault_digital_accounts_delete"),
    path("api/personal-vault/social-profiles/save/", views.personal_vault_social_profiles_save, name="personal_vault_social_profiles_save"),
    path("api/personal-vault/password-references/", views.personal_vault_password_references, name="personal_vault_password_references"),
    path("api/personal-vault/password-references/create/", views.personal_vault_password_references_create, name="personal_vault_password_references_create"),
    path("api/personal-vault/password-references/<int:reference_id>/update/", views.personal_vault_password_references_update, name="personal_vault_password_references_update"),
    path("api/personal-vault/password-references/<int:reference_id>/delete/", views.personal_vault_password_references_delete, name="personal_vault_password_references_delete"),

    path("api/finance/bootstrap/", views.finance_bootstrap, name="finance_bootstrap"),

    path("api/finance/transactions/", views.finance_transactions, name="finance_transactions"),
    path("api/finance/transactions/create/", views.finance_transactions_create, name="finance_transactions_create"),
    path("api/finance/transactions/<int:transaction_id>/update/", views.finance_transactions_update, name="finance_transactions_update"),
    path("api/finance/transactions/<int:transaction_id>/delete/", views.finance_transactions_delete, name="finance_transactions_delete"),
    path("api/finance/transactions/export.csv", views.finance_transactions_export_csv, name="finance_transactions_export_csv"),

    path("api/finance/categories/", views.finance_categories, name="finance_categories"),
    path("api/finance/categories/create/", views.finance_categories_create, name="finance_categories_create"),
    path("api/finance/categories/<int:category_id>/update/", views.finance_categories_update, name="finance_categories_update"),
    path("api/finance/categories/<int:category_id>/delete/", views.finance_categories_delete, name="finance_categories_delete"),

    path("api/finance/budgets/", views.finance_budgets, name="finance_budgets"),
    path("api/finance/budgets/create/", views.finance_budgets_create, name="finance_budgets_create"),
    path("api/finance/budgets/<int:budget_id>/update/", views.finance_budgets_update, name="finance_budgets_update"),
    path("api/finance/budgets/<int:budget_id>/delete/", views.finance_budgets_delete, name="finance_budgets_delete"),

    path("api/finance/savings-goals/", views.finance_savings_goals, name="finance_savings_goals"),
    path("api/finance/savings-goals/create/", views.finance_savings_goals_create, name="finance_savings_goals_create"),
    path("api/finance/savings-goals/<int:goal_id>/update/", views.finance_savings_goals_update, name="finance_savings_goals_update"),
    path("api/finance/savings-goals/<int:goal_id>/delete/", views.finance_savings_goals_delete, name="finance_savings_goals_delete"),

    path("api/finance/application-costs/", views.finance_application_costs, name="finance_application_costs"),
    path("api/finance/application-costs/create/", views.finance_application_costs_create, name="finance_application_costs_create"),
    path("api/finance/application-costs/<int:cost_id>/update/", views.finance_application_costs_update, name="finance_application_costs_update"),
    path("api/finance/application-costs/<int:cost_id>/delete/", views.finance_application_costs_delete, name="finance_application_costs_delete"),

    path("api/finance/project-budgets/", views.finance_project_budgets, name="finance_project_budgets"),
    path("api/finance/project-budgets/create/", views.finance_project_budgets_create, name="finance_project_budgets_create"),
    path("api/finance/project-budgets/<int:project_budget_id>/update/", views.finance_project_budgets_update, name="finance_project_budgets_update"),
    path("api/finance/project-budgets/<int:project_budget_id>/delete/", views.finance_project_budgets_delete, name="finance_project_budgets_delete"),

    path("api/finance/recurring/", views.finance_recurring, name="finance_recurring"),
    path("api/finance/recurring/create/", views.finance_recurring_create, name="finance_recurring_create"),
    path("api/finance/recurring/<int:recurring_id>/update/", views.finance_recurring_update, name="finance_recurring_update"),
    path("api/finance/recurring/<int:recurring_id>/delete/", views.finance_recurring_delete, name="finance_recurring_delete"),
    path("api/finance/forecast/", views.finance_forecast, name="finance_forecast"),
    path("api/finance/recurring/<int:recurring_id>/apply-now/", views.finance_recurring_apply_now, name="finance_recurring_apply_now"),

    path("api/finance/alerts/", views.finance_alerts, name="finance_alerts"),
    path("api/finance/alerts/<int:alert_id>/mark-read/", views.finance_alert_mark_read, name="finance_alert_mark_read"),
    path("api/finance/alerts/mark-all-read/", views.finance_alert_mark_all_read, name="finance_alert_mark_all_read"),

    path("api/education/bootstrap/", views.education_bootstrap, name="education_bootstrap"),

    path("api/education/levels/", views.education_levels, name="education_levels"),
    path("api/education/levels/create/", views.education_levels_create, name="education_levels_create"),
    path("api/education/levels/<int:level_id>/update/", views.education_levels_update, name="education_levels_update"),
    path("api/education/levels/<int:level_id>/delete/", views.education_levels_delete, name="education_levels_delete"),

    path("api/education/exams/", views.education_exams, name="education_exams"),
    path("api/education/exams/create/", views.education_exams_create, name="education_exams_create"),
    path("api/education/exams/<int:exam_id>/update/", views.education_exams_update, name="education_exams_update"),
    path("api/education/exams/<int:exam_id>/delete/", views.education_exams_delete, name="education_exams_delete"),

    path("api/education/documents/", views.education_documents, name="education_documents"),
    path("api/education/documents/create/", views.education_documents_create, name="education_documents_create"),
    path("api/education/documents/<int:document_id>/update/", views.education_documents_update, name="education_documents_update"),
    path("api/education/documents/<int:document_id>/delete/", views.education_documents_delete, name="education_documents_delete"),

    path("api/education/scholarships/", views.education_scholarships, name="education_scholarships"),
    path("api/education/scholarships/create/", views.education_scholarships_create, name="education_scholarships_create"),
    path("api/education/scholarships/<int:scholarship_id>/update/", views.education_scholarships_update, name="education_scholarships_update"),
    path("api/education/scholarships/<int:scholarship_id>/delete/", views.education_scholarships_delete, name="education_scholarships_delete"),

    path("api/education/requirements/create/", views.education_requirements_create, name="education_requirements_create"),
    path("api/education/requirements/<int:requirement_id>/update/", views.education_requirements_update, name="education_requirements_update"),
    path("api/education/requirements/<int:requirement_id>/delete/", views.education_requirements_delete, name="education_requirements_delete"),
    path("api/education/requirements/<int:requirement_id>/toggle/", views.education_requirements_toggle, name="education_requirements_toggle"),

    path("api/education/applications/create/", views.education_applications_create, name="education_applications_create"),
    path("api/education/applications/<int:application_id>/update/", views.education_applications_update, name="education_applications_update"),
    path("api/education/applications/<int:application_id>/delete/", views.education_applications_delete, name="education_applications_delete"),

    path("api/education/deadline-alerts/", views.education_deadline_alerts, name="education_deadline_alerts"),
]

```

---

## myos_project/myos_app/views.py

- Size: 124752 bytes
- Lines: 3332
- Modified: 2026-03-06 21:31:32
- SHA256: 0ccafa0a6352c852dfa6e5b673de02297ecba84923c137444df07dd6f3e538c5
- MIME: text/x-script.python

```
import csv
import json
import re
import base64
import hashlib
import hmac
import os
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

from django.conf import settings
from django.core.paginator import Paginator
from django.db.models import Sum
from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_GET, require_POST

from .models import (
    AcademicLevel,
    ApplicationDocument,
    ApplicationCost,
    Budget,
    Category,
    ContactInfo,
    DigitalAccounts,
    DiaryEntry,
    ExamCertification,
    FinanceAlert,
    IdentityDocuments,
    IdentityUploadedFile,
    NotificationPreference,
    PageFormData,
    PasswordReferences,
    PersonalIdentityVault,
    Project,
    ProjectBudget,
    RecurringExpenseTemplate,
    SavingsGoal,
    Scholarship,
    ScholarshipApplication,
    ScholarshipRequirement,
    SocialProfiles,
    Task,
    Transaction,
    UploadedDocument,
    UserProfile,
)


def _render_page(request, template_name, active_page):
    # Ensure AJAX POST endpoints always have a CSRF cookie available in browser sessions.
    get_token(request)
    return render(
        request,
        template_name,
        {
            "active_page": active_page,
        },
    )


ALLOWED_UPLOAD_EXTENSIONS = {
    ".pdf",
    ".png",
    ".jpg",
    ".jpeg",
    ".doc",
    ".docx",
    ".txt",
}
MAX_UPLOAD_SIZE_BYTES = 10 * 1024 * 1024


def _require_finance_access(request):
    return None


def _require_education_access(request):
    return None


def _require_personal_vault_access(request):
    return None


def _clean_page_slug(page_slug):
    if not re.fullmatch(r"[a-z0-9_-]{2,50}", page_slug or ""):
        return None
    return page_slug


def _clean_field_key(field_key):
    if not re.fullmatch(r"[a-z0-9_-]{2,80}", field_key or ""):
        return None
    return field_key


def _upload_to_dict(upload):
    return {
        "id": upload.id,
        "page_slug": upload.page_slug,
        "field_key": upload.field_key,
        "label": upload.label,
        "original_name": upload.original_name,
        "content_type": upload.content_type,
        "file_size": upload.file_size,
        "url": upload.file.url if upload.file else "",
        "uploaded_at": upload.uploaded_at.isoformat(),
    }


def home(request):
    return _render_page(request, "dashboard.html", "dashboard")


def dashboard_page(request):
    return _render_page(request, "dashboard.html", "dashboard")


def personal_page(request):
    return _render_page(request, "personal.html", "personal")


def education_page(request):
    return _render_page(request, "education.html", "education")


def finance_page(request):
    return _render_page(request, "finance.html", "finance")


def media_page(request):
    return _render_page(request, "media.html", "media")


def bucket_page(request):
    return _render_page(request, "bucket.html", "bucket")


def projects_page(request):
    return _render_page(request, "projects.html", "projects")


def diary_page(request):
    return _render_page(request, "diary.html", "diary")


def settings_page(request):
    return _render_page(request, "settings.html", "settings")


def _ensure_core_records():
    profile, _ = UserProfile.objects.get_or_create(
        id=1,
        defaults={
            "display_name": "",
            "email": "",
            "timezone": settings.TIME_ZONE,
        },
    )
    notifications, _ = NotificationPreference.objects.get_or_create(id=1)
    return profile, notifications


def _parse_json(request):
    try:
        return json.loads(request.body.decode("utf-8")) if request.body else {}
    except json.JSONDecodeError:
        return {}


def _validate_uploaded_file(uploaded_file):
    if uploaded_file is None:
        return "No file was provided"
    if uploaded_file.size > MAX_UPLOAD_SIZE_BYTES:
        return "File is too large. Maximum size is 10MB"

    extension = Path(uploaded_file.name).suffix.lower()
    if extension not in ALLOWED_UPLOAD_EXTENSIONS:
        return "Unsupported file type"

    return None


def _task_to_dict(task):
    return {"id": task.id, "title": task.title, "is_done": task.is_done, "sort_order": task.sort_order}


def _entry_to_dict(entry):
    return {
        "id": entry.id,
        "entry_date": entry.entry_date.isoformat(),
        "mood": entry.mood,
        "content": entry.content,
        "achievements": entry.achievements,
        "lessons": entry.lessons,
        "ideas": entry.ideas,
        "created_at": entry.created_at.isoformat(),
    }


@require_GET
def bootstrap_data(request):
    profile, notifications = _ensure_core_records()
    tasks = [_task_to_dict(task) for task in Task.objects.all()]
    diary_entries = [_entry_to_dict(entry) for entry in DiaryEntry.objects.all()[:12]]
    return JsonResponse(
        {
            "profile": {
                "display_name": profile.display_name,
                "email": profile.email,
                "timezone": profile.timezone,
            },
            "notifications": {
                "scholarship_deadlines": notifications.scholarship_deadlines,
                "task_due_alerts": notifications.task_due_alerts,
                "diary_prompt": notifications.diary_prompt,
                "finance_alerts": notifications.finance_alerts,
            },
            "tasks": tasks,
            "diary_entries": diary_entries,
        }
    )


@require_POST
def toggle_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.is_done = not task.is_done
    task.save(update_fields=["is_done", "updated_at"])
    return JsonResponse({"ok": True, "task": _task_to_dict(task)})


@require_POST
def create_task(request):
    payload = _parse_json(request)
    title = (payload.get("title") or "").strip()
    if not title:
        return JsonResponse({"ok": False, "error": "Task title is required"}, status=400)
    max_order = Task.objects.order_by("-sort_order").values_list("sort_order", flat=True).first() or 0
    task = Task.objects.create(title=title, sort_order=max_order + 1)
    return JsonResponse({"ok": True, "task": _task_to_dict(task)}, status=201)


@require_POST
def save_diary_entry(request):
    payload = _parse_json(request)
    entry = DiaryEntry.objects.create(
        entry_date=date.today(),
        mood=(payload.get("mood") or "").strip(),
        content=(payload.get("content") or "").strip(),
        achievements=(payload.get("achievements") or "").strip(),
        lessons=(payload.get("lessons") or "").strip(),
        ideas=(payload.get("ideas") or "").strip(),
    )
    return JsonResponse({"ok": True, "entry": _entry_to_dict(entry)}, status=201)


@require_POST
def save_profile(request):
    payload = _parse_json(request)
    profile, _ = UserProfile.objects.get_or_create(id=1)
    profile.display_name = (payload.get("display_name") or profile.display_name).strip()
    profile.email = (payload.get("email") or profile.email).strip()
    profile.timezone = (payload.get("timezone") or profile.timezone).strip()
    profile.save()
    return JsonResponse({"ok": True})


@require_POST
def save_notifications(request):
    payload = _parse_json(request)
    prefs, _ = NotificationPreference.objects.get_or_create(id=1)
    prefs.scholarship_deadlines = bool(payload.get("scholarship_deadlines"))
    prefs.task_due_alerts = bool(payload.get("task_due_alerts"))
    prefs.diary_prompt = bool(payload.get("diary_prompt"))
    prefs.finance_alerts = bool(payload.get("finance_alerts"))
    prefs.save()
    return JsonResponse({"ok": True})


def _serialize_project(item):
    return {
        "id": item.id,
        "title": item.title,
        "description": item.description,
        "status": item.status,
        "progress": item.progress,
        "start_date": item.start_date.isoformat() if item.start_date else None,
        "end_date": item.end_date.isoformat() if item.end_date else None,
        "updated_at": item.updated_at.isoformat(),
    }


@require_GET
def projects_list(request):
    rows = [_serialize_project(item) for item in Project.objects.all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def projects_create(request):
    payload = _parse_json(request)
    title = (payload.get("title") or "").strip()
    if not title:
        return JsonResponse({"ok": False, "error": "Project title is required"}, status=400)

    status = (payload.get("status") or Project.STATUS_IDEA).strip()
    valid_statuses = {choice[0] for choice in Project.STATUS_CHOICES}
    if status not in valid_statuses:
        return JsonResponse({"ok": False, "error": "Invalid project status"}, status=400)

    try:
        progress = int(payload.get("progress", 0))
    except (TypeError, ValueError):
        progress = 0
    progress = max(0, min(100, progress))

    item = Project.objects.create(
        title=title,
        description=(payload.get("description") or "").strip(),
        status=status,
        progress=progress,
        start_date=_parse_date(payload.get("start_date")),
        end_date=_parse_date(payload.get("end_date")),
    )
    return JsonResponse({"ok": True, "project": _serialize_project(item)}, status=201)


@require_POST
def projects_update(request, project_id):
    item = get_object_or_404(Project, id=project_id)
    payload = _parse_json(request)

    title = (payload.get("title") or item.title).strip()
    if not title:
        return JsonResponse({"ok": False, "error": "Project title is required"}, status=400)

    status = (payload.get("status") or item.status).strip()
    valid_statuses = {choice[0] for choice in Project.STATUS_CHOICES}
    if status not in valid_statuses:
        return JsonResponse({"ok": False, "error": "Invalid project status"}, status=400)

    try:
        progress = int(payload.get("progress", item.progress))
    except (TypeError, ValueError):
        progress = item.progress
    progress = max(0, min(100, progress))

    item.title = title
    item.description = (payload.get("description") if "description" in payload else item.description or "").strip()
    item.status = status
    item.progress = progress
    if "start_date" in payload:
        item.start_date = _parse_date(payload.get("start_date"))
    if "end_date" in payload:
        item.end_date = _parse_date(payload.get("end_date"))
    item.save()
    return JsonResponse({"ok": True, "project": _serialize_project(item)})


@require_POST
def projects_delete(request, project_id):
    item = get_object_or_404(Project, id=project_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def get_page_form_data(request, page_slug):
    clean_slug = _clean_page_slug(page_slug)
    if not clean_slug:
        return JsonResponse({"ok": False, "error": "Invalid page slug"}, status=400)

    snapshot, _ = PageFormData.objects.get_or_create(page_slug=clean_slug)
    return JsonResponse({"ok": True, "page": clean_slug, "data": snapshot.data or {}})


@require_POST
def save_page_form_data(request, page_slug):
    clean_slug = _clean_page_slug(page_slug)
    if not clean_slug:
        return JsonResponse({"ok": False, "error": "Invalid page slug"}, status=400)

    payload = _parse_json(request)
    data = payload.get("data")
    if not isinstance(data, dict):
        return JsonResponse({"ok": False, "error": "Expected object payload for data"}, status=400)

    snapshot, _ = PageFormData.objects.get_or_create(page_slug=clean_slug)
    snapshot.data = data
    snapshot.save(update_fields=["data", "updated_at"])
    return JsonResponse({"ok": True, "page": clean_slug, "updated_at": snapshot.updated_at.isoformat()})


@require_GET
def list_uploaded_files(request, page_slug):
    clean_slug = _clean_page_slug(page_slug)
    if not clean_slug:
        return JsonResponse({"ok": False, "error": "Invalid page slug"}, status=400)

    files = UploadedDocument.objects.filter(page_slug=clean_slug)
    field_key = request.GET.get("field_key", "").strip()
    if field_key:
        clean_field_key = _clean_field_key(field_key)
        if not clean_field_key:
            return JsonResponse({"ok": False, "error": "Invalid field key"}, status=400)
        files = files.filter(field_key=clean_field_key)

    return JsonResponse({"ok": True, "files": [_upload_to_dict(item) for item in files[:200]]})


@require_POST
def upload_file_for_field(request, page_slug, field_key):
    clean_slug = _clean_page_slug(page_slug)
    clean_field_key = _clean_field_key(field_key)
    if not clean_slug:
        return JsonResponse({"ok": False, "error": "Invalid page slug"}, status=400)
    if not clean_field_key:
        return JsonResponse({"ok": False, "error": "Invalid field key"}, status=400)

    uploaded_file = request.FILES.get("file")
    validation_error = _validate_uploaded_file(uploaded_file)
    if validation_error:
        return JsonResponse({"ok": False, "error": validation_error}, status=400)

    label = (request.POST.get("label") or "").strip()[:120]
    record = UploadedDocument.objects.create(
        page_slug=clean_slug,
        field_key=clean_field_key,
        label=label,
        file=uploaded_file,
        original_name=uploaded_file.name,
        content_type=(uploaded_file.content_type or "")[:120],
        file_size=uploaded_file.size,
    )
    return JsonResponse({"ok": True, "file": _upload_to_dict(record)}, status=201)


# -----------------------------
# Finance command center APIs
# -----------------------------


def _safe_decimal(value, default=Decimal("0.00")):
    if value in (None, ""):
        return default
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return default


def _json_error(message, status=400):
    return JsonResponse({"ok": False, "error": message}, status=status)


def _parse_date(value):
    if not value:
        return None
    try:
        return datetime.strptime(str(value), "%Y-%m-%d").date()
    except ValueError:
        return None


def _to_money(value):
    return float(_safe_decimal(value))


def _month_bounds(any_date):
    start = any_date.replace(day=1)
    next_start = (start + timedelta(days=32)).replace(day=1)
    return start, next_start


def _month_key(any_date):
    return any_date.strftime("%Y-%m")


def _month_start(any_date):
    return any_date.replace(day=1)


def _add_months(any_date, months):
    month = any_date.month - 1 + months
    year = any_date.year + month // 12
    month = month % 12 + 1
    day = min(any_date.day, [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1])
    return date(year, month, day)


def _split_tags(raw):
    if isinstance(raw, list):
        return [str(tag).strip() for tag in raw if str(tag).strip()][:20]
    if isinstance(raw, str):
        return [piece.strip() for piece in raw.split(",") if piece.strip()][:20]
    return []


def _serialize_category(category):
    return {
        "id": category.id,
        "name": category.name,
        "slug": category.slug,
        "kind": category.kind,
        "color": category.color,
        "icon": category.icon,
        "is_active": category.is_active,
        "sort_order": category.sort_order,
    }


def _serialize_transaction(item):
    sign = Decimal("-1.00") if item.tx_type == Transaction.TYPE_EXPENSE else Decimal("1.00")
    signed_amount = sign * item.amount
    return {
        "id": item.id,
        "tx_date": item.tx_date.isoformat(),
        "description": item.description,
        "category": {
            "id": item.category_id,
            "name": item.category.name,
            "kind": item.category.kind,
            "color": item.category.color,
            "icon": item.category.icon,
        },
        "account": item.account,
        "tx_type": item.tx_type,
        "amount": _to_money(item.amount),
        "signed_amount": _to_money(signed_amount),
        "tags": item.tags or [],
        "notes": item.notes,
        "savings_goal_id": item.savings_goal_id,
        "application_cost_id": item.application_cost_id,
        "project_budget_id": item.project_budget_id,
        "updated_at": item.updated_at.isoformat(),
    }


def _serialize_budget(item, spent_amount):
    spent = _safe_decimal(spent_amount)
    remaining = item.monthly_limit - spent
    utilization = int((spent / item.monthly_limit) * 100) if item.monthly_limit > 0 else 0
    return {
        "id": item.id,
        "category": {
            "id": item.category_id,
            "name": item.category.name,
            "color": item.category.color,
            "kind": item.category.kind,
        },
        "period_start": item.period_start.isoformat(),
        "monthly_limit": _to_money(item.monthly_limit),
        "current_spending": _to_money(spent),
        "remaining_balance": _to_money(remaining),
        "progress_pct": utilization,
        "warning_threshold_pct": item.warning_threshold_pct,
        "is_active": item.is_active,
        "is_warning": utilization >= item.warning_threshold_pct,
        "is_over_limit": spent > item.monthly_limit,
    }


def _serialize_savings_goal(item, current_savings, suggestion):
    target = item.target_amount
    current = _safe_decimal(current_savings)
    progress = int((current / target) * 100) if target > 0 else 0
    progress = max(0, min(100, progress))
    return {
        "id": item.id,
        "name": item.name,
        "target_amount": _to_money(item.target_amount),
        "starting_amount": _to_money(item.starting_amount),
        "current_savings": _to_money(current),
        "progress_pct": progress,
        "deadline": item.deadline.isoformat() if item.deadline else None,
        "status": item.status,
        "monthly_target_suggestion": _to_money(suggestion),
    }


def _serialize_application_cost(item):
    return {
        "id": item.id,
        "item_type": item.item_type,
        "item_label": item.get_item_type_display(),
        "estimated_cost": _to_money(item.estimated_cost),
        "actual_cost": _to_money(item.actual_cost) if item.actual_cost is not None else None,
        "status": item.status,
        "deadline": item.deadline.isoformat() if item.deadline else None,
        "notes": item.notes,
    }


def _serialize_project_budget(item, spent_amount):
    spent = _safe_decimal(spent_amount)
    remaining = item.budget_amount - spent
    return {
        "id": item.id,
        "project_name": item.project_name,
        "budget_amount": _to_money(item.budget_amount),
        "spent_amount": _to_money(spent),
        "remaining_funds": _to_money(remaining),
        "roi_target_pct": float(item.roi_target_pct) if item.roi_target_pct is not None else None,
        "roi_actual_pct": float(item.roi_actual_pct) if item.roi_actual_pct is not None else None,
        "status": item.status,
    }


def _serialize_recurring(item):
    return {
        "id": item.id,
        "name": item.name,
        "category_id": item.category_id,
        "category_name": item.category.name,
        "account": item.account,
        "amount": _to_money(item.amount),
        "cadence": item.cadence,
        "next_due_date": item.next_due_date.isoformat(),
        "end_date": item.end_date.isoformat() if item.end_date else None,
        "is_active": item.is_active,
    }


def _serialize_alert(item):
    return {
        "id": item.id,
        "alert_type": item.alert_type,
        "severity": item.severity,
        "message": item.message,
        "related_model": item.related_model,
        "related_id": item.related_id,
        "period_key": item.period_key,
        "is_read": item.is_read,
        "created_at": item.created_at.isoformat(),
    }


def _compute_goal_suggestion(goal, current_savings, today):
    remaining = max(Decimal("0.00"), goal.target_amount - current_savings)
    if remaining <= 0:
        return Decimal("0.00")
    if goal.deadline is None:
        return remaining / Decimal("6.00")
    if goal.deadline <= today:
        return remaining

    month_diff = (goal.deadline.year - today.year) * 12 + (goal.deadline.month - today.month)
    if goal.deadline.day >= today.day:
        month_diff += 1
    month_diff = max(month_diff, 1)
    return remaining / Decimal(month_diff)


def _upsert_alert(alert_type, severity, message, related_model, related_id, period_key):
    alert, created = FinanceAlert.objects.get_or_create(
        alert_type=alert_type,
        related_model=related_model or "",
        related_id=related_id,
        period_key=period_key or "",
        defaults={"severity": severity, "message": message, "is_read": False},
    )
    if not created:
        changed = False
        if alert.severity != severity:
            alert.severity = severity
            changed = True
        if alert.message != message:
            alert.message = message
            changed = True
        if changed:
            alert.is_read = False
            alert.save(update_fields=["severity", "message", "is_read", "updated_at"])

def _filter_transactions(params):
    qs = Transaction.objects.select_related("category", "savings_goal", "application_cost", "project_budget")

    query = (params.get("q") or "").strip()
    if query:
        qs = qs.filter(description__icontains=query)

    date_from = _parse_date(params.get("date_from"))
    date_to = _parse_date(params.get("date_to"))
    if date_from:
        qs = qs.filter(tx_date__gte=date_from)
    if date_to:
        qs = qs.filter(tx_date__lte=date_to)

    category_id = (params.get("category_id") or "").strip()
    if category_id.isdigit():
        qs = qs.filter(category_id=int(category_id))

    account = (params.get("account") or "").strip()
    if account in {choice[0] for choice in Transaction.ACCOUNT_CHOICES}:
        qs = qs.filter(account=account)

    tx_type = (params.get("tx_type") or "").strip()
    if tx_type in {choice[0] for choice in Transaction.TYPE_CHOICES}:
        qs = qs.filter(tx_type=tx_type)

    amount_min = _safe_decimal(params.get("amount_min"), None)
    amount_max = _safe_decimal(params.get("amount_max"), None)
    if amount_min is not None:
        qs = qs.filter(amount__gte=amount_min)
    if amount_max is not None:
        qs = qs.filter(amount__lte=amount_max)

    sort_map = {
        "date_desc": "-tx_date",
        "date_asc": "tx_date",
        "amount_desc": "-amount",
        "amount_asc": "amount",
        "category_asc": "category__name",
        "category_desc": "-category__name",
        "updated_desc": "-updated_at",
    }
    sort = (params.get("sort") or "date_desc").strip()
    qs = qs.order_by(sort_map.get(sort, "-tx_date"), "-id")
    return qs


def _paginate_queryset(qs, params):
    page_size = params.get("page_size", 12)
    try:
        page_size = int(page_size)
    except (TypeError, ValueError):
        page_size = 12
    page_size = max(1, min(page_size, 100))

    page_number = params.get("page", 1)
    try:
        page_number = int(page_number)
    except (TypeError, ValueError):
        page_number = 1

    paginator = Paginator(qs, page_size)
    page_obj = paginator.get_page(page_number)
    return page_obj, paginator


def _compute_finance_payload():
    today = date.today()
    current_start, current_end = _month_bounds(today)
    prev_start = _add_months(current_start, -1)
    prev_end = current_start

    current_qs = Transaction.objects.filter(tx_date__gte=current_start, tx_date__lt=current_end)
    prev_qs = Transaction.objects.filter(tx_date__gte=prev_start, tx_date__lt=prev_end)

    current_income = _safe_decimal(current_qs.filter(tx_type=Transaction.TYPE_INCOME).aggregate(total=Sum("amount"))["total"])
    current_expense = _safe_decimal(current_qs.filter(tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])
    current_savings = _safe_decimal(current_qs.filter(tx_type=Transaction.TYPE_SAVINGS).aggregate(total=Sum("amount"))["total"])

    prev_income = _safe_decimal(prev_qs.filter(tx_type=Transaction.TYPE_INCOME).aggregate(total=Sum("amount"))["total"])
    prev_expense = _safe_decimal(prev_qs.filter(tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])

    all_savings = _safe_decimal(Transaction.objects.filter(tx_type=Transaction.TYPE_SAVINGS).aggregate(total=Sum("amount"))["total"])
    app_estimated = _safe_decimal(ApplicationCost.objects.aggregate(total=Sum("estimated_cost"))["total"])
    app_actual = _safe_decimal(ApplicationCost.objects.exclude(actual_cost__isnull=True).aggregate(total=Sum("actual_cost"))["total"])

    budget_qs = Budget.objects.select_related("category").filter(period_start=current_start, is_active=True)
    budget_limit_total = _safe_decimal(budget_qs.aggregate(total=Sum("monthly_limit"))["total"])
    budget_spend_total = Decimal("0.00")
    for budget in budget_qs:
        spent = _safe_decimal(
            current_qs.filter(tx_type=Transaction.TYPE_EXPENSE, category=budget.category).aggregate(total=Sum("amount"))["total"]
        )
        budget_spend_total += spent

    monthly_budget_remaining = budget_limit_total - budget_spend_total
    cash_flow = current_income - current_expense

    investment_fund = _safe_decimal(
        Transaction.objects.filter(category__kind__in=[Category.KIND_INVESTMENT, Category.KIND_BUSINESS], tx_type=Transaction.TYPE_INCOME).aggregate(total=Sum("amount"))["total"]
    )
    scholarship_fund = max(Decimal("0.00"), app_estimated - app_actual)

    def pct_change(current, previous):
        if previous == 0:
            return 0
        return float(((current - previous) / previous) * Decimal("100.00"))

    metrics = [
        {
            "key": "monthly_income",
            "label": "Monthly Income",
            "icon": "fa-sack-dollar",
            "value": _to_money(current_income),
            "trend": pct_change(current_income, prev_income),
            "description": "Total income for the current month.",
        },
        {
            "key": "total_expenses",
            "label": "Total Expenses",
            "icon": "fa-arrow-trend-down",
            "value": _to_money(current_expense),
            "trend": pct_change(current_expense, prev_expense),
            "description": "Total spending for the current month.",
        },
        {
            "key": "net_savings",
            "label": "Net Savings",
            "icon": "fa-piggy-bank",
            "value": _to_money(current_income - current_expense),
            "trend": pct_change(current_income - current_expense, prev_income - prev_expense),
            "description": "Income minus expenses in the current month.",
        },
        {
            "key": "application_budget",
            "label": "Application Budget",
            "icon": "fa-graduation-cap",
            "value": _to_money(app_estimated),
            "trend": 0,
            "description": "Total planned scholarship/application spending.",
        },
        {
            "key": "cash_flow",
            "label": "Cash Flow",
            "icon": "fa-arrows-left-right",
            "value": _to_money(cash_flow),
            "trend": pct_change(cash_flow, prev_income - prev_expense),
            "description": "Money movement after costs this month.",
        },
        {
            "key": "budget_remaining",
            "label": "Monthly Budget Remaining",
            "icon": "fa-scale-balanced",
            "value": _to_money(monthly_budget_remaining),
            "trend": 0,
            "description": "Configured monthly budgets minus tracked spending.",
        },
        {
            "key": "total_savings_balance",
            "label": "Total Savings Balance",
            "icon": "fa-vault",
            "value": _to_money(all_savings),
            "trend": 0,
            "description": "Cumulative savings transactions recorded.",
        },
        {
            "key": "scholarship_fund",
            "label": "Scholarship Application Fund",
            "icon": "fa-passport",
            "value": _to_money(scholarship_fund),
            "trend": 0,
            "description": "Estimated application costs still outstanding.",
        },
        {
            "key": "investment_fund",
            "label": "Investment / Business Fund",
            "icon": "fa-chart-line",
            "value": _to_money(investment_fund),
            "trend": 0,
            "description": "Capital allocated to projects and investments.",
        },
    ]

    # Budgets
    budget_items = []
    budget_overrun_count = 0
    budget_warning_count = 0
    for budget in budget_qs:
        spent = _safe_decimal(
            current_qs.filter(tx_type=Transaction.TYPE_EXPENSE, category=budget.category).aggregate(total=Sum("amount"))["total"]
        )
        payload = _serialize_budget(budget, spent)
        budget_items.append(payload)
        if payload["is_over_limit"]:
            budget_overrun_count += 1
        elif payload["is_warning"]:
            budget_warning_count += 1

    # Savings goals
    goals_payload = []
    goals_at_risk = 0
    for goal in SavingsGoal.objects.all():
        goal_saved = _safe_decimal(
            Transaction.objects.filter(tx_type=Transaction.TYPE_SAVINGS, savings_goal=goal).aggregate(total=Sum("amount"))["total"]
        )
        current_saved = goal.starting_amount + goal_saved
        suggestion = _compute_goal_suggestion(goal, current_saved, today)
        goals_payload.append(_serialize_savings_goal(goal, current_saved, suggestion))

        if goal.deadline and goal.deadline > today and current_saved < goal.target_amount:
            if suggestion > Decimal("0") and suggestion > (goal.target_amount * Decimal("0.20")):
                goals_at_risk += 1

    # Application costs
    application_items = [_serialize_application_cost(item) for item in ApplicationCost.objects.all()]

    # Project budgets
    project_payload = []
    for project in ProjectBudget.objects.all():
        project_spent = _safe_decimal(project.manual_spent_adjustment)
        project_spent += _safe_decimal(
            Transaction.objects.filter(project_budget=project, tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"]
        )
        project_payload.append(_serialize_project_budget(project, project_spent))

    # Recurring forecast preview 60 days
    recurring_preview = _compute_forecast(days=60)

    # Alerts (hybrid persisted)
    period_key = _month_key(today)
    for budget_item in budget_items:
        if budget_item["is_over_limit"]:
            _upsert_alert(
                FinanceAlert.TYPE_BUDGET_OVERRUN,
                FinanceAlert.SEVERITY_CRITICAL,
                f"{budget_item['category']['name']} is over budget by KES {abs(budget_item['remaining_balance']):,.2f}.",
                "budget",
                budget_item["id"],
                period_key,
            )
        elif budget_item["is_warning"]:
            _upsert_alert(
                FinanceAlert.TYPE_BUDGET_OVERRUN,
                FinanceAlert.SEVERITY_WARNING,
                f"{budget_item['category']['name']} has reached {budget_item['progress_pct']}% of monthly limit.",
                "budget",
                budget_item["id"],
                period_key,
            )

    if cash_flow < 0:
        _upsert_alert(
            FinanceAlert.TYPE_CASHFLOW,
            FinanceAlert.SEVERITY_WARNING,
            "Cash flow is negative this month. Reduce expenses or increase income sources.",
            "system",
            1,
            period_key,
        )

    for app in ApplicationCost.objects.exclude(status__in=[ApplicationCost.STATUS_PAID, ApplicationCost.STATUS_WAIVED, ApplicationCost.STATUS_CANCELLED]):
        if app.deadline and 0 <= (app.deadline - today).days <= 21:
            _upsert_alert(
                FinanceAlert.TYPE_DEADLINE,
                FinanceAlert.SEVERITY_WARNING,
                f"{app.get_item_type_display()} deadline is in {(app.deadline - today).days} days.",
                "application_cost",
                app.id,
                _month_key(app.deadline),
            )

    if goals_at_risk > 0:
        _upsert_alert(
            FinanceAlert.TYPE_GOAL_RISK,
            FinanceAlert.SEVERITY_WARNING,
            f"{goals_at_risk} savings goal(s) are at risk of missing target deadlines.",
            "savings_goal",
            None,
            period_key,
        )

    alerts_payload = [_serialize_alert(item) for item in FinanceAlert.objects.all()[:50]]

    # Insights (computed on-demand)
    insights = []
    food_like = Category.objects.filter(name__icontains="living").values_list("id", flat=True)
    current_food = _safe_decimal(current_qs.filter(category_id__in=food_like, tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])
    prev_food = _safe_decimal(prev_qs.filter(category_id__in=food_like, tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])
    if prev_food > 0:
        diff = ((current_food - prev_food) / prev_food) * Decimal("100.00")
        if diff > 15:
            insights.append({"tag": "Budget", "message": f"Living costs increased {float(diff):.1f}% compared to last month."})

    if current_savings > 0 and current_income > 0:
        save_rate = (current_savings / current_income) * Decimal("100.00")
        insights.append({"tag": "Savings", "message": f"You are saving {float(save_rate):.1f}% of monthly income."})

    if scholarship_fund > 0:
        insights.append({"tag": "Scholarships", "message": f"KES {float(scholarship_fund):,.0f} still needed for application pipeline."})

    # Charts
    month_labels = []
    income_series = []
    expense_series = []
    savings_series = []
    balance_series = []
    running_balance = Decimal("0.00")
    for idx in range(5, -1, -1):
        start = _add_months(current_start, -idx)
        end = _add_months(start, 1)
        label = start.strftime("%b")
        month_labels.append(label)
        month_qs = Transaction.objects.filter(tx_date__gte=start, tx_date__lt=end)
        income_v = _safe_decimal(month_qs.filter(tx_type=Transaction.TYPE_INCOME).aggregate(total=Sum("amount"))["total"])
        expense_v = _safe_decimal(month_qs.filter(tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])
        savings_v = _safe_decimal(month_qs.filter(tx_type=Transaction.TYPE_SAVINGS).aggregate(total=Sum("amount"))["total"])
        running_balance += income_v - expense_v
        income_series.append(_to_money(income_v))
        expense_series.append(_to_money(expense_v))
        savings_series.append(_to_money(savings_v))
        balance_series.append(_to_money(running_balance))

    category_breakdown = []
    for category in Category.objects.filter(is_active=True):
        value = _safe_decimal(current_qs.filter(category=category, tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])
        if value > 0:
            category_breakdown.append(
                {
                    "label": category.name,
                    "value": _to_money(value),
                    "color": category.color,
                }
            )

    budget_util = [
        {
            "label": item["category"]["name"],
            "value": item["progress_pct"],
            "color": item["category"]["color"],
        }
        for item in budget_items
    ]

    app_breakdown = [
        {
            "label": item["item_label"],
            "estimated": item["estimated_cost"],
            "actual": item["actual_cost"] or 0,
        }
        for item in application_items
    ]

    project_roi = [
        {
            "label": item["project_name"],
            "target": item["roi_target_pct"] or 0,
            "actual": item["roi_actual_pct"] or 0,
        }
        for item in project_payload
    ]

    return {
        "metrics": metrics,
        "budgets": budget_items,
        "savings_goals": goals_payload,
        "application_costs": application_items,
        "project_budgets": project_payload,
        "recurring_forecast": recurring_preview,
        "alerts": alerts_payload,
        "insights": insights,
        "summary": {
            "cash_flow": _to_money(cash_flow),
            "budget_remaining": _to_money(monthly_budget_remaining),
            "total_savings": _to_money(all_savings),
            "application_estimated_total": _to_money(app_estimated),
            "application_actual_total": _to_money(app_actual),
            "budget_warning_count": budget_warning_count,
            "budget_overrun_count": budget_overrun_count,
        },
        "charts": {
            "monthly_income_vs_expenses": {
                "labels": month_labels,
                "income": income_series,
                "expenses": expense_series,
            },
            "expense_category_distribution": category_breakdown,
            "savings_growth": {
                "labels": month_labels,
                "values": savings_series,
            },
            "budget_utilization": budget_util,
            "application_cost_breakdown": app_breakdown,
            "project_roi": project_roi,
            "cash_balance_trend": {
                "labels": month_labels,
                "values": balance_series,
            },
        },
    }


def _compute_forecast(days=30):
    horizon = date.today() + timedelta(days=days)
    forecast_rows = []
    for template in RecurringExpenseTemplate.objects.select_related("category").filter(is_active=True):
        due = template.next_due_date
        while due <= horizon:
            if template.end_date and due > template.end_date:
                break
            forecast_rows.append(
                {
                    "template_id": template.id,
                    "template_name": template.name,
                    "category": template.category.name,
                    "category_color": template.category.color,
                    "amount": _to_money(template.amount),
                    "account": template.account,
                    "due_date": due.isoformat(),
                }
            )
            if template.cadence == RecurringExpenseTemplate.CADENCE_WEEKLY:
                due = due + timedelta(days=7)
            elif template.cadence == RecurringExpenseTemplate.CADENCE_YEARLY:
                due = _add_months(due, 12)
            else:
                due = _add_months(due, 1)

    forecast_rows.sort(key=lambda row: row["due_date"])
    return forecast_rows[:200]


@require_GET
def finance_bootstrap(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    base_payload = _compute_finance_payload()
    transaction_qs = _filter_transactions(request.GET)
    page_obj, paginator = _paginate_queryset(transaction_qs, request.GET)
    ledger = [_serialize_transaction(item) for item in page_obj.object_list]

    payload = {
        "ok": True,
        **base_payload,
        "ledger": {
            "rows": ledger,
            "pagination": {
                "page": page_obj.number,
                "page_size": page_obj.paginator.per_page,
                "total_pages": paginator.num_pages,
                "total_items": paginator.count,
                "has_next": page_obj.has_next(),
                "has_prev": page_obj.has_previous(),
            },
        },
    }
    return JsonResponse(payload)


@require_GET
def finance_transactions(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    qs = _filter_transactions(request.GET)
    page_obj, paginator = _paginate_queryset(qs, request.GET)
    rows = [_serialize_transaction(item) for item in page_obj.object_list]
    return JsonResponse(
        {
            "ok": True,
            "rows": rows,
            "pagination": {
                "page": page_obj.number,
                "page_size": page_obj.paginator.per_page,
                "total_pages": paginator.num_pages,
                "total_items": paginator.count,
                "has_next": page_obj.has_next(),
                "has_prev": page_obj.has_previous(),
            },
        }
    )


@require_POST
def finance_transactions_create(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    payload = _parse_json(request)
    tx_date = _parse_date(payload.get("tx_date"))
    if not tx_date:
        return _json_error("Valid transaction date is required")

    description = (payload.get("description") or "").strip()
    if not description:
        return _json_error("Description is required")

    category_id = payload.get("category_id")
    category = Category.objects.filter(id=category_id).first()
    if not category:
        return _json_error("Valid category is required")

    account = (payload.get("account") or Transaction.ACCOUNT_BANK).strip()
    if account not in {choice[0] for choice in Transaction.ACCOUNT_CHOICES}:
        return _json_error("Invalid account")

    tx_type = (payload.get("tx_type") or Transaction.TYPE_EXPENSE).strip()
    if tx_type not in {choice[0] for choice in Transaction.TYPE_CHOICES}:
        return _json_error("Invalid transaction type")

    amount = _safe_decimal(payload.get("amount"), None)
    if amount is None or amount <= 0:
        return _json_error("Amount must be greater than zero")

    tags = _split_tags(payload.get("tags"))

    savings_goal = None
    if payload.get("savings_goal_id"):
        savings_goal = SavingsGoal.objects.filter(id=payload.get("savings_goal_id")).first()

    application_cost = None
    if payload.get("application_cost_id"):
        application_cost = ApplicationCost.objects.filter(id=payload.get("application_cost_id")).first()

    project_budget = None
    if payload.get("project_budget_id"):
        project_budget = ProjectBudget.objects.filter(id=payload.get("project_budget_id")).first()

    tx = Transaction.objects.create(
        tx_date=tx_date,
        description=description,
        category=category,
        account=account,
        tx_type=tx_type,
        amount=amount,
        tags=tags,
        savings_goal=savings_goal,
        application_cost=application_cost,
        project_budget=project_budget,
        notes=(payload.get("notes") or "").strip(),
    )
    return JsonResponse({"ok": True, "transaction": _serialize_transaction(tx)}, status=201)


@require_POST
def finance_transactions_update(request, transaction_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    tx = get_object_or_404(Transaction, id=transaction_id)
    payload = _parse_json(request)

    tx_date = _parse_date(payload.get("tx_date"))
    if not tx_date:
        return _json_error("Valid transaction date is required")

    description = (payload.get("description") or "").strip()
    if not description:
        return _json_error("Description is required")

    category = Category.objects.filter(id=payload.get("category_id")).first()
    if not category:
        return _json_error("Valid category is required")

    account = (payload.get("account") or Transaction.ACCOUNT_BANK).strip()
    if account not in {choice[0] for choice in Transaction.ACCOUNT_CHOICES}:
        return _json_error("Invalid account")

    tx_type = (payload.get("tx_type") or Transaction.TYPE_EXPENSE).strip()
    if tx_type not in {choice[0] for choice in Transaction.TYPE_CHOICES}:
        return _json_error("Invalid transaction type")

    amount = _safe_decimal(payload.get("amount"), None)
    if amount is None or amount <= 0:
        return _json_error("Amount must be greater than zero")

    tx.tx_date = tx_date
    tx.description = description
    tx.category = category
    tx.account = account
    tx.tx_type = tx_type
    tx.amount = amount
    tx.tags = _split_tags(payload.get("tags"))
    tx.notes = (payload.get("notes") or "").strip()
    tx.savings_goal = SavingsGoal.objects.filter(id=payload.get("savings_goal_id")).first() if payload.get("savings_goal_id") else None
    tx.application_cost = ApplicationCost.objects.filter(id=payload.get("application_cost_id")).first() if payload.get("application_cost_id") else None
    tx.project_budget = ProjectBudget.objects.filter(id=payload.get("project_budget_id")).first() if payload.get("project_budget_id") else None
    tx.save()
    return JsonResponse({"ok": True, "transaction": _serialize_transaction(tx)})


@require_POST
def finance_transactions_delete(request, transaction_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    tx = get_object_or_404(Transaction, id=transaction_id)
    tx.delete()
    return JsonResponse({"ok": True})


@require_GET
def finance_transactions_export_csv(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    qs = _filter_transactions(request.GET)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="finance-transactions.csv"'

    writer = csv.writer(response)
    writer.writerow(["Date", "Description", "Category", "Account", "Type", "Amount", "Tags", "Notes"])
    for item in qs[:5000]:
        writer.writerow(
            [
                item.tx_date.isoformat(),
                item.description,
                item.category.name,
                item.account,
                item.tx_type,
                str(item.amount),
                ", ".join(item.tags or []),
                item.notes,
            ]
        )

    return response


@require_GET
def finance_categories(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_category(cat) for cat in Category.objects.all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def finance_categories_create(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)

    name = (payload.get("name") or "").strip()
    if not name:
        return _json_error("Category name is required")

    kind = (payload.get("kind") or Category.KIND_EXPENSE).strip()
    if kind not in {choice[0] for choice in Category.KIND_CHOICES}:
        return _json_error("Invalid category kind")

    slug = (payload.get("slug") or re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")).strip()
    if not slug:
        return _json_error("Valid category slug is required")
    if Category.objects.filter(slug=slug).exists():
        return _json_error("Category slug already exists")

    category = Category.objects.create(
        name=name,
        slug=slug,
        kind=kind,
        color=(payload.get("color") or "#8B5A2B").strip()[:16],
        icon=(payload.get("icon") or "fa-wallet").strip()[:40],
        is_active=bool(payload.get("is_active", True)),
        sort_order=int(payload.get("sort_order") or 0),
    )
    return JsonResponse({"ok": True, "category": _serialize_category(category)}, status=201)


@require_POST
def finance_categories_update(request, category_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    category = get_object_or_404(Category, id=category_id)
    payload = _parse_json(request)

    name = (payload.get("name") or category.name).strip()
    slug = (payload.get("slug") or category.slug).strip()
    kind = (payload.get("kind") or category.kind).strip()

    if kind not in {choice[0] for choice in Category.KIND_CHOICES}:
        return _json_error("Invalid category kind")
    if Category.objects.exclude(id=category.id).filter(slug=slug).exists():
        return _json_error("Category slug already exists")

    category.name = name
    category.slug = slug
    category.kind = kind
    category.color = (payload.get("color") or category.color).strip()[:16]
    category.icon = (payload.get("icon") or category.icon).strip()[:40]
    category.is_active = bool(payload.get("is_active", category.is_active))
    category.sort_order = int(payload.get("sort_order") if payload.get("sort_order") is not None else category.sort_order)
    category.save()
    return JsonResponse({"ok": True, "category": _serialize_category(category)})


@require_POST
def finance_categories_delete(request, category_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    category = get_object_or_404(Category, id=category_id)
    if Transaction.objects.filter(category=category).exists():
        return _json_error("Cannot delete category with existing transactions", status=409)
    if Budget.objects.filter(category=category).exists():
        return _json_error("Cannot delete category with existing budgets", status=409)
    if RecurringExpenseTemplate.objects.filter(category=category).exists():
        return _json_error("Cannot delete category with recurring templates", status=409)
    category.delete()
    return JsonResponse({"ok": True})


@require_GET
def finance_budgets(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    rows = []
    for item in Budget.objects.select_related("category").all():
        month_start, month_end = _month_bounds(item.period_start)
        spent = _safe_decimal(
            Transaction.objects.filter(
                tx_type=Transaction.TYPE_EXPENSE,
                category=item.category,
                tx_date__gte=month_start,
                tx_date__lt=month_end,
            ).aggregate(total=Sum("amount"))["total"]
        )
        rows.append(_serialize_budget(item, spent))
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def finance_budgets_create(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    payload = _parse_json(request)
    category = Category.objects.filter(id=payload.get("category_id")).first()
    if not category:
        return _json_error("Valid category is required")

    period_start = _parse_date(payload.get("period_start"))
    if not period_start:
        return _json_error("Valid period start date is required")
    period_start = _month_start(period_start)

    monthly_limit = _safe_decimal(payload.get("monthly_limit"), None)
    if monthly_limit is None or monthly_limit <= 0:
        return _json_error("Monthly limit must be greater than zero")

    if Budget.objects.filter(category=category, period_start=period_start).exists():
        return _json_error("Budget for this category and month already exists", status=409)

    item = Budget.objects.create(
        category=category,
        period_start=period_start,
        monthly_limit=monthly_limit,
        warning_threshold_pct=int(payload.get("warning_threshold_pct") or 90),
        is_active=bool(payload.get("is_active", True)),
    )
    return JsonResponse({"ok": True, "budget": _serialize_budget(item, Decimal("0.00"))}, status=201)


@require_POST
def finance_budgets_update(request, budget_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    item = get_object_or_404(Budget, id=budget_id)
    payload = _parse_json(request)

    category = Category.objects.filter(id=payload.get("category_id")).first() if payload.get("category_id") else item.category
    period_start = _parse_date(payload.get("period_start")) if payload.get("period_start") else item.period_start
    period_start = _month_start(period_start)

    monthly_limit = _safe_decimal(payload.get("monthly_limit"), item.monthly_limit)
    if monthly_limit <= 0:
        return _json_error("Monthly limit must be greater than zero")

    if Budget.objects.exclude(id=item.id).filter(category=category, period_start=period_start).exists():
        return _json_error("Budget for this category and month already exists", status=409)

    item.category = category
    item.period_start = period_start
    item.monthly_limit = monthly_limit
    item.warning_threshold_pct = int(payload.get("warning_threshold_pct") or item.warning_threshold_pct)
    item.is_active = bool(payload.get("is_active", item.is_active))
    item.save()

    spent = _safe_decimal(
        Transaction.objects.filter(
            tx_type=Transaction.TYPE_EXPENSE,
            category=item.category,
            tx_date__gte=period_start,
            tx_date__lt=_add_months(period_start, 1),
        ).aggregate(total=Sum("amount"))["total"]
    )
    return JsonResponse({"ok": True, "budget": _serialize_budget(item, spent)})


@require_POST
def finance_budgets_delete(request, budget_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(Budget, id=budget_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def finance_savings_goals(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    today = date.today()
    rows = []
    for goal in SavingsGoal.objects.all():
        tracked = _safe_decimal(Transaction.objects.filter(tx_type=Transaction.TYPE_SAVINGS, savings_goal=goal).aggregate(total=Sum("amount"))["total"])
        current = goal.starting_amount + tracked
        suggestion = _compute_goal_suggestion(goal, current, today)
        rows.append(_serialize_savings_goal(goal, current, suggestion))
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def finance_savings_goals_create(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    payload = _parse_json(request)
    name = (payload.get("name") or "").strip()
    if not name:
        return _json_error("Goal name is required")

    target_amount = _safe_decimal(payload.get("target_amount"), None)
    if target_amount is None or target_amount <= 0:
        return _json_error("Target amount must be greater than zero")

    starting_amount = _safe_decimal(payload.get("starting_amount"), Decimal("0.00"))
    deadline = _parse_date(payload.get("deadline"))
    status = (payload.get("status") or SavingsGoal.STATUS_ACTIVE).strip()
    if status not in {choice[0] for choice in SavingsGoal.STATUS_CHOICES}:
        return _json_error("Invalid status")

    goal = SavingsGoal.objects.create(
        name=name,
        target_amount=target_amount,
        starting_amount=max(Decimal("0.00"), starting_amount),
        deadline=deadline,
        status=status,
        monthly_target_suggestion=_safe_decimal(payload.get("monthly_target_suggestion"), Decimal("0.00")),
    )
    suggestion = _compute_goal_suggestion(goal, goal.starting_amount, date.today())
    return JsonResponse({"ok": True, "goal": _serialize_savings_goal(goal, goal.starting_amount, suggestion)}, status=201)


@require_POST
def finance_savings_goals_update(request, goal_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    goal = get_object_or_404(SavingsGoal, id=goal_id)
    payload = _parse_json(request)

    name = (payload.get("name") or goal.name).strip()
    target_amount = _safe_decimal(payload.get("target_amount"), goal.target_amount)
    if target_amount <= 0:
        return _json_error("Target amount must be greater than zero")

    goal.name = name
    goal.target_amount = target_amount
    goal.starting_amount = max(Decimal("0.00"), _safe_decimal(payload.get("starting_amount"), goal.starting_amount))
    goal.deadline = _parse_date(payload.get("deadline")) if payload.get("deadline") is not None else goal.deadline
    status = (payload.get("status") or goal.status).strip()
    if status not in {choice[0] for choice in SavingsGoal.STATUS_CHOICES}:
        return _json_error("Invalid status")
    goal.status = status
    goal.monthly_target_suggestion = _safe_decimal(payload.get("monthly_target_suggestion"), goal.monthly_target_suggestion)
    goal.save()

    tracked = _safe_decimal(Transaction.objects.filter(tx_type=Transaction.TYPE_SAVINGS, savings_goal=goal).aggregate(total=Sum("amount"))["total"])
    current = goal.starting_amount + tracked
    suggestion = _compute_goal_suggestion(goal, current, date.today())
    return JsonResponse({"ok": True, "goal": _serialize_savings_goal(goal, current, suggestion)})


@require_POST
def finance_savings_goals_delete(request, goal_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    goal = get_object_or_404(SavingsGoal, id=goal_id)
    Transaction.objects.filter(savings_goal=goal).update(savings_goal=None)
    goal.delete()
    return JsonResponse({"ok": True})


@require_GET
def finance_application_costs(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_application_cost(item) for item in ApplicationCost.objects.all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def finance_application_costs_create(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)

    item_type = (payload.get("item_type") or ApplicationCost.TYPE_OTHER).strip()
    if item_type not in {choice[0] for choice in ApplicationCost.ITEM_TYPE_CHOICES}:
        return _json_error("Invalid item type")

    estimated_cost = _safe_decimal(payload.get("estimated_cost"), None)
    if estimated_cost is None or estimated_cost < 0:
        return _json_error("Estimated cost must be zero or greater")

    status = (payload.get("status") or ApplicationCost.STATUS_PLANNED).strip()
    if status not in {choice[0] for choice in ApplicationCost.STATUS_CHOICES}:
        return _json_error("Invalid status")

    item = ApplicationCost.objects.create(
        item_type=item_type,
        estimated_cost=estimated_cost,
        actual_cost=_safe_decimal(payload.get("actual_cost"), None) if payload.get("actual_cost") not in (None, "") else None,
        status=status,
        deadline=_parse_date(payload.get("deadline")),
        notes=(payload.get("notes") or "").strip(),
    )
    return JsonResponse({"ok": True, "application_cost": _serialize_application_cost(item)}, status=201)


@require_POST
def finance_application_costs_update(request, cost_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ApplicationCost, id=cost_id)
    payload = _parse_json(request)

    item_type = (payload.get("item_type") or item.item_type).strip()
    if item_type not in {choice[0] for choice in ApplicationCost.ITEM_TYPE_CHOICES}:
        return _json_error("Invalid item type")

    status = (payload.get("status") or item.status).strip()
    if status not in {choice[0] for choice in ApplicationCost.STATUS_CHOICES}:
        return _json_error("Invalid status")

    estimated_cost = _safe_decimal(payload.get("estimated_cost"), item.estimated_cost)
    if estimated_cost < 0:
        return _json_error("Estimated cost must be zero or greater")

    item.item_type = item_type
    item.estimated_cost = estimated_cost
    item.actual_cost = _safe_decimal(payload.get("actual_cost"), None) if payload.get("actual_cost") not in (None, "") else None
    item.status = status
    item.deadline = _parse_date(payload.get("deadline")) if payload.get("deadline") is not None else item.deadline
    item.notes = (payload.get("notes") or item.notes).strip()
    item.save()

    return JsonResponse({"ok": True, "application_cost": _serialize_application_cost(item)})


@require_POST
def finance_application_costs_delete(request, cost_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ApplicationCost, id=cost_id)
    Transaction.objects.filter(application_cost=item).update(application_cost=None)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def finance_project_budgets(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    rows = []
    for item in ProjectBudget.objects.all():
        spent = _safe_decimal(item.manual_spent_adjustment)
        spent += _safe_decimal(Transaction.objects.filter(project_budget=item, tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])
        rows.append(_serialize_project_budget(item, spent))
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def finance_project_budgets_create(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)

    name = (payload.get("project_name") or "").strip()
    if not name:
        return _json_error("Project name is required")

    budget_amount = _safe_decimal(payload.get("budget_amount"), None)
    if budget_amount is None or budget_amount <= 0:
        return _json_error("Budget amount must be greater than zero")

    status = (payload.get("status") or ProjectBudget.STATUS_ACTIVE).strip()
    if status not in {choice[0] for choice in ProjectBudget.STATUS_CHOICES}:
        return _json_error("Invalid status")

    item = ProjectBudget.objects.create(
        project_name=name,
        budget_amount=budget_amount,
        manual_spent_adjustment=max(Decimal("0.00"), _safe_decimal(payload.get("manual_spent_adjustment"), Decimal("0.00"))),
        roi_target_pct=_safe_decimal(payload.get("roi_target_pct"), None) if payload.get("roi_target_pct") not in (None, "") else None,
        roi_actual_pct=_safe_decimal(payload.get("roi_actual_pct"), None) if payload.get("roi_actual_pct") not in (None, "") else None,
        status=status,
    )
    spent = _safe_decimal(item.manual_spent_adjustment)
    return JsonResponse({"ok": True, "project_budget": _serialize_project_budget(item, spent)}, status=201)


@require_POST
def finance_project_budgets_update(request, project_budget_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ProjectBudget, id=project_budget_id)
    payload = _parse_json(request)

    item.project_name = (payload.get("project_name") or item.project_name).strip()
    budget_amount = _safe_decimal(payload.get("budget_amount"), item.budget_amount)
    if budget_amount <= 0:
        return _json_error("Budget amount must be greater than zero")
    item.budget_amount = budget_amount
    item.manual_spent_adjustment = max(Decimal("0.00"), _safe_decimal(payload.get("manual_spent_adjustment"), item.manual_spent_adjustment))

    status = (payload.get("status") or item.status).strip()
    if status not in {choice[0] for choice in ProjectBudget.STATUS_CHOICES}:
        return _json_error("Invalid status")
    item.status = status

    item.roi_target_pct = _safe_decimal(payload.get("roi_target_pct"), None) if payload.get("roi_target_pct") not in (None, "") else None
    item.roi_actual_pct = _safe_decimal(payload.get("roi_actual_pct"), None) if payload.get("roi_actual_pct") not in (None, "") else None
    item.save()

    spent = _safe_decimal(item.manual_spent_adjustment)
    spent += _safe_decimal(Transaction.objects.filter(project_budget=item, tx_type=Transaction.TYPE_EXPENSE).aggregate(total=Sum("amount"))["total"])
    return JsonResponse({"ok": True, "project_budget": _serialize_project_budget(item, spent)})


@require_POST
def finance_project_budgets_delete(request, project_budget_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ProjectBudget, id=project_budget_id)
    Transaction.objects.filter(project_budget=item).update(project_budget=None)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def finance_recurring(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_recurring(item) for item in RecurringExpenseTemplate.objects.select_related("category").all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def finance_recurring_create(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)

    name = (payload.get("name") or "").strip()
    if not name:
        return _json_error("Recurring template name is required")

    category = Category.objects.filter(id=payload.get("category_id")).first()
    if not category:
        return _json_error("Valid category is required")

    amount = _safe_decimal(payload.get("amount"), None)
    if amount is None or amount <= 0:
        return _json_error("Amount must be greater than zero")

    account = (payload.get("account") or Transaction.ACCOUNT_BANK).strip()
    if account not in {choice[0] for choice in Transaction.ACCOUNT_CHOICES}:
        return _json_error("Invalid account")

    cadence = (payload.get("cadence") or RecurringExpenseTemplate.CADENCE_MONTHLY).strip()
    if cadence not in {choice[0] for choice in RecurringExpenseTemplate.CADENCE_CHOICES}:
        return _json_error("Invalid cadence")

    next_due_date = _parse_date(payload.get("next_due_date"))
    if not next_due_date:
        return _json_error("Valid next due date is required")

    item = RecurringExpenseTemplate.objects.create(
        name=name,
        category=category,
        account=account,
        amount=amount,
        cadence=cadence,
        next_due_date=next_due_date,
        end_date=_parse_date(payload.get("end_date")),
        is_active=bool(payload.get("is_active", True)),
    )
    return JsonResponse({"ok": True, "recurring": _serialize_recurring(item)}, status=201)


@require_POST
def finance_recurring_update(request, recurring_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(RecurringExpenseTemplate, id=recurring_id)
    payload = _parse_json(request)

    item.name = (payload.get("name") or item.name).strip()
    category = Category.objects.filter(id=payload.get("category_id")).first() if payload.get("category_id") else item.category
    item.category = category

    amount = _safe_decimal(payload.get("amount"), item.amount)
    if amount <= 0:
        return _json_error("Amount must be greater than zero")
    item.amount = amount

    account = (payload.get("account") or item.account).strip()
    if account not in {choice[0] for choice in Transaction.ACCOUNT_CHOICES}:
        return _json_error("Invalid account")
    item.account = account

    cadence = (payload.get("cadence") or item.cadence).strip()
    if cadence not in {choice[0] for choice in RecurringExpenseTemplate.CADENCE_CHOICES}:
        return _json_error("Invalid cadence")
    item.cadence = cadence

    next_due_date = _parse_date(payload.get("next_due_date")) if payload.get("next_due_date") else item.next_due_date
    if not next_due_date:
        return _json_error("Valid next due date is required")
    item.next_due_date = next_due_date

    item.end_date = _parse_date(payload.get("end_date")) if payload.get("end_date") is not None else item.end_date
    item.is_active = bool(payload.get("is_active", item.is_active))
    item.save()

    return JsonResponse({"ok": True, "recurring": _serialize_recurring(item)})


@require_POST
def finance_recurring_delete(request, recurring_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(RecurringExpenseTemplate, id=recurring_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def finance_forecast(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    days = request.GET.get("days", 30)
    try:
        days = int(days)
    except (TypeError, ValueError):
        days = 30
    days = 30 if days not in {30, 60} else days
    return JsonResponse({"ok": True, "rows": _compute_forecast(days=days)})


@require_POST
def finance_recurring_apply_now(request, recurring_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error

    template = get_object_or_404(RecurringExpenseTemplate.objects.select_related("category"), id=recurring_id)
    tx = Transaction.objects.create(
        tx_date=date.today(),
        description=f"Recurring: {template.name}",
        category=template.category,
        account=template.account,
        tx_type=Transaction.TYPE_EXPENSE,
        amount=template.amount,
        tags=["recurring", template.cadence],
        notes="Generated from recurring template",
    )

    if template.cadence == RecurringExpenseTemplate.CADENCE_WEEKLY:
        template.next_due_date = template.next_due_date + timedelta(days=7)
    elif template.cadence == RecurringExpenseTemplate.CADENCE_YEARLY:
        template.next_due_date = _add_months(template.next_due_date, 12)
    else:
        template.next_due_date = _add_months(template.next_due_date, 1)
    template.save(update_fields=["next_due_date", "updated_at"])

    return JsonResponse({"ok": True, "transaction": _serialize_transaction(tx)})


@require_GET
def finance_alerts(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_alert(item) for item in FinanceAlert.objects.all()[:200]]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def finance_alert_mark_read(request, alert_id):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(FinanceAlert, id=alert_id)
    item.is_read = True
    item.save(update_fields=["is_read", "updated_at"])
    return JsonResponse({"ok": True})


@require_POST
def finance_alert_mark_all_read(request):
    auth_error = _require_finance_access(request)
    if auth_error:
        return auth_error
    FinanceAlert.objects.filter(is_read=False).update(is_read=True)
    return JsonResponse({"ok": True})


# -----------------------------
# Education command center APIs
# -----------------------------


def _parse_request_data(request):
    if request.content_type and "application/json" in request.content_type:
        return _parse_json(request)
    return request.POST.dict()


def _bool_value(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off", ""}:
        return False
    return default


def _optional_int(value):
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _serialize_exam(exam):
    return {
        "id": exam.id,
        "academic_level_id": exam.academic_level_id,
        "exam_name": exam.exam_name,
        "exam_year": exam.exam_year,
        "candidate_number": exam.candidate_number,
        "grade_score": exam.grade_score,
        "certificate_url": exam.certificate_file.url if exam.certificate_file else "",
        "notes": exam.notes,
        "updated_at": exam.updated_at.isoformat(),
    }


def _serialize_academic_level(level):
    return {
        "id": level.id,
        "level_type": level.level_type,
        "level_label": level.get_level_type_display(),
        "status": level.status,
        "school_name": level.school_name,
        "admission_number": level.admission_number,
        "location": level.location,
        "start_year": level.start_year,
        "end_year": level.end_year,
        "subjects_taken": level.subjects_taken,
        "grades": level.grades,
        "certification_exam_completed": level.certification_exam_completed,
        "certificate_url": level.certificate_file.url if level.certificate_file else "",
        "university_name": level.university_name,
        "country": level.country,
        "degree": level.degree,
        "major_program": level.major_program,
        "expected_graduation_year": level.expected_graduation_year,
        "student_number": level.student_number,
        "gpa": level.gpa,
        "transcript_url": level.transcript_file.url if level.transcript_file else "",
        "research_topic": level.research_topic,
        "internships": level.internships,
        "clubs_activities": level.clubs_activities,
        "awards": level.awards,
        "notes": level.notes,
        "exam_certifications": [_serialize_exam(exam) for exam in level.exam_certifications.all()],
        "updated_at": level.updated_at.isoformat(),
    }


def _application_result_badge(status):
    if status == ScholarshipApplication.STATUS_ACCEPTED:
        return "accepted"
    if status == ScholarshipApplication.STATUS_REJECTED:
        return "rejected"
    return "pending"


def _serialize_application_document(item):
    return {
        "id": item.id,
        "title": item.title,
        "document_type": item.document_type,
        "document_type_label": item.get_document_type_display(),
        "file_url": item.file.url if item.file else "",
        "file_name": item.file.name.split("/")[-1] if item.file else "",
        "version": item.version,
        "notes": item.notes,
        "expiration_date": item.expiration_date.isoformat() if item.expiration_date else None,
        "updated_at": item.updated_at.isoformat(),
    }


def _serialize_scholarship_requirement(req):
    return {
        "id": req.id,
        "scholarship_id": req.scholarship_id,
        "requirement_name": req.requirement_name,
        "is_required": req.is_required,
        "is_completed": req.is_completed,
        "linked_document_id": req.linked_document_id,
        "linked_document_title": req.linked_document.title if req.linked_document_id else "",
        "sort_order": req.sort_order,
    }


def _serialize_scholarship(item):
    app = getattr(item, "application", None)
    requirements = [_serialize_scholarship_requirement(req) for req in item.requirements.select_related("linked_document").all()]
    completed = len([req for req in requirements if req["is_completed"]])
    total = len(requirements)
    progress_pct = int((completed / total) * 100) if total else 0
    return {
        "id": item.id,
        "name": item.name,
        "country": item.country,
        "university": item.university,
        "field_of_study": item.field_of_study,
        "degree_level": item.degree_level,
        "official_website": item.official_website,
        "application_deadline": item.application_deadline.isoformat() if item.application_deadline else None,
        "tuition_coverage": item.tuition_coverage,
        "monthly_stipend": _to_money(item.monthly_stipend) if item.monthly_stipend is not None else None,
        "travel_coverage": item.travel_coverage,
        "accommodation": item.accommodation,
        "other_benefits": item.other_benefits,
        "is_active": item.is_active,
        "requirements": requirements,
        "requirements_completed": completed,
        "requirements_total": total,
        "progress_pct": progress_pct,
        "application": {
            "id": app.id,
            "status": app.status,
            "status_label": app.get_status_display(),
            "result_badge": _application_result_badge(app.status),
            "is_submitted": app.is_submitted,
            "submission_date": app.submission_date.isoformat() if app.submission_date else None,
            "application_id": app.application_id,
            "portal_link": app.portal_link,
            "notes": app.notes,
        } if app else None,
    }


def _compute_education_deadline_alerts():
    today = date.today()
    alerts = []
    for scholarship in Scholarship.objects.filter(is_active=True):
        if not scholarship.application_deadline:
            continue
        days = (scholarship.application_deadline - today).days
        if days < 0:
            continue
        if days <= 45:
            alerts.append(
                {
                    "type": "scholarship_deadline",
                    "severity": "warning" if days <= 14 else "info",
                    "days_left": days,
                    "message": f"{scholarship.name} deadline in {days} day{'s' if days != 1 else ''}.",
                    "scholarship_id": scholarship.id,
                }
            )

    for item in ApplicationDocument.objects.exclude(expiration_date__isnull=True):
        days = (item.expiration_date - today).days
        if days < 0:
            continue
        if days <= 30:
            alerts.append(
                {
                    "type": "document_expiration",
                    "severity": "warning" if days <= 7 else "info",
                    "days_left": days,
                    "message": f"{item.title} expires in {days} day{'s' if days != 1 else ''}.",
                    "document_id": item.id,
                }
            )

    alerts.sort(key=lambda row: (row["days_left"], row["message"]))
    return alerts[:30]

@require_GET
def education_bootstrap(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    levels = [_serialize_academic_level(item) for item in AcademicLevel.objects.prefetch_related("exam_certifications").all()]
    documents = [_serialize_application_document(item) for item in ApplicationDocument.objects.all()]
    scholarships = [_serialize_scholarship(item) for item in Scholarship.objects.prefetch_related("requirements__linked_document").select_related("application").all()]
    alerts = _compute_education_deadline_alerts()

    return JsonResponse(
        {
            "ok": True,
            "academic_levels": levels,
            "documents": documents,
            "scholarships": scholarships,
            "deadline_alerts": alerts,
            "summary": {
                "levels_count": len(levels),
                "documents_count": len(documents),
                "scholarships_count": len(scholarships),
                "alerts_count": len(alerts),
            },
        }
    )


@require_GET
def education_levels(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_academic_level(item) for item in AcademicLevel.objects.prefetch_related("exam_certifications").all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def education_levels_create(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    payload = _parse_request_data(request)

    level_type = (payload.get("level_type") or "").strip()
    if level_type not in {choice[0] for choice in AcademicLevel.LEVEL_CHOICES}:
        return _json_error("Invalid level type")

    status = (payload.get("status") or AcademicLevel.STATUS_PLANNED).strip()
    if status not in {choice[0] for choice in AcademicLevel.STATUS_CHOICES}:
        status = AcademicLevel.STATUS_PLANNED

    item = AcademicLevel.objects.create(
        level_type=level_type,
        status=status,
        school_name=(payload.get("school_name") or "").strip(),
        admission_number=(payload.get("admission_number") or "").strip(),
        location=(payload.get("location") or "").strip(),
        start_year=_optional_int(payload.get("start_year")),
        end_year=_optional_int(payload.get("end_year")),
        subjects_taken=(payload.get("subjects_taken") or "").strip(),
        grades=(payload.get("grades") or "").strip(),
        certification_exam_completed=_bool_value(payload.get("certification_exam_completed")),
        university_name=(payload.get("university_name") or "").strip(),
        country=(payload.get("country") or "").strip(),
        degree=(payload.get("degree") or "").strip(),
        major_program=(payload.get("major_program") or "").strip(),
        expected_graduation_year=_optional_int(payload.get("expected_graduation_year")),
        student_number=(payload.get("student_number") or "").strip(),
        gpa=(payload.get("gpa") or "").strip(),
        research_topic=(payload.get("research_topic") or "").strip(),
        internships=(payload.get("internships") or "").strip(),
        clubs_activities=(payload.get("clubs_activities") or "").strip(),
        awards=(payload.get("awards") or "").strip(),
        notes=(payload.get("notes") or "").strip(),
    )
    if request.FILES.get("certificate_file"):
        item.certificate_file = request.FILES.get("certificate_file")
    if request.FILES.get("transcript_file"):
        item.transcript_file = request.FILES.get("transcript_file")
    item.save()
    return JsonResponse({"ok": True, "level": _serialize_academic_level(item)}, status=201)


@require_POST
def education_levels_update(request, level_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(AcademicLevel, id=level_id)
    payload = _parse_request_data(request)

    level_type = (payload.get("level_type") or item.level_type).strip()
    if level_type in {choice[0] for choice in AcademicLevel.LEVEL_CHOICES}:
        item.level_type = level_type

    status = (payload.get("status") or item.status).strip()
    if status in {choice[0] for choice in AcademicLevel.STATUS_CHOICES}:
        item.status = status

    fields = [
        "school_name",
        "admission_number",
        "location",
        "subjects_taken",
        "grades",
        "university_name",
        "country",
        "degree",
        "major_program",
        "student_number",
        "gpa",
        "research_topic",
        "internships",
        "clubs_activities",
        "awards",
        "notes",
    ]
    for field in fields:
        if field in payload:
            setattr(item, field, (payload.get(field) or "").strip())

    if "start_year" in payload:
        item.start_year = _optional_int(payload.get("start_year"))
    if "end_year" in payload:
        item.end_year = _optional_int(payload.get("end_year"))
    if "expected_graduation_year" in payload:
        item.expected_graduation_year = _optional_int(payload.get("expected_graduation_year"))
    if "certification_exam_completed" in payload:
        item.certification_exam_completed = _bool_value(payload.get("certification_exam_completed"), item.certification_exam_completed)

    if request.FILES.get("certificate_file"):
        item.certificate_file = request.FILES.get("certificate_file")
    if request.FILES.get("transcript_file"):
        item.transcript_file = request.FILES.get("transcript_file")

    item.save()
    return JsonResponse({"ok": True, "level": _serialize_academic_level(item)})


@require_POST
def education_levels_delete(request, level_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(AcademicLevel, id=level_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def education_exams(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_exam(item) for item in ExamCertification.objects.select_related("academic_level").all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def education_exams_create(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    payload = _parse_request_data(request)

    try:
        level_id = int(payload.get("academic_level_id"))
    except (TypeError, ValueError):
        level_id = None
    level = AcademicLevel.objects.filter(id=level_id).first()
    if not level:
        return _json_error("Academic level is required")

    exam_name = (payload.get("exam_name") or "").strip()
    if not exam_name:
        return _json_error("Exam name is required")

    item = ExamCertification.objects.create(
        academic_level=level,
        exam_name=exam_name,
        exam_year=_optional_int(payload.get("exam_year")),
        candidate_number=(payload.get("candidate_number") or "").strip(),
        grade_score=(payload.get("grade_score") or "").strip(),
        notes=(payload.get("notes") or "").strip(),
    )
    if request.FILES.get("certificate_file"):
        item.certificate_file = request.FILES.get("certificate_file")
        item.save(update_fields=["certificate_file", "updated_at"])

    if "certification_exam_completed" in payload:
        level.certification_exam_completed = _bool_value(payload.get("certification_exam_completed"), True)
    else:
        level.certification_exam_completed = True
    level.save(update_fields=["certification_exam_completed", "updated_at"])
    return JsonResponse({"ok": True, "exam": _serialize_exam(item)}, status=201)


@require_POST
def education_exams_update(request, exam_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ExamCertification, id=exam_id)
    payload = _parse_request_data(request)

    if "academic_level_id" in payload:
        try:
            level_id = int(payload.get("academic_level_id"))
        except (TypeError, ValueError):
            level_id = None
        level = AcademicLevel.objects.filter(id=level_id).first()
        if level:
            item.academic_level = level

    if "exam_name" in payload:
        item.exam_name = (payload.get("exam_name") or item.exam_name).strip()
    if "exam_year" in payload:
        item.exam_year = _optional_int(payload.get("exam_year"))
    if "candidate_number" in payload:
        item.candidate_number = (payload.get("candidate_number") or "").strip()
    if "grade_score" in payload:
        item.grade_score = (payload.get("grade_score") or "").strip()
    if "notes" in payload:
        item.notes = (payload.get("notes") or "").strip()
    if request.FILES.get("certificate_file"):
        item.certificate_file = request.FILES.get("certificate_file")
    item.save()
    return JsonResponse({"ok": True, "exam": _serialize_exam(item)})


@require_POST
def education_exams_delete(request, exam_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ExamCertification, id=exam_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def education_documents(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_application_document(item) for item in ApplicationDocument.objects.all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def education_documents_create(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    payload = _parse_request_data(request)

    title = (payload.get("title") or "").strip()
    if not title:
        return _json_error("Document title is required")
    doc_type = (payload.get("document_type") or ApplicationDocument.TYPE_OTHER).strip()
    if doc_type not in {choice[0] for choice in ApplicationDocument.DOCUMENT_TYPE_CHOICES}:
        return _json_error("Invalid document type")

    uploaded = request.FILES.get("file")
    if not uploaded:
        return _json_error("Document file is required")
    validation_error = _validate_uploaded_file(uploaded)
    if validation_error:
        return _json_error(validation_error)

    item = ApplicationDocument.objects.create(
        title=title,
        document_type=doc_type,
        file=uploaded,
        version=(payload.get("version") or "v1").strip()[:40],
        notes=(payload.get("notes") or "").strip(),
        expiration_date=_parse_date(payload.get("expiration_date")),
    )
    return JsonResponse({"ok": True, "document": _serialize_application_document(item)}, status=201)


@require_POST
def education_documents_update(request, document_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ApplicationDocument, id=document_id)
    payload = _parse_request_data(request)

    if "title" in payload:
        item.title = (payload.get("title") or item.title).strip()
    if "document_type" in payload:
        doc_type = (payload.get("document_type") or item.document_type).strip()
        if doc_type in {choice[0] for choice in ApplicationDocument.DOCUMENT_TYPE_CHOICES}:
            item.document_type = doc_type
    if "version" in payload:
        item.version = (payload.get("version") or item.version).strip()[:40]
    if "notes" in payload:
        item.notes = (payload.get("notes") or "").strip()
    if "expiration_date" in payload:
        item.expiration_date = _parse_date(payload.get("expiration_date"))

    uploaded = request.FILES.get("file")
    if uploaded:
        validation_error = _validate_uploaded_file(uploaded)
        if validation_error:
            return _json_error(validation_error)
        item.file = uploaded

    item.save()
    return JsonResponse({"ok": True, "document": _serialize_application_document(item)})


@require_POST
def education_documents_delete(request, document_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ApplicationDocument, id=document_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def education_scholarships(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    rows = [_serialize_scholarship(item) for item in Scholarship.objects.prefetch_related("requirements__linked_document").select_related("application").all()]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def education_scholarships_create(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)

    name = (payload.get("name") or "").strip()
    if not name:
        return _json_error("Scholarship name is required")

    item = Scholarship.objects.create(
        name=name,
        country=(payload.get("country") or "").strip(),
        university=(payload.get("university") or "").strip(),
        field_of_study=(payload.get("field_of_study") or "").strip(),
        degree_level=(payload.get("degree_level") or "").strip(),
        official_website=(payload.get("official_website") or "").strip(),
        application_deadline=_parse_date(payload.get("application_deadline")),
        tuition_coverage=(payload.get("tuition_coverage") or "").strip(),
        monthly_stipend=_safe_decimal(payload.get("monthly_stipend"), None),
        travel_coverage=_bool_value(payload.get("travel_coverage")),
        accommodation=_bool_value(payload.get("accommodation")),
        other_benefits=(payload.get("other_benefits") or "").strip(),
        is_active=_bool_value(payload.get("is_active"), True),
    )
    ScholarshipApplication.objects.create(
        scholarship=item,
        status=ScholarshipApplication.STATUS_RESEARCHING,
        is_submitted=False,
    )
    return JsonResponse({"ok": True, "scholarship": _serialize_scholarship(item)}, status=201)


@require_POST
def education_scholarships_update(request, scholarship_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(Scholarship, id=scholarship_id)
    payload = _parse_json(request)

    text_fields = [
        "name",
        "country",
        "university",
        "field_of_study",
        "degree_level",
        "official_website",
        "tuition_coverage",
        "other_benefits",
    ]
    for field in text_fields:
        if field in payload:
            setattr(item, field, (payload.get(field) or "").strip())
    if "application_deadline" in payload:
        item.application_deadline = _parse_date(payload.get("application_deadline"))
    if "monthly_stipend" in payload:
        item.monthly_stipend = _safe_decimal(payload.get("monthly_stipend"), None)
    if "travel_coverage" in payload:
        item.travel_coverage = _bool_value(payload.get("travel_coverage"), item.travel_coverage)
    if "accommodation" in payload:
        item.accommodation = _bool_value(payload.get("accommodation"), item.accommodation)
    if "is_active" in payload:
        item.is_active = _bool_value(payload.get("is_active"), item.is_active)
    item.save()
    return JsonResponse({"ok": True, "scholarship": _serialize_scholarship(item)})


@require_POST
def education_scholarships_delete(request, scholarship_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(Scholarship, id=scholarship_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_POST
def education_requirements_create(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)

    scholarship = Scholarship.objects.filter(id=payload.get("scholarship_id")).first()
    if not scholarship:
        return _json_error("Scholarship is required")
    requirement_name = (payload.get("requirement_name") or "").strip()
    if not requirement_name:
        return _json_error("Requirement name is required")

    linked_document = ApplicationDocument.objects.filter(id=payload.get("linked_document_id")).first() if payload.get("linked_document_id") else None
    item = ScholarshipRequirement.objects.create(
        scholarship=scholarship,
        requirement_name=requirement_name,
        is_required=_bool_value(payload.get("is_required"), True),
        is_completed=_bool_value(payload.get("is_completed"), False),
        linked_document=linked_document,
        sort_order=_optional_int(payload.get("sort_order")) or 0,
    )
    return JsonResponse({"ok": True, "requirement": _serialize_scholarship_requirement(item)}, status=201)


@require_POST
def education_requirements_update(request, requirement_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ScholarshipRequirement, id=requirement_id)
    payload = _parse_json(request)

    if "requirement_name" in payload:
        item.requirement_name = (payload.get("requirement_name") or item.requirement_name).strip()
    if "is_required" in payload:
        item.is_required = _bool_value(payload.get("is_required"), item.is_required)
    if "is_completed" in payload:
        item.is_completed = _bool_value(payload.get("is_completed"), item.is_completed)
    if "sort_order" in payload:
        item.sort_order = _optional_int(payload.get("sort_order")) or item.sort_order
    if "linked_document_id" in payload:
        item.linked_document = ApplicationDocument.objects.filter(id=payload.get("linked_document_id")).first() if payload.get("linked_document_id") else None
    item.save()
    return JsonResponse({"ok": True, "requirement": _serialize_scholarship_requirement(item)})


@require_POST
def education_requirements_delete(request, requirement_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ScholarshipRequirement, id=requirement_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_POST
def education_requirements_toggle(request, requirement_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ScholarshipRequirement, id=requirement_id)
    item.is_completed = not item.is_completed
    item.save(update_fields=["is_completed", "updated_at"])
    return JsonResponse({"ok": True, "requirement": _serialize_scholarship_requirement(item)})


@require_POST
def education_applications_create(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    scholarship = Scholarship.objects.filter(id=payload.get("scholarship_id")).first()
    if not scholarship:
        return _json_error("Scholarship is required")
    if ScholarshipApplication.objects.filter(scholarship=scholarship).exists():
        return _json_error("Application already exists for this scholarship", status=409)
    item = ScholarshipApplication.objects.create(scholarship=scholarship)
    return JsonResponse({"ok": True, "application": {"id": item.id, "scholarship_id": scholarship.id}}, status=201)


@require_POST
def education_applications_update(request, application_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ScholarshipApplication, id=application_id)
    payload = _parse_json(request)

    if "status" in payload:
        status = (payload.get("status") or "").strip()
        if status in {choice[0] for choice in ScholarshipApplication.STATUS_CHOICES}:
            item.status = status
    if "is_submitted" in payload:
        item.is_submitted = _bool_value(payload.get("is_submitted"), item.is_submitted)
    if "submission_date" in payload:
        item.submission_date = _parse_date(payload.get("submission_date"))
    if "application_id" in payload:
        item.application_id = (payload.get("application_id") or "").strip()
    if "portal_link" in payload:
        item.portal_link = (payload.get("portal_link") or "").strip()
    if "notes" in payload:
        item.notes = (payload.get("notes") or "").strip()

    item.save()
    return JsonResponse(
        {
            "ok": True,
            "application": {
                "id": item.id,
                "status": item.status,
                "status_label": item.get_status_display(),
                "result_badge": _application_result_badge(item.status),
                "is_submitted": item.is_submitted,
                "submission_date": item.submission_date.isoformat() if item.submission_date else None,
                "application_id": item.application_id,
                "portal_link": item.portal_link,
                "notes": item.notes,
            },
        }
    )


@require_POST
def education_applications_delete(request, application_id):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    item = get_object_or_404(ScholarshipApplication, id=application_id)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def education_deadline_alerts(request):
    auth_error = _require_education_access(request)
    if auth_error:
        return auth_error
    return JsonResponse({"ok": True, "rows": _compute_education_deadline_alerts()})


# -----------------------------
# Personal identity vault APIs
# -----------------------------


PERSONAL_FILE_ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png"}
PHONE_PATTERN = re.compile(r"^\+?[0-9][0-9\-\s]{6,20}$")
URL_PATTERN = re.compile(r"^https?://", re.IGNORECASE)


def _validate_personal_file(uploaded_file):
    if uploaded_file is None:
        return "No file provided"
    if uploaded_file.size > MAX_UPLOAD_SIZE_BYTES:
        return "File is too large. Maximum size is 10MB"
    extension = Path(uploaded_file.name).suffix.lower()
    if extension not in PERSONAL_FILE_ALLOWED_EXTENSIONS:
        return "Unsupported file type. Allowed: PDF, JPG, PNG"
    return None


def _validate_profile_photo(uploaded_file):
    if uploaded_file is None:
        return "No photo provided"
    if uploaded_file.size > MAX_UPLOAD_SIZE_BYTES:
        return "Photo is too large. Maximum size is 10MB"
    extension = Path(uploaded_file.name).suffix.lower()
    if extension not in {".jpg", ".jpeg", ".png"}:
        return "Unsupported photo type. Allowed: JPG, PNG"
    return None


def _is_valid_email(value):
    text = (value or "").strip()
    if not text:
        return True
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", text))


def _is_valid_phone(value):
    text = (value or "").strip()
    if not text:
        return True
    return bool(PHONE_PATTERN.fullmatch(text))


def _is_valid_url(value):
    text = (value or "").strip()
    if not text:
        return True
    return bool(URL_PATTERN.match(text))


def _vault_key_bytes():
    return hashlib.sha256(f"{settings.SECRET_KEY}|personal-vault|v1".encode("utf-8")).digest()


def _personal_keystream(key_bytes, nonce, length):
    stream = bytearray()
    counter = 0
    while len(stream) < length:
        block = hashlib.sha256(key_bytes + nonce + counter.to_bytes(4, "big")).digest()
        stream.extend(block)
        counter += 1
    return bytes(stream[:length])


def _encrypt_personal_sensitive(value):
    text = (value or "").strip()
    if not text:
        return ""
    raw = text.encode("utf-8")
    key = _vault_key_bytes()
    nonce = os.urandom(16)
    stream = _personal_keystream(key, nonce, len(raw))
    cipher = bytes(a ^ b for a, b in zip(raw, stream))
    mac = hmac.new(key, nonce + cipher, hashlib.sha256).digest()[:16]
    token = nonce + mac + cipher
    return base64.urlsafe_b64encode(token).decode("ascii")


def _decrypt_personal_sensitive(token):
    if not token:
        return ""
    try:
        decoded = base64.urlsafe_b64decode(token.encode("ascii"))
        if len(decoded) < 33:
            return ""
        nonce = decoded[:16]
        mac = decoded[16:32]
        cipher = decoded[32:]
        key = _vault_key_bytes()
        expected = hmac.new(key, nonce + cipher, hashlib.sha256).digest()[:16]
        if not hmac.compare_digest(mac, expected):
            return ""
        stream = _personal_keystream(key, nonce, len(cipher))
        plain = bytes(a ^ b for a, b in zip(cipher, stream))
        return plain.decode("utf-8")
    except Exception:
        return ""


def _get_or_create_personal_vault():
    vault = PersonalIdentityVault.objects.first()
    if not vault:
        profile = UserProfile.objects.first()
        first_name = ""
        last_name = ""
        if profile and profile.display_name:
            parts = profile.display_name.split()
            first_name = parts[0] if parts else ""
            last_name = " ".join(parts[1:]) if len(parts) > 1 else ""
        vault = PersonalIdentityVault.objects.create(first_name=first_name, last_name=last_name, nationality="Kenyan")
    contact, _ = ContactInfo.objects.get_or_create(vault=vault)
    identity_docs, _ = IdentityDocuments.objects.get_or_create(vault=vault)
    social, _ = SocialProfiles.objects.get_or_create(vault=vault)
    return vault, contact, identity_docs, social


def _serialize_personal_identity(vault):
    return {
        "first_name": vault.first_name,
        "last_name": vault.last_name,
        "dob": vault.dob.isoformat() if vault.dob else None,
        "gender": vault.gender,
        "nationality": vault.nationality,
        "languages": vault.languages or [],
        "profile_photo_url": vault.profile_photo.url if vault.profile_photo else "",
    }


def _serialize_contact_info(contact):
    return {
        "primary_email": contact.primary_email,
        "secondary_email": contact.secondary_email,
        "additional_emails": contact.additional_emails or [],
        "primary_phone": contact.primary_phone,
        "secondary_phone": contact.secondary_phone,
        "other_phone_numbers": contact.other_phone_numbers or [],
        "home_address": contact.home_address,
        "city": contact.city,
        "country": contact.country,
        "postal_code": contact.postal_code,
    }


def _serialize_identity_documents(identity_docs):
    return {
        "national_id": _decrypt_personal_sensitive(identity_docs.national_id_encrypted),
        "passport_number": _decrypt_personal_sensitive(identity_docs.passport_number_encrypted),
        "passport_expiry": identity_docs.passport_expiry.isoformat() if identity_docs.passport_expiry else None,
        "drivers_license": _decrypt_personal_sensitive(identity_docs.drivers_license_encrypted),
        "student_id": _decrypt_personal_sensitive(identity_docs.student_id_encrypted),
    }


def _serialize_identity_file(item):
    return {
        "id": item.id,
        "file_type": item.file_type,
        "file_type_label": item.get_file_type_display(),
        "file_url": item.file.url if item.file else "",
        "file_name": item.original_name or (item.file.name.split("/")[-1] if item.file else ""),
        "file_size": item.file_size,
        "updated_at": item.updated_at.isoformat(),
    }


def _serialize_digital_account(item):
    return {
        "id": item.id,
        "platform": item.platform,
        "platform_label": item.get_platform_display(),
        "custom_platform": item.custom_platform,
        "username": item.username,
        "email_used": item.email_used,
        "profile_link": item.profile_link,
        "notes": item.notes,
    }


def _serialize_social_profiles(item):
    return {
        "linkedin": item.linkedin,
        "twitter_x": item.twitter_x,
        "instagram": item.instagram,
        "github": item.github,
        "portfolio_website": item.portfolio_website,
        "personal_blog": item.personal_blog,
        "youtube_channel": item.youtube_channel,
    }


def _serialize_password_reference(item):
    return {
        "id": item.id,
        "platform": item.platform,
        "username": item.username,
        "email_used": item.email_used,
        "password_hint": item.password_hint,
        "two_factor_enabled": item.two_factor_enabled,
        "backup_codes_location": item.backup_codes_location,
        "password_manager": item.password_manager,
        "password_manager_label": item.get_password_manager_display(),
        "notes": item.notes,
    }


def _compute_personal_completion(vault, contact, identity_docs, files, digital_accounts, social, password_refs):
    def has_any(values):
        return any(bool(v) for v in values)

    step_checks = []

    step1 = has_any([vault.first_name, vault.last_name, vault.dob, vault.nationality, vault.profile_photo, vault.languages])
    step_checks.append(step1)

    step2 = has_any([contact.primary_email, contact.primary_phone, contact.city, contact.country]) and _is_valid_email(contact.primary_email)
    step_checks.append(step2)

    step3 = has_any(
        [
            _decrypt_personal_sensitive(identity_docs.national_id_encrypted),
            _decrypt_personal_sensitive(identity_docs.passport_number_encrypted),
            identity_docs.passport_expiry,
            _decrypt_personal_sensitive(identity_docs.drivers_license_encrypted),
            _decrypt_personal_sensitive(identity_docs.student_id_encrypted),
        ]
    ) and len(files) > 0
    step_checks.append(step3)

    step4 = len(digital_accounts) > 0
    step_checks.append(step4)

    social_values = [social.linkedin, social.twitter_x, social.instagram, social.github, social.portfolio_website, social.personal_blog, social.youtube_channel]
    step5 = has_any(social_values)
    step_checks.append(step5)

    step6 = len(password_refs) > 0
    step_checks.append(step6)

    completed_count = len([flag for flag in step_checks if flag])
    score = int((completed_count / 6) * 100)

    suggestions = []
    if not step1:
        suggestions.append("Add your basic identity details and profile photo.")
    if not step2:
        suggestions.append("Add a primary contact email and phone number.")
    if not step3:
        suggestions.append("Upload identity documents and add passport details.")
    if not step4:
        suggestions.append("Add your key digital accounts.")
    if not step5:
        suggestions.append("Add public social profile links.")
    if not step6:
        suggestions.append("Add password reference entries with 2FA status.")

    step_labels = [
        "Basic Identity",
        "Contact Information",
        "Identity Documents",
        "Digital Accounts",
        "Public Social Profiles",
        "Security References",
    ]
    step_status = []
    for idx, completed in enumerate(step_checks, start=1):
        icon = "✓" if completed else "○"
        status = "completed" if completed else "not_started"
        if not completed and idx == completed_count + 1:
            icon = "•"
            status = "in_progress"
        step_status.append({"step": idx, "label": step_labels[idx - 1], "icon": icon, "status": status})

    return score, step_status, suggestions


def _personal_document_expiry_alerts(identity_docs):
    alerts = []
    if identity_docs.passport_expiry:
        today = date.today()
        diff = (identity_docs.passport_expiry - today).days
        if diff >= 0 and diff <= 180:
            alerts.append(
                {
                    "type": "passport_expiry",
                    "severity": "warning" if diff <= 60 else "info",
                    "message": f"Passport expires in {diff} day{'s' if diff != 1 else ''}.",
                    "days_left": diff,
                }
            )
    return alerts


@require_GET
def personal_vault_bootstrap(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    vault, contact, identity_docs, social = _get_or_create_personal_vault()
    files = list(IdentityUploadedFile.objects.filter(vault=vault))
    digital_accounts = list(DigitalAccounts.objects.filter(vault=vault))
    password_refs = list(PasswordReferences.objects.filter(vault=vault))
    completion_score, step_status, suggestions = _compute_personal_completion(
        vault, contact, identity_docs, files, digital_accounts, social, password_refs
    )

    return JsonResponse(
        {
            "ok": True,
            "identity": _serialize_personal_identity(vault),
            "contact": _serialize_contact_info(contact),
            "identity_documents": _serialize_identity_documents(identity_docs),
            "uploaded_files": [_serialize_identity_file(item) for item in files],
            "digital_accounts": [_serialize_digital_account(item) for item in digital_accounts],
            "social_profiles": _serialize_social_profiles(social),
            "password_references": [_serialize_password_reference(item) for item in password_refs],
            "completion_score": completion_score,
            "step_status": step_status,
            "suggestions": suggestions,
            "expiry_alerts": _personal_document_expiry_alerts(identity_docs),
        }
    )


@require_POST
def personal_vault_step1_save(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_request_data(request)
    vault, _, _, _ = _get_or_create_personal_vault()

    if "first_name" in payload:
        vault.first_name = (payload.get("first_name") or "").strip()
    if "last_name" in payload:
        vault.last_name = (payload.get("last_name") or "").strip()
    if "dob" in payload:
        vault.dob = _parse_date(payload.get("dob"))
    if "gender" in payload:
        gender = (payload.get("gender") or "").strip()
        if not gender:
            vault.gender = ""
        elif gender in {choice[0] for choice in PersonalIdentityVault.GENDER_CHOICES}:
            vault.gender = gender
    if "nationality" in payload:
        vault.nationality = (payload.get("nationality") or "").strip()
    if "languages" in payload:
        vault.languages = _split_tags(payload.get("languages"))

    photo = request.FILES.get("profile_photo")
    if photo:
        validation_error = _validate_profile_photo(photo)
        if validation_error:
            return _json_error(validation_error)
        vault.profile_photo = photo

    vault.save()
    return JsonResponse({"ok": True, "identity": _serialize_personal_identity(vault)})


@require_POST
def personal_vault_step2_save(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    vault, contact, _, _ = _get_or_create_personal_vault()
    _ = vault

    primary_email = (payload.get("primary_email") or "").strip()
    secondary_email = (payload.get("secondary_email") or "").strip()
    primary_phone = (payload.get("primary_phone") or "").strip()
    secondary_phone = (payload.get("secondary_phone") or "").strip()

    email_values = [primary_email, secondary_email] + _split_tags(payload.get("additional_emails"))
    for email in email_values:
        if email and not _is_valid_email(email):
            return _json_error(f"Invalid email format: {email}")

    phone_values = [primary_phone, secondary_phone] + _split_tags(payload.get("other_phone_numbers"))
    for phone in phone_values:
        if phone and not _is_valid_phone(phone):
            return _json_error(f"Invalid phone format: {phone}")

    contact.primary_email = primary_email
    contact.secondary_email = secondary_email
    contact.additional_emails = _split_tags(payload.get("additional_emails"))
    contact.primary_phone = primary_phone
    contact.secondary_phone = secondary_phone
    contact.other_phone_numbers = _split_tags(payload.get("other_phone_numbers"))
    contact.home_address = (payload.get("home_address") or "").strip()
    contact.city = (payload.get("city") or "").strip()
    contact.country = (payload.get("country") or "").strip()
    contact.postal_code = (payload.get("postal_code") or "").strip()
    contact.save()

    return JsonResponse({"ok": True, "contact": _serialize_contact_info(contact)})


@require_POST
def personal_vault_step3_save(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    _, _, identity_docs, _ = _get_or_create_personal_vault()

    if "national_id" in payload:
        identity_docs.national_id_encrypted = _encrypt_personal_sensitive(payload.get("national_id"))
    if "passport_number" in payload:
        identity_docs.passport_number_encrypted = _encrypt_personal_sensitive(payload.get("passport_number"))
    if "passport_expiry" in payload:
        identity_docs.passport_expiry = _parse_date(payload.get("passport_expiry"))
    if "drivers_license" in payload:
        identity_docs.drivers_license_encrypted = _encrypt_personal_sensitive(payload.get("drivers_license"))
    if "student_id" in payload:
        identity_docs.student_id_encrypted = _encrypt_personal_sensitive(payload.get("student_id"))
    identity_docs.save()

    return JsonResponse({"ok": True, "identity_documents": _serialize_identity_documents(identity_docs)})


@require_GET
def personal_vault_identity_files(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    vault, _, _, _ = _get_or_create_personal_vault()
    rows = [_serialize_identity_file(item) for item in IdentityUploadedFile.objects.filter(vault=vault)]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def personal_vault_identity_file_upload(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_request_data(request)
    vault, _, _, _ = _get_or_create_personal_vault()
    file_type = (payload.get("file_type") or IdentityUploadedFile.TYPE_OTHER).strip()
    if file_type not in {choice[0] for choice in IdentityUploadedFile.FILE_TYPE_CHOICES}:
        return _json_error("Invalid identity document type")

    uploaded_file = request.FILES.get("file")
    validation_error = _validate_personal_file(uploaded_file)
    if validation_error:
        return _json_error(validation_error)

    item = IdentityUploadedFile.objects.create(
        vault=vault,
        file_type=file_type,
        file=uploaded_file,
        original_name=uploaded_file.name,
        file_size=uploaded_file.size,
    )
    return JsonResponse({"ok": True, "file": _serialize_identity_file(item)}, status=201)


@require_POST
def personal_vault_identity_file_delete(request, file_id):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    vault, _, _, _ = _get_or_create_personal_vault()
    item = get_object_or_404(IdentityUploadedFile, id=file_id, vault=vault)
    item.delete()
    return JsonResponse({"ok": True})


@require_GET
def personal_vault_digital_accounts(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    vault, _, _, _ = _get_or_create_personal_vault()
    rows = [_serialize_digital_account(item) for item in DigitalAccounts.objects.filter(vault=vault)]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def personal_vault_digital_accounts_create(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    vault, _, _, _ = _get_or_create_personal_vault()

    platform = (payload.get("platform") or "").strip()
    if platform not in {choice[0] for choice in DigitalAccounts.PLATFORM_CHOICES}:
        return _json_error("Invalid platform")
    profile_link = (payload.get("profile_link") or "").strip()
    if not _is_valid_url(profile_link):
        return _json_error("Invalid profile URL")
    email_used = (payload.get("email_used") or "").strip()
    if email_used and not _is_valid_email(email_used):
        return _json_error("Invalid account email format")

    item = DigitalAccounts.objects.create(
        vault=vault,
        platform=platform,
        custom_platform=(payload.get("custom_platform") or "").strip(),
        username=(payload.get("username") or "").strip(),
        email_used=email_used,
        profile_link=profile_link,
        notes=(payload.get("notes") or "").strip(),
    )
    return JsonResponse({"ok": True, "account": _serialize_digital_account(item)}, status=201)


@require_POST
def personal_vault_digital_accounts_update(request, account_id):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    vault, _, _, _ = _get_or_create_personal_vault()
    item = get_object_or_404(DigitalAccounts, id=account_id, vault=vault)

    platform = (payload.get("platform") if "platform" in payload else item.platform or "").strip()
    if platform not in {choice[0] for choice in DigitalAccounts.PLATFORM_CHOICES}:
        return _json_error("Invalid platform")
    profile_link = (payload.get("profile_link") if "profile_link" in payload else item.profile_link or "").strip()
    if not _is_valid_url(profile_link):
        return _json_error("Invalid profile URL")
    email_used = (payload.get("email_used") if "email_used" in payload else item.email_used or "").strip()
    if email_used and not _is_valid_email(email_used):
        return _json_error("Invalid account email format")

    item.platform = platform
    item.custom_platform = (payload.get("custom_platform") if "custom_platform" in payload else item.custom_platform or "").strip()
    item.username = (payload.get("username") if "username" in payload else item.username or "").strip()
    item.email_used = email_used
    item.profile_link = profile_link
    item.notes = (payload.get("notes") if "notes" in payload else item.notes or "").strip()
    item.save()
    return JsonResponse({"ok": True, "account": _serialize_digital_account(item)})


@require_POST
def personal_vault_digital_accounts_delete(request, account_id):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    vault, _, _, _ = _get_or_create_personal_vault()
    item = get_object_or_404(DigitalAccounts, id=account_id, vault=vault)
    item.delete()
    return JsonResponse({"ok": True})


@require_POST
def personal_vault_social_profiles_save(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    _, _, _, social = _get_or_create_personal_vault()

    url_fields = [
        "linkedin",
        "twitter_x",
        "instagram",
        "github",
        "portfolio_website",
        "personal_blog",
        "youtube_channel",
    ]
    for field in url_fields:
        value = (payload.get(field) or "").strip()
        if value and not _is_valid_url(value):
            return _json_error(f"Invalid URL for {field.replace('_', ' ')}")
        setattr(social, field, value)
    social.save()
    return JsonResponse({"ok": True, "social_profiles": _serialize_social_profiles(social)})


@require_GET
def personal_vault_password_references(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    vault, _, _, _ = _get_or_create_personal_vault()
    rows = [_serialize_password_reference(item) for item in PasswordReferences.objects.filter(vault=vault)]
    return JsonResponse({"ok": True, "rows": rows})


@require_POST
def personal_vault_password_references_create(request):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    vault, _, _, _ = _get_or_create_personal_vault()
    manager = (payload.get("password_manager") or PasswordReferences.MANAGER_BITWARDEN).strip()
    if manager not in {choice[0] for choice in PasswordReferences.PASSWORD_MANAGER_CHOICES}:
        return _json_error("Invalid password manager")
    email_used = (payload.get("email_used") or "").strip()
    if email_used and not _is_valid_email(email_used):
        return _json_error("Invalid email format")
    item = PasswordReferences.objects.create(
        vault=vault,
        platform=(payload.get("platform") or "").strip(),
        username=(payload.get("username") or "").strip(),
        email_used=email_used,
        password_hint=(payload.get("password_hint") or "").strip(),
        two_factor_enabled=_bool_value(payload.get("two_factor_enabled"), False),
        backup_codes_location=(payload.get("backup_codes_location") or "").strip(),
        password_manager=manager,
        notes=(payload.get("notes") or "").strip(),
    )
    return JsonResponse({"ok": True, "reference": _serialize_password_reference(item)}, status=201)


@require_POST
def personal_vault_password_references_update(request, reference_id):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    payload = _parse_json(request)
    vault, _, _, _ = _get_or_create_personal_vault()
    item = get_object_or_404(PasswordReferences, id=reference_id, vault=vault)
    manager = (payload.get("password_manager") if "password_manager" in payload else item.password_manager or "").strip()
    if manager not in {choice[0] for choice in PasswordReferences.PASSWORD_MANAGER_CHOICES}:
        return _json_error("Invalid password manager")
    email_used = (payload.get("email_used") if "email_used" in payload else item.email_used or "").strip()
    if email_used and not _is_valid_email(email_used):
        return _json_error("Invalid email format")

    item.platform = (payload.get("platform") if "platform" in payload else item.platform or "").strip()
    item.username = (payload.get("username") if "username" in payload else item.username or "").strip()
    item.email_used = email_used
    item.password_hint = (payload.get("password_hint") if "password_hint" in payload else item.password_hint or "").strip()
    item.two_factor_enabled = _bool_value(payload.get("two_factor_enabled"), item.two_factor_enabled)
    item.backup_codes_location = (payload.get("backup_codes_location") if "backup_codes_location" in payload else item.backup_codes_location or "").strip()
    item.password_manager = manager
    item.notes = (payload.get("notes") if "notes" in payload else item.notes or "").strip()
    item.save()
    return JsonResponse({"ok": True, "reference": _serialize_password_reference(item)})


@require_POST
def personal_vault_password_references_delete(request, reference_id):
    auth_error = _require_personal_vault_access(request)
    if auth_error:
        return auth_error
    vault, _, _, _ = _get_or_create_personal_vault()
    item = get_object_or_404(PasswordReferences, id=reference_id, vault=vault)
    item.delete()
    return JsonResponse({"ok": True})

```

---

## myos_project/myos_project/__init__.py

- Size: 0 bytes
- Lines: 0
- Modified: 2026-03-05 17:17:13
- SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- MIME: inode/x-empty

```

```

---

## myos_project/myos_project/asgi.py

- Size: 401 bytes
- Lines: 16
- Modified: 2026-03-05 17:17:13
- SHA256: 7c7221345f65a0f10d37cb46a3cad09366c854c399084d9d6d122af1a82a5b5c
- MIME: text/plain

```
"""
ASGI config for myos_project project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/6.0/howto/deployment/asgi/
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myos_project.settings')

application = get_asgi_application()

```

---

## myos_project/myos_project/settings.py

- Size: 3537 bytes
- Lines: 136
- Modified: 2026-03-06 21:50:19
- SHA256: aa860caf117ebab2f8be424e6e5ca549627374db1af0a461fedd905c9a64887e
- MIME: text/plain

```
"""
Django settings for myos_project project.

Generated by 'django-admin startproject' using Django 6.0.3.

For more information on this file, see
https://docs.djangoproject.com/en/6.0/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/6.0/ref/settings/
"""

import os
from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


def _env_bool(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {'1', 'true', 'yes', 'on'}


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/6.0/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'unsafe-dev-secret-key')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = _env_bool('DJANGO_DEBUG', False)

ALLOWED_HOSTS = [
    host.strip()
    for host in os.getenv('DJANGO_ALLOWED_HOSTS', '127.0.0.1,localhost,testserver').split(',')
    if host.strip()
]


# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'myos_app',
    'media_tracker',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'myos_project.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'myos_project.wsgi.application'


# Database
# https://docs.djangoproject.com/en/6.0/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# Password validation
# https://docs.djangoproject.com/en/6.0/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/6.0/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/6.0/howto/static-files/

STATIC_URL = '/static/'
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

FILE_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 20 * 1024 * 1024

```

---

## myos_project/myos_project/urls.py

- Size: 1039 bytes
- Lines: 29
- Modified: 2026-03-06 21:50:23
- SHA256: 34b691a6393a8af836f6356edeab1d539b4dc2b2f31cf1619716133c60cf7464
- MIME: text/plain

```
"""
URL configuration for myos_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('media_tracker.urls')),
    path('', include('myos_app.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

```

---

## myos_project/myos_project/wsgi.py

- Size: 401 bytes
- Lines: 16
- Modified: 2026-03-05 17:17:13
- SHA256: d7165e0cddcc9a8a1f3b4d71a3d537f8b663f75c4fd84b21a4ff1239c2972436
- MIME: text/plain

```
"""
WSGI config for myos_project project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/6.0/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myos_project.settings')

application = get_wsgi_application()

```

