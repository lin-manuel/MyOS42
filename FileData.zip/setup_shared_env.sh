#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$ROOT_DIR/venv"

if [[ ! -d "$VENV_DIR" ]]; then
  python3 -m venv "$VENV_DIR"
fi

"$VENV_DIR/bin/pip" install --upgrade pip
"$VENV_DIR/bin/pip" install -r "$ROOT_DIR/myos_backend/requirements.txt"

(
  cd "$ROOT_DIR/myos_project"
  ../venv/bin/python manage.py check
)

(
  cd "$ROOT_DIR/myos_backend"
  ../venv/bin/python manage.py check
  ../venv/bin/python manage.py makemigrations
  ../venv/bin/python manage.py migrate
)

echo "Shared environment is ready."
