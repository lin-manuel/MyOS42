# MyOS Workspace Architecture Map

## 1) Workspace Layout

```
/home/immanuel/classwork/myos
├── myos_backend/         # Modular API backend (Django + DRF + JWT + OTP)
├── myos_project/         # Template/UI app (Django + HTML/CSS/JS + JSON endpoints)
└── venv/                 # Shared Python environment target
```

## 2) High-Level System Diagram

```mermaid
flowchart LR
    Browser[Browser UI]

    subgraph P2[myos_project]
      P2V[myos_app/views.py\nTemplate + JSON endpoints]
      P2M[(SQLite: myos_project/db.sqlite3)]
      P2S[static/js/main.js\nautosave + uploads]
      P2T[templates/*.html]
    end

    subgraph P1[myos_backend]
      API[apps/api/urls.py\nDRF router + aggregation + search]
      USERS[apps/users\nCustomUser + OTP + JWT]
      DOMAINS[projects/finance/diary/media/bucket/notifications]
      COMMON[apps/common\nAudit middleware + encrypted field]
      DB[(Postgres or SQLite via DATABASE_ENGINE)]
    end

    Browser --> P2S
    Browser --> P2V
    P2V --> P2M
    P2S --> P2V
    Browser --> API
    API --> USERS
    API --> DOMAINS
    USERS --> DB
    DOMAINS --> DB
    COMMON --> DB
```

## 3) `myos_backend` Internal Map

### Request Path

```
myos_backend/urls.py
  -> /api/ -> apps/api/urls.py
      -> DRF router viewsets:
         profile, projects, finance, diary, media, bucket/categories,
         bucket/items, notifications
      -> auth endpoints from apps/users/urls.py
      -> /search/ (cross-domain search)
      -> /dashboard/ (aggregated metrics)
```

### App Responsibilities

- `apps/users`:
  - `CustomUser` + `UserOTP`
  - Signup + OTP verification
  - JWT token issuance with email-verification + optional 2FA checks
  - Password reset request/confirm
- `apps/projects`: project CRUD + progress state transitions + notifications.
- `apps/finance`: finance entries (sensitive text encrypted at rest).
- `apps/diary`: diary entries (content encrypted at rest).
- `apps/media`: user media library CRUD and validation.
- `apps/bucket`: categories + items for bucket goals.
- `apps/notifications`: list/update/read-state actions.
- `apps/common`:
  - `EncryptedTextField` (Fernet)
  - `AuditLogMiddleware`
  - object owner permission base class.

### Cross-App Events

Signal handlers create notifications for project/finance/diary/media/bucket/user events.

## 4) `myos_project` Internal Map

### Request Path

```
myos_project/urls.py
  -> '' include myos_app/urls.py
      -> page routes: dashboard, personal, education, finance, media,
         bucket, projects, analytics, diary, settings
      -> JSON routes: bootstrap/tasks/profile/notifications/forms/uploads
```

### Frontend Behavior (`static/js/main.js`)

- Local auth overlay (`localStorage` flag)
- Autosave per-page form snapshots via `/api/forms/<page>/save/`
- Uploads by page/field via `/api/uploads/<page>/<field>/`
- Dashboard/widgets/charts rendering via Chart.js

### Data Model (`myos_app/models.py`)

- `UserProfile`
- `NotificationPreference`
- `Task`
- `DiaryEntry`
- `PageFormData`
- `UploadedDocument`

## 5) Security/Data Notes

- Backend sensitive diary/finance text uses field-level encryption.
- Encrypted fields cannot support direct DB `icontains`; search now scans decrypted values in bounded windows.
- Backend audit middleware logs mutating HTTP methods.

## 6) Shared Environment Target

- Shared Python runtime target: `venv` with Django 6.x and backend deps from `myos_backend/requirements.txt`.
- Backend settings now support `DATABASE_ENGINE=sqlite` for local single-environment bootstrap.
