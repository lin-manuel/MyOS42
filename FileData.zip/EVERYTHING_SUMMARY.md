# Everything Scan Summary (Workspace: /home/immanuel/classwork/myos)

Generated at: 2026-03-06T22:12:01+03:00

## Scope Scanned
- Entire workspace root recursively, including venv/.
- Complete per-file metadata in WORKSPACE_FULL_MANIFEST.tsv.
- Complete per-directory metadata in WORKSPACE_DIR_MANIFEST.tsv.
- Full first-party source dump in FIRST_PARTY_FILE_DETAILS.md.

## High-Level Totals
- Files (all): 6052
- Directories (all): 2904
- Files outside venv: 376

## Disk Usage
```
4.0K	ARCHITECTURE_MAP.md
4.0K	EVERYTHING_SUMMARY.md
24K	NON_VENV_FILE_LIST.txt
232K	WORKSPACE_DIR_MANIFEST.tsv
692K	FIRST_PARTY_FILE_DETAILS.md
1.2M	WORKSPACE_FULL_MANIFEST.tsv
1.3M	myos_backend
2.2M	myos_project
67M	venv
```

## Top-Level Inventory
```
total 2148
drwxrwxr-x  5 immanuel immanuel    4096 Mar  6 22:11 .
drwxrwxr-x 14 immanuel immanuel    4096 Mar  5 15:52 ..
-rw-rw-r--  1 immanuel immanuel    3563 Mar  6 21:12 ARCHITECTURE_MAP.md
-rw-rw-r--  1 immanuel immanuel     738 Mar  6 22:12 EVERYTHING_SUMMARY.md
-rw-rw-r--  1 immanuel immanuel  706948 Mar  6 21:59 FIRST_PARTY_FILE_DETAILS.md
-rw-rw-r--  1 immanuel immanuel   20807 Mar  6 22:05 NON_VENV_FILE_LIST.txt
-rw-rw-r--  1 immanuel immanuel  237056 Mar  6 21:58 WORKSPACE_DIR_MANIFEST.tsv
-rw-------  1 immanuel immanuel 1193324 Mar  6 22:11 WORKSPACE_FULL_MANIFEST.tsv
drwxrwxr-x  6 immanuel immanuel    4096 Mar  5 18:52 myos_backend
drwxrwxr-x  6 immanuel immanuel    4096 Mar  6 22:01 myos_project
-rwxrwxr-x  1 immanuel immanuel     555 Mar  5 21:13 setup_shared_env.sh
drwxrwxr-x  5 immanuel immanuel    4096 Mar  5 17:15 venv
```

## File Count by Top-Level Directory (from manifest)
```
   5676 venv
    262 myos_backend
    108 myos_project
      1 setup_shared_env.sh
      1 WORKSPACE_DIR_MANIFEST.tsv
      1 NON_VENV_FILE_LIST.txt
      1 FIRST_PARTY_FILE_DETAILS.md
      1 EVERYTHING_SUMMARY.md
      1 ARCHITECTURE_MAP.md
```

## Most Common MIME Types
```
   1585 application/x-bytecode.python
   1226 application/x-gettext-translation
   1215 text/x-po
    976 text/x-script.python
    701 text/plain
    212 inode/x-empty
     58 text/html
     32 image/svg+xml
     29 application/javascript
      4 text/csv
      3 text/xml
      2 text/x-c++
      2 text/x-asm
      2 application/octet-stream
      1 text/x-shellscript
      1 text/x-ruby
      1 image/png
      1 application/vnd.sqlite3
      1 application/gzip
```

## Largest Files (All)
```
./FIRST_PARTY_FILE_DETAILS.md	706948
./venv/lib/python3.12/site-packages/django-6.0.3.dist-info/RECORD	452917
./myos_project/db.sqlite3	442368
./myos_project/media/uploads/personal/certificates/Screenshot_from_2026-02-13_12-52-17.png	400877
./venv/lib/python3.12/site-packages/django/contrib/admin/static/admin/js/vendor/xregexp/xregexp.js	325171
./venv/lib/python3.12/site-packages/django/contrib/admin/static/admin/js/vendor/jquery/jquery.js	285314
./venv/lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem	281617
./venv/lib/python3.12/site-packages/pip/_vendor/pyparsing/__pycache__/core.cpython-312.pyc	267710
./WORKSPACE_DIR_MANIFEST.tsv	237056
./venv/lib/python3.12/site-packages/pip/_vendor/pyparsing/core.py	224445
./venv/lib/python3.12/site-packages/pip/_vendor/idna/uts46data.py	206539
./venv/lib/python3.12/site-packages/pip/_vendor/rich/__pycache__/_emoji_codes.cpython-312.pyc	205978
./venv/lib/python3.12/site-packages/django/contrib/admin/static/admin/js/vendor/select2/select2.full.js	173566
./myos_project/myos_app/__pycache__/views.cpython-312.pyc	167350
./myos_project/myos_app/static/js/main.js	165966
./venv/lib/python3.12/site-packages/django/contrib/admin/static/admin/js/vendor/xregexp/xregexp.min.js	163184
./venv/lib/python3.12/site-packages/pip/_vendor/idna/__pycache__/uts46data.cpython-312.pyc	158871
./venv/lib/python3.12/site-packages/pip/_vendor/pkg_resources/__pycache__/__init__.cpython-312.pyc	146475
./venv/lib/python3.12/site-packages/pip/_vendor/rich/_emoji_codes.py	140235
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/langrussianmodel.py	128035
./myos_project/myos_app/views.py	124752
./venv/lib/python3.12/site-packages/django/db/models/__pycache__/query.cpython-312.pyc	122643
./venv/lib/python3.12/site-packages/pip/_vendor/__pycache__/typing_extensions.cpython-312.pyc	122050
./venv/lib/python3.12/site-packages/django/db/models/sql/query.py	121438
./venv/lib/python3.12/site-packages/django/db/models/sql/__pycache__/query.cpython-312.pyc	117442
./venv/lib/python3.12/site-packages/django/db/models/fields/__pycache__/__init__.cpython-312.pyc	115335
./venv/lib/python3.12/site-packages/pip/_vendor/rich/__pycache__/console.cpython-312.pyc	113795
./venv/lib/python3.12/site-packages/pip/_vendor/typing_extensions.py	111130
./venv/lib/python3.12/site-packages/pip/_vendor/pkg_resources/__init__.py	109364
./venv/lib/python3.12/site-packages/django/db/models/__pycache__/expressions.cpython-312.pyc	108071
./venv/lib/python3.12/site-packages/django/contrib/admin/__pycache__/options.cpython-312.pyc	107910
./venv/lib/python3.12/site-packages/django/db/models/query.py	107796
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/__pycache__/langrussianmodel.cpython-312.pyc	105252
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/langbulgarianmodel.py	104562
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/langthaimodel.py	102774
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/langhungarianmodel.py	101363
./venv/lib/python3.12/site-packages/django/contrib/admin/options.py	99797
./venv/lib/python3.12/site-packages/pip/_vendor/idna/__pycache__/idnadata.cpython-312.pyc	99498
./venv/lib/python3.12/site-packages/pip/_vendor/rich/console.py	99218
./venv/lib/python3.12/site-packages/django/db/models/fields/__init__.py	98663
./venv/lib/python3.12/site-packages/django/db/models/sql/__pycache__/compiler.cpython-312.pyc	98656
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/langgreekmodel.py	98484
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/langhebrewmodel.py	98196
./venv/lib/python3.12/site-packages/django/db/models/__pycache__/base.cpython-312.pyc	97874
./venv/lib/python3.12/site-packages/django/db/models/base.py	97656
./venv/lib/python3.12/site-packages/django/db/models/sql/compiler.py	96014
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/langturkishmodel.py	95372
./venv/lib/python3.12/site-packages/django/db/migrations/autodetector.py	89863
./venv/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/util.cpython-312.pyc	88257
./venv/lib/python3.12/site-packages/django/contrib/admin/static/admin/js/vendor/jquery/jquery.min.js	87533
./venv/lib/python3.12/site-packages/django/db/backends/base/__pycache__/schema.cpython-312.pyc	86286
./venv/lib/python3.12/site-packages/django/db/models/fields/__pycache__/related.cpython-312.pyc	86249
./venv/lib/python3.12/site-packages/django/test/__pycache__/testcases.cpython-312.pyc	83845
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/__pycache__/langbulgarianmodel.cpython-312.pyc	83123
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/__pycache__/langhungarianmodel.cpython-312.pyc	83077
./venv/lib/python3.12/site-packages/pip/_vendor/chardet/__pycache__/johabfreq.cpython-312.pyc	83004
./venv/lib/python3.12/site-packages/django/db/migrations/__pycache__/autodetector.cpython-312.pyc	82618
./venv/lib/python3.12/site-packages/django/db/backends/base/schema.py	82509
./venv/lib/python3.12/site-packages/django/contrib/auth/common-passwords.txt.gz	80228
./venv/lib/python3.12/site-packages/django/db/models/fields/related.py	79862
```

## Non-Venv Codebase Stats
```
myos_backend files: 262
myos_project files: 108
venv files: 5676
myos_backend files (no __pycache__): 134
myos_project files (no __pycache__): 76
text lines (myos_backend + myos_project, excluding __pycache__): 12172
```

## Runtime Environment (venv)
```
Python 3.12.3
Package  Version
-------- -------
asgiref  3.11.1
Django   6.0.3
pip      24.0
sqlparse 0.5.5

site-packages top-level:
asgiref
asgiref-3.11.1.dist-info
django
django-6.0.3.dist-info
pip
pip-24.0.dist-info
sqlparse
sqlparse-0.5.5.dist-info
```

## myos_project Database Snapshot
```
TABLES 40
auth_group
auth_group_permissions
auth_permission
auth_user
auth_user_groups
auth_user_user_permissions
django_admin_log
django_content_type
django_migrations
django_session
media_tracker_mediaitem
media_tracker_mediaprogress
myos_app_academiclevel
myos_app_applicationcost
myos_app_applicationdocument
myos_app_budget
myos_app_category
myos_app_contactinfo
myos_app_diaryentry
myos_app_digitalaccounts
myos_app_examcertification
myos_app_financealert
myos_app_identitydocuments
myos_app_identityuploadedfile
myos_app_notificationpreference
myos_app_pageformdata
myos_app_passwordreferences
myos_app_personalidentityvault
myos_app_project
myos_app_projectbudget
myos_app_recurringexpensetemplate
myos_app_savingsgoal
myos_app_scholarship
myos_app_scholarshipapplication
myos_app_scholarshiprequirement
myos_app_socialprofiles
myos_app_task
myos_app_transaction
myos_app_uploadeddocument
myos_app_userprofile
---
admin.LogEntry	django_admin_log	0
auth.Permission	auth_permission	144
auth.Group	auth_group	0
auth.User	auth_user	1
contenttypes.ContentType	django_content_type	36
sessions.Session	django_session	13
myos_app.UserProfile	myos_app_userprofile	1
myos_app.NotificationPreference	myos_app_notificationpreference	1
myos_app.Task	myos_app_task	4
myos_app.DiaryEntry	myos_app_diaryentry	3
myos_app.PageFormData	myos_app_pageformdata	10
myos_app.UploadedDocument	myos_app_uploadeddocument	1
myos_app.Category	myos_app_category	8
myos_app.SavingsGoal	myos_app_savingsgoal	1
myos_app.ApplicationCost	myos_app_applicationcost	5
myos_app.ProjectBudget	myos_app_projectbudget	1
myos_app.Project	myos_app_project	0
myos_app.Transaction	myos_app_transaction	4
myos_app.Budget	myos_app_budget	5
myos_app.RecurringExpenseTemplate	myos_app_recurringexpensetemplate	2
myos_app.FinanceAlert	myos_app_financealert	1
myos_app.AcademicLevel	myos_app_academiclevel	6
myos_app.ExamCertification	myos_app_examcertification	1
myos_app.ApplicationDocument	myos_app_applicationdocument	1
myos_app.Scholarship	myos_app_scholarship	3
myos_app.ScholarshipApplication	myos_app_scholarshipapplication	3
myos_app.ScholarshipRequirement	myos_app_scholarshiprequirement	10
myos_app.PersonalIdentityVault	myos_app_personalidentityvault	1
myos_app.ContactInfo	myos_app_contactinfo	1
myos_app.IdentityDocuments	myos_app_identitydocuments	1
myos_app.IdentityUploadedFile	myos_app_identityuploadedfile	0
myos_app.DigitalAccounts	myos_app_digitalaccounts	0
myos_app.SocialProfiles	myos_app_socialprofiles	1
myos_app.PasswordReferences	myos_app_passwordreferences	0
media_tracker.MediaItem	media_tracker_mediaitem	0
media_tracker.MediaProgress	media_tracker_mediaprogress	0
```

## Route Inventory
```
myos_backend/myos_backend/urls.py:8:    path("admin/", admin.site.urls),
myos_backend/myos_backend/urls.py:9:    path("", TemplateView.as_view(template_name="index.html"), name="home"),
myos_backend/myos_backend/urls.py:10:    path("api/", include("apps.api.urls")),
myos_backend/apps/api/urls.py:24:    path("", include(router.urls)),
myos_backend/apps/api/urls.py:25:    path("", include("apps.users.urls")),
myos_backend/apps/api/urls.py:26:    path("search/", GlobalSearchAPIView.as_view(), name="global_search"),
myos_backend/apps/api/urls.py:27:    path("dashboard/", DashboardAggregationAPIView.as_view(), name="dashboard_aggregation"),
myos_backend/apps/users/urls.py:17:    path("auth/signup/", SignupAPIView.as_view(), name="signup"),
myos_backend/apps/users/urls.py:18:    path("auth/verify-otp/", VerifyOTPAPIView.as_view(), name="verify_otp"),
myos_backend/apps/users/urls.py:19:    path("auth/2fa/request/", Request2FAAPIView.as_view(), name="request_2fa"),
myos_backend/apps/users/urls.py:20:    path("auth/2fa/verify/", Verify2FAAPIView.as_view(), name="verify_2fa"),
myos_backend/apps/users/urls.py:21:    path("auth/token/", SecureTokenObtainPairView.as_view(), name="token_obtain_pair"),
myos_backend/apps/users/urls.py:22:    path("auth/token/refresh/", SecureTokenRefreshView.as_view(), name="token_refresh"),
myos_backend/apps/users/urls.py:23:    path("auth/password-reset/request/", PasswordResetRequestAPIView.as_view(), name="password_reset_request"),
myos_backend/apps/users/urls.py:24:    path("auth/password-reset/confirm/", PasswordResetConfirmAPIView.as_view(), name="password_reset_confirm"),
myos_backend/apps/users/urls.py:25:    path("auth/social/google/", GoogleSocialLoginAPIView.as_view(), name="google_social_login"),
myos_backend/apps/users/urls.py:26:    path("auth/social/apple/", AppleSocialLoginAPIView.as_view(), name="apple_social_login"),
myos_project/media_tracker/urls.py:6:    path("media/", views.media_dashboard, name="media"),
myos_project/media_tracker/urls.py:7:    path("media/dashboard/", views.media_dashboard, name="media_dashboard"),
myos_project/media_tracker/urls.py:8:    path("media/movies/", views.movies_view, name="movies_view"),
myos_project/media_tracker/urls.py:9:    path("media/series/", views.series_view, name="series_view"),
myos_project/media_tracker/urls.py:10:    path("media/anime/", views.anime_view, name="anime_view"),
myos_project/media_tracker/urls.py:11:    path("media/animation/", views.animation_view, name="animation_view"),
myos_project/media_tracker/urls.py:12:    path("media/add/", views.add_media, name="add_media"),
myos_project/media_tracker/urls.py:13:    path("media/edit/<int:item_id>/", views.edit_media, name="edit_media"),
myos_project/media_tracker/urls.py:14:    path("media/delete/<int:item_id>/", views.delete_media, name="delete_media"),
myos_project/media_tracker/urls.py:15:    path("media/progress/<int:item_id>/", views.update_progress, name="update_progress"),
myos_project/media_tracker/urls.py:16:    path("api/media/stats/", views.api_media_stats, name="api_media_stats"),
myos_project/media_tracker/urls.py:17:    path("api/media/movies/", views.api_media_movies, name="api_media_movies"),
myos_project/media_tracker/urls.py:18:    path("api/media/series/", views.api_media_series, name="api_media_series"),
myos_project/media_tracker/urls.py:19:    path("api/media/anime/", views.api_media_anime, name="api_media_anime"),
myos_project/myos_app/urls.py:5:    path("", views.dashboard_page, name="dashboard"),
myos_project/myos_app/urls.py:6:    path("home/", views.home, name="home"),
myos_project/myos_app/urls.py:7:    path("personal/", views.personal_page, name="personal"),
myos_project/myos_app/urls.py:8:    path("education/", views.education_page, name="education"),
myos_project/myos_app/urls.py:9:    path("finance/", views.finance_page, name="finance"),
myos_project/myos_app/urls.py:10:    path("bucket/", views.bucket_page, name="bucket"),
myos_project/myos_app/urls.py:11:    path("projects/", views.projects_page, name="projects"),
myos_project/myos_app/urls.py:12:    path("diary/", views.diary_page, name="diary"),
myos_project/myos_app/urls.py:13:    path("settings/", views.settings_page, name="settings"),
myos_project/myos_app/urls.py:15:    path("api/projects/", views.projects_list, name="projects_list"),
myos_project/myos_app/urls.py:16:    path("api/projects/create/", views.projects_create, name="projects_create"),
myos_project/myos_app/urls.py:17:    path("api/projects/<int:project_id>/update/", views.projects_update, name="projects_update"),
myos_project/myos_app/urls.py:18:    path("api/projects/<int:project_id>/delete/", views.projects_delete, name="projects_delete"),
myos_project/myos_app/urls.py:20:    path("api/bootstrap/", views.bootstrap_data, name="bootstrap_data"),
myos_project/myos_app/urls.py:21:    path("api/tasks/create/", views.create_task, name="create_task"),
myos_project/myos_app/urls.py:22:    path("api/tasks/<int:task_id>/toggle/", views.toggle_task, name="toggle_task"),
myos_project/myos_app/urls.py:23:    path("api/diary/save/", views.save_diary_entry, name="save_diary_entry"),
myos_project/myos_app/urls.py:24:    path("api/profile/save/", views.save_profile, name="save_profile"),
myos_project/myos_app/urls.py:25:    path("api/notifications/save/", views.save_notifications, name="save_notifications"),
myos_project/myos_app/urls.py:26:    path("api/forms/<slug:page_slug>/", views.get_page_form_data, name="get_page_form_data"),
myos_project/myos_app/urls.py:27:    path("api/forms/<slug:page_slug>/save/", views.save_page_form_data, name="save_page_form_data"),
myos_project/myos_app/urls.py:28:    path("api/uploads/<slug:page_slug>/", views.list_uploaded_files, name="list_uploaded_files"),
myos_project/myos_app/urls.py:29:    path("api/uploads/<slug:page_slug>/<slug:field_key>/", views.upload_file_for_field, name="upload_file_for_field"),
myos_project/myos_app/urls.py:31:    path("api/personal-vault/bootstrap/", views.personal_vault_bootstrap, name="personal_vault_bootstrap"),
myos_project/myos_app/urls.py:32:    path("api/personal-vault/step1/save/", views.personal_vault_step1_save, name="personal_vault_step1_save"),
myos_project/myos_app/urls.py:33:    path("api/personal-vault/step2/save/", views.personal_vault_step2_save, name="personal_vault_step2_save"),
myos_project/myos_app/urls.py:34:    path("api/personal-vault/step3/save/", views.personal_vault_step3_save, name="personal_vault_step3_save"),
myos_project/myos_app/urls.py:35:    path("api/personal-vault/identity-files/", views.personal_vault_identity_files, name="personal_vault_identity_files"),
myos_project/myos_app/urls.py:36:    path("api/personal-vault/identity-files/upload/", views.personal_vault_identity_file_upload, name="personal_vault_identity_file_upload"),
myos_project/myos_app/urls.py:37:    path("api/personal-vault/identity-files/<int:file_id>/delete/", views.personal_vault_identity_file_delete, name="personal_vault_identity_file_delete"),
myos_project/myos_app/urls.py:38:    path("api/personal-vault/digital-accounts/", views.personal_vault_digital_accounts, name="personal_vault_digital_accounts"),
myos_project/myos_app/urls.py:39:    path("api/personal-vault/digital-accounts/create/", views.personal_vault_digital_accounts_create, name="personal_vault_digital_accounts_create"),
myos_project/myos_app/urls.py:40:    path("api/personal-vault/digital-accounts/<int:account_id>/update/", views.personal_vault_digital_accounts_update, name="personal_vault_digital_accounts_update"),
myos_project/myos_app/urls.py:41:    path("api/personal-vault/digital-accounts/<int:account_id>/delete/", views.personal_vault_digital_accounts_delete, name="personal_vault_digital_accounts_delete"),
myos_project/myos_app/urls.py:42:    path("api/personal-vault/social-profiles/save/", views.personal_vault_social_profiles_save, name="personal_vault_social_profiles_save"),
myos_project/myos_app/urls.py:43:    path("api/personal-vault/password-references/", views.personal_vault_password_references, name="personal_vault_password_references"),
myos_project/myos_app/urls.py:44:    path("api/personal-vault/password-references/create/", views.personal_vault_password_references_create, name="personal_vault_password_references_create"),
myos_project/myos_app/urls.py:45:    path("api/personal-vault/password-references/<int:reference_id>/update/", views.personal_vault_password_references_update, name="personal_vault_password_references_update"),
myos_project/myos_app/urls.py:46:    path("api/personal-vault/password-references/<int:reference_id>/delete/", views.personal_vault_password_references_delete, name="personal_vault_password_references_delete"),
myos_project/myos_app/urls.py:48:    path("api/finance/bootstrap/", views.finance_bootstrap, name="finance_bootstrap"),
myos_project/myos_app/urls.py:50:    path("api/finance/transactions/", views.finance_transactions, name="finance_transactions"),
myos_project/myos_app/urls.py:51:    path("api/finance/transactions/create/", views.finance_transactions_create, name="finance_transactions_create"),
myos_project/myos_app/urls.py:52:    path("api/finance/transactions/<int:transaction_id>/update/", views.finance_transactions_update, name="finance_transactions_update"),
myos_project/myos_app/urls.py:53:    path("api/finance/transactions/<int:transaction_id>/delete/", views.finance_transactions_delete, name="finance_transactions_delete"),
myos_project/myos_app/urls.py:54:    path("api/finance/transactions/export.csv", views.finance_transactions_export_csv, name="finance_transactions_export_csv"),
myos_project/myos_app/urls.py:56:    path("api/finance/categories/", views.finance_categories, name="finance_categories"),
myos_project/myos_app/urls.py:57:    path("api/finance/categories/create/", views.finance_categories_create, name="finance_categories_create"),
myos_project/myos_app/urls.py:58:    path("api/finance/categories/<int:category_id>/update/", views.finance_categories_update, name="finance_categories_update"),
myos_project/myos_app/urls.py:59:    path("api/finance/categories/<int:category_id>/delete/", views.finance_categories_delete, name="finance_categories_delete"),
myos_project/myos_app/urls.py:61:    path("api/finance/budgets/", views.finance_budgets, name="finance_budgets"),
myos_project/myos_app/urls.py:62:    path("api/finance/budgets/create/", views.finance_budgets_create, name="finance_budgets_create"),
myos_project/myos_app/urls.py:63:    path("api/finance/budgets/<int:budget_id>/update/", views.finance_budgets_update, name="finance_budgets_update"),
myos_project/myos_app/urls.py:64:    path("api/finance/budgets/<int:budget_id>/delete/", views.finance_budgets_delete, name="finance_budgets_delete"),
myos_project/myos_app/urls.py:66:    path("api/finance/savings-goals/", views.finance_savings_goals, name="finance_savings_goals"),
myos_project/myos_app/urls.py:67:    path("api/finance/savings-goals/create/", views.finance_savings_goals_create, name="finance_savings_goals_create"),
myos_project/myos_app/urls.py:68:    path("api/finance/savings-goals/<int:goal_id>/update/", views.finance_savings_goals_update, name="finance_savings_goals_update"),
myos_project/myos_app/urls.py:69:    path("api/finance/savings-goals/<int:goal_id>/delete/", views.finance_savings_goals_delete, name="finance_savings_goals_delete"),
myos_project/myos_app/urls.py:71:    path("api/finance/application-costs/", views.finance_application_costs, name="finance_application_costs"),
myos_project/myos_app/urls.py:72:    path("api/finance/application-costs/create/", views.finance_application_costs_create, name="finance_application_costs_create"),
myos_project/myos_app/urls.py:73:    path("api/finance/application-costs/<int:cost_id>/update/", views.finance_application_costs_update, name="finance_application_costs_update"),
myos_project/myos_app/urls.py:74:    path("api/finance/application-costs/<int:cost_id>/delete/", views.finance_application_costs_delete, name="finance_application_costs_delete"),
myos_project/myos_app/urls.py:76:    path("api/finance/project-budgets/", views.finance_project_budgets, name="finance_project_budgets"),
myos_project/myos_app/urls.py:77:    path("api/finance/project-budgets/create/", views.finance_project_budgets_create, name="finance_project_budgets_create"),
myos_project/myos_app/urls.py:78:    path("api/finance/project-budgets/<int:project_budget_id>/update/", views.finance_project_budgets_update, name="finance_project_budgets_update"),
myos_project/myos_app/urls.py:79:    path("api/finance/project-budgets/<int:project_budget_id>/delete/", views.finance_project_budgets_delete, name="finance_project_budgets_delete"),
myos_project/myos_app/urls.py:81:    path("api/finance/recurring/", views.finance_recurring, name="finance_recurring"),
myos_project/myos_app/urls.py:82:    path("api/finance/recurring/create/", views.finance_recurring_create, name="finance_recurring_create"),
myos_project/myos_app/urls.py:83:    path("api/finance/recurring/<int:recurring_id>/update/", views.finance_recurring_update, name="finance_recurring_update"),
myos_project/myos_app/urls.py:84:    path("api/finance/recurring/<int:recurring_id>/delete/", views.finance_recurring_delete, name="finance_recurring_delete"),
myos_project/myos_app/urls.py:85:    path("api/finance/forecast/", views.finance_forecast, name="finance_forecast"),
myos_project/myos_app/urls.py:86:    path("api/finance/recurring/<int:recurring_id>/apply-now/", views.finance_recurring_apply_now, name="finance_recurring_apply_now"),
myos_project/myos_app/urls.py:88:    path("api/finance/alerts/", views.finance_alerts, name="finance_alerts"),
myos_project/myos_app/urls.py:89:    path("api/finance/alerts/<int:alert_id>/mark-read/", views.finance_alert_mark_read, name="finance_alert_mark_read"),
myos_project/myos_app/urls.py:90:    path("api/finance/alerts/mark-all-read/", views.finance_alert_mark_all_read, name="finance_alert_mark_all_read"),
myos_project/myos_app/urls.py:92:    path("api/education/bootstrap/", views.education_bootstrap, name="education_bootstrap"),
myos_project/myos_app/urls.py:94:    path("api/education/levels/", views.education_levels, name="education_levels"),
myos_project/myos_app/urls.py:95:    path("api/education/levels/create/", views.education_levels_create, name="education_levels_create"),
myos_project/myos_app/urls.py:96:    path("api/education/levels/<int:level_id>/update/", views.education_levels_update, name="education_levels_update"),
myos_project/myos_app/urls.py:97:    path("api/education/levels/<int:level_id>/delete/", views.education_levels_delete, name="education_levels_delete"),
myos_project/myos_app/urls.py:99:    path("api/education/exams/", views.education_exams, name="education_exams"),
myos_project/myos_app/urls.py:100:    path("api/education/exams/create/", views.education_exams_create, name="education_exams_create"),
myos_project/myos_app/urls.py:101:    path("api/education/exams/<int:exam_id>/update/", views.education_exams_update, name="education_exams_update"),
myos_project/myos_app/urls.py:102:    path("api/education/exams/<int:exam_id>/delete/", views.education_exams_delete, name="education_exams_delete"),
myos_project/myos_app/urls.py:104:    path("api/education/documents/", views.education_documents, name="education_documents"),
myos_project/myos_app/urls.py:105:    path("api/education/documents/create/", views.education_documents_create, name="education_documents_create"),
myos_project/myos_app/urls.py:106:    path("api/education/documents/<int:document_id>/update/", views.education_documents_update, name="education_documents_update"),
myos_project/myos_app/urls.py:107:    path("api/education/documents/<int:document_id>/delete/", views.education_documents_delete, name="education_documents_delete"),
myos_project/myos_app/urls.py:109:    path("api/education/scholarships/", views.education_scholarships, name="education_scholarships"),
myos_project/myos_app/urls.py:110:    path("api/education/scholarships/create/", views.education_scholarships_create, name="education_scholarships_create"),
myos_project/myos_app/urls.py:111:    path("api/education/scholarships/<int:scholarship_id>/update/", views.education_scholarships_update, name="education_scholarships_update"),
myos_project/myos_app/urls.py:112:    path("api/education/scholarships/<int:scholarship_id>/delete/", views.education_scholarships_delete, name="education_scholarships_delete"),
myos_project/myos_app/urls.py:114:    path("api/education/requirements/create/", views.education_requirements_create, name="education_requirements_create"),
myos_project/myos_app/urls.py:115:    path("api/education/requirements/<int:requirement_id>/update/", views.education_requirements_update, name="education_requirements_update"),
myos_project/myos_app/urls.py:116:    path("api/education/requirements/<int:requirement_id>/delete/", views.education_requirements_delete, name="education_requirements_delete"),
myos_project/myos_app/urls.py:117:    path("api/education/requirements/<int:requirement_id>/toggle/", views.education_requirements_toggle, name="education_requirements_toggle"),
myos_project/myos_app/urls.py:119:    path("api/education/applications/create/", views.education_applications_create, name="education_applications_create"),
myos_project/myos_app/urls.py:120:    path("api/education/applications/<int:application_id>/update/", views.education_applications_update, name="education_applications_update"),
myos_project/myos_app/urls.py:121:    path("api/education/applications/<int:application_id>/delete/", views.education_applications_delete, name="education_applications_delete"),
myos_project/myos_app/urls.py:123:    path("api/education/deadline-alerts/", views.education_deadline_alerts, name="education_deadline_alerts"),
```

## Model Class Inventory
```
myos_backend/apps/users/models.py:10:class CustomUserManager(BaseUserManager):
myos_backend/apps/users/models.py:27:class CustomUser(AbstractBaseUser, PermissionsMixin, TimeStampedModel):
myos_backend/apps/users/models.py:49:class UserOTP(TimeStampedModel):
myos_backend/apps/projects/models.py:8:class Project(TimeStampedModel):
myos_backend/apps/notifications/models.py:7:class Notification(TimeStampedModel):
myos_backend/apps/media/models.py:19:class MediaItem(TimeStampedModel):
myos_backend/apps/finance/models.py:9:class FinanceEntry(TimeStampedModel):
myos_backend/apps/diary/models.py:8:class DiaryEntry(TimeStampedModel):
myos_backend/apps/bucket/models.py:7:class BucketCategory(TimeStampedModel):
myos_backend/apps/bucket/models.py:19:class BucketItem(TimeStampedModel):
myos_project/media_tracker/models.py:7:class MediaItem(models.Model):
myos_project/media_tracker/models.py:87:class MediaProgress(models.Model):
myos_backend/apps/common/models.py:5:class TimeStampedModel(models.Model):
myos_backend/apps/common/models.py:13:class AuditLog(models.Model):
myos_project/myos_app/models.py:8:class UserProfile(models.Model):
myos_project/myos_app/models.py:18:class NotificationPreference(models.Model):
myos_project/myos_app/models.py:29:class Task(models.Model):
myos_project/myos_app/models.py:43:class DiaryEntry(models.Model):
myos_project/myos_app/models.py:59:class PageFormData(models.Model):
myos_project/myos_app/models.py:77:class UploadedDocument(models.Model):
myos_project/myos_app/models.py:94:class TimeStampedModel(models.Model):
myos_project/myos_app/models.py:102:class Category(TimeStampedModel):
myos_project/myos_app/models.py:143:class SavingsGoal(TimeStampedModel):
myos_project/myos_app/models.py:168:class ApplicationCost(TimeStampedModel):
myos_project/myos_app/models.py:221:class ProjectBudget(TimeStampedModel):
myos_project/myos_app/models.py:246:class Project(TimeStampedModel):
myos_project/myos_app/models.py:273:class Transaction(TimeStampedModel):
myos_project/myos_app/models.py:319:class Budget(TimeStampedModel):
myos_project/myos_app/models.py:336:class RecurringExpenseTemplate(TimeStampedModel):
myos_project/myos_app/models.py:363:class FinanceAlert(TimeStampedModel):
myos_project/myos_app/models.py:420:class AcademicLevel(TimeStampedModel):
myos_project/myos_app/models.py:477:class ExamCertification(TimeStampedModel):
myos_project/myos_app/models.py:493:class ApplicationDocument(TimeStampedModel):
myos_project/myos_app/models.py:528:class Scholarship(TimeStampedModel):
myos_project/myos_app/models.py:551:class ScholarshipApplication(TimeStampedModel):
myos_project/myos_app/models.py:585:class ScholarshipRequirement(TimeStampedModel):
myos_project/myos_app/models.py:605:class PersonalIdentityVault(TimeStampedModel):
myos_project/myos_app/models.py:633:class ContactInfo(TimeStampedModel):
myos_project/myos_app/models.py:653:class IdentityDocuments(TimeStampedModel):
myos_project/myos_app/models.py:668:class IdentityUploadedFile(TimeStampedModel):
myos_project/myos_app/models.py:696:class DigitalAccounts(TimeStampedModel):
myos_project/myos_app/models.py:736:class SocialProfiles(TimeStampedModel):
myos_project/myos_app/models.py:753:class PasswordReferences(TimeStampedModel):
```

## Migration Inventory
```
myos_project/media_tracker/migrations/0001_initial.py
myos_project/myos_app/migrations/0001_initial.py
myos_project/myos_app/migrations/0002_pageformdata.py
myos_project/myos_app/migrations/0003_uploadeddocument.py
myos_project/myos_app/migrations/0004_applicationcost_category_projectbudget_savingsgoal_and_more.py
myos_project/myos_app/migrations/0005_seed_finance_defaults.py
myos_project/myos_app/migrations/0006_academiclevel_applicationdocument_scholarship_and_more.py
myos_project/myos_app/migrations/0007_personalidentityvault_passwordreferences_and_more.py
myos_project/myos_app/migrations/0008_project.py
```

## Zero-Byte Files
```
myos_backend/apps/__init__.py
myos_backend/apps/api/__init__.py
myos_backend/apps/api/migrations/__init__.py
myos_backend/apps/api/services/__init__.py
myos_backend/apps/api/tests/__init__.py
myos_backend/apps/bucket/__init__.py
myos_backend/apps/bucket/migrations/__init__.py
myos_backend/apps/bucket/services/__init__.py
myos_backend/apps/bucket/tests/__init__.py
myos_backend/apps/common/__init__.py
myos_backend/apps/common/migrations/__init__.py
myos_backend/apps/common/services/__init__.py
myos_backend/apps/common/tests/__init__.py
myos_backend/apps/diary/__init__.py
myos_backend/apps/diary/migrations/__init__.py
myos_backend/apps/diary/services/__init__.py
myos_backend/apps/diary/tests/__init__.py
myos_backend/apps/finance/__init__.py
myos_backend/apps/finance/migrations/__init__.py
myos_backend/apps/finance/services/__init__.py
myos_backend/apps/finance/tests/__init__.py
myos_backend/apps/media/__init__.py
myos_backend/apps/media/migrations/__init__.py
myos_backend/apps/media/services/__init__.py
myos_backend/apps/media/tests/__init__.py
myos_backend/apps/notifications/__init__.py
myos_backend/apps/notifications/migrations/__init__.py
myos_backend/apps/notifications/services/__init__.py
myos_backend/apps/notifications/tests/__init__.py
myos_backend/apps/projects/__init__.py
myos_backend/apps/projects/migrations/__init__.py
myos_backend/apps/projects/services/__init__.py
myos_backend/apps/projects/tests/__init__.py
myos_backend/apps/users/__init__.py
myos_backend/apps/users/migrations/__init__.py
myos_backend/apps/users/services/__init__.py
myos_backend/apps/users/tests/__init__.py
myos_backend/myos_backend/__init__.py
myos_backend/myos_backend/settings/__init__.py
myos_project/myos_app/__init__.py
myos_project/myos_app/migrations/__init__.py
myos_project/myos_project/__init__.py
```
